"""
stats/core/util.py

Contains functions to help with statistical analysis. Functions in here should be generally
useful and agnostic to the type of data.

Author: Jen Selby <jen.selby@bluerivertech.com
Copyright 2020, Blue River Technology
"""


import numpy as np


def bootstrap_summary(data, iterations=1000, sample_size=None):
    """
    Resamples data with replacement and returns the mean and standard deviation
    of the means of the resampled populations.

    Args:
        data (list or numpy.ndarray or pandas.core.series.Series):
            numerical data
        iterations (int): number of resamples to perform
            (default 1000, because below that it is hard to see if distribution is normal)
        sample_size (int): number of samples to take per iteration (default: size of data)
    Returns:
        float: mean of resample means
        float: standard deviation of resample means
    """

    if sample_size is None:
        if hasattr(data, "size"):
            sample_size = data.size
        else:
            sample_size = len(data)
    if sample_size == 0:
        return np.nan, np.nan

    resamples = np.random.choice(data, (iterations, sample_size), replace=True)
    means = resamples.mean(axis=1)

    return means.mean(), means.std()
