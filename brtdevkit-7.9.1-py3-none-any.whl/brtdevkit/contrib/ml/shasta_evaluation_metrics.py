""" shasta_evaluation_metrics.py -- Various utility functions related
to dl-core model evaluation.

Includes utilities for:
 - Parsing evaluation metrics into dictionaries
 - Generating thumbnails for Aletheia ImageEvaluations.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivertech.com>
Copyright 2020, Blue River Technology
"""

import csv
from collections import defaultdict
from os import PathLike
from typing import Any, Optional

import cv2
import numpy as np
from skimage import io as imageio


def _update_metrics(metrics, header: str, value: Any, labelmap: dict):
    """ Updates a metrics dictionary in place for a given
    set of inputs.

    Args:
        header (str): Example - PixelMetric_precision_0
        value (convertible to str): Example - 0.9835
        labelmap (dict): Example {0: 'ground', 1: 'weed', 2: 'crop'}
    """
    metric, measure = header.split('_', 1)
    for k, v in labelmap.items():
        measure = measure.replace(str(k), v)
    metrics[metric][measure] = value


def parse_aggregate_metrics(path: PathLike, labelmap: dict):
    """
    Parse aggregate evaluation metrics CSV into Python dictionary.
    Convert numerical codes to labelmap mapped classes.

    Args:
        path (PathLike): Path to the aggregate metrics CSV file
        labelmap (dict): Labelmap to use when mapping classes
    Returns:
        dict: Dictionary containing aggregrate metrics with
        mapped class names.

        Example:
        {
            "PixelMetric": {
                "precision_ground": "0.986619451942997",
                "precision_weed": "0.010400460714623392",
                "precision_crop": "0.9125456936103548",
                ...
            },
            "GridMetric": {
                "covered_targets": "40.0",
                "missed_targets": "4.0",
                ...
            }
        }
    """
    metrics = defaultdict(dict)
    with open(path) as csvfile:
        reader = csv.reader(csvfile)
        for header, value in reader:
            _update_metrics(metrics, header, value, labelmap)
    return metrics


def parse_sample_metrics(path: PathLike, labelmap: dict):
    """
    Parse sample evaluation metrics CSV into Python dictionary.
    Convert numerical codes to labelmap mapped classes.

    Args:
        path (PathLike): Path to the sample metrics CSV file
        labelmap (dict): Labelmap to use when mapping classes
    Returns:
        dict: Dictionary containing sample metrics with
        mapped class names keyed by image ID.

        Example:
        {
            "5efa63f7b09e350638daf0ba": {
                "PixelMetric": {
                    "precision_ground": "0.9876709116490494",
                    "precision_weed": "0.0",
                    "precision_crop": "0.9379954268292683",
                    ...
                },
                "GridMetric": {
                    "covered_targets": "1",
                    "missed_targets": "0",
                    ...
                }
            },
            "5efa63fa7717ba0fdeaca2c9": {
                "PixelMetric": {
                    "precision_ground": "0.9775344442375722",
                    "precision_weed": "0.07031425364758698",
                    "precision_crop": "0.9313073394495412",
                    ...
                },
                "GridMetric": {
                    "covered_targets": "3",
                    "missed_targets": "0",
                    ...
                }
            }
        }
    """
    sample_metrics = {}
    with open(path) as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            img_id = row.pop('')
            metrics = defaultdict(dict)
            for header, value in row.items():
                _update_metrics(metrics, header, value, labelmap)
            sample_metrics[img_id] = metrics
    return sample_metrics


def pixel_metrics_to_confusion_matrix_csv(
        pixel_metrics: dict, labels: Optional[list], outfile: PathLike):
    """
    From Shasta model evaluation results, generate a confusion matrix in CSV form
    for consumption by the KFP metadata UI visualization system.

    Args:
        pixel_metrics (dict): Pixel metrics dictionary
        labels (Optional[list[str]]): Optional list of class labels. Will be
                                      inferred if not provided
        outfile (PathLike): Outfile for the CSV

    Example:
        Pixel metrics
        {
            "class_crop_as_class_crop": "112.0",
            "class_crop_as_class_ground": "143616.0",
            "class_crop_as_class_weed": "19556.0",
            "class_ground_as_class_crop": "0.0",
            "class_ground_as_class_ground": "3976355.0",
            "class_ground_as_class_weed": "457.0",
            "class_weed_as_class_crop": "0.0",
            "class_weed_as_class_ground": "4493.0",
            "class_weed_as_class_weed": "2611.0",
            ...
        }
        will be converted to CSV:

        crop,crop,112.0
        crop,ground,143616.0
        crop,weed,19556.0
        ground,crop,0.0
        ground,ground,3976355.0
        ground,weed,457.0
        weed,crop,0.0
        weed,ground,4493.0
        weed,weed,2611.0
    """
    # Infer the class labels if not provided
    # by accumulating y for every class_{x}_as_class_{y}
    if labels is None:
        labels_set = set()
        for k, v in pixel_metrics.items():
            if '_as_class_' in k:
                labels_set.add(k.split('_as_class_', 1)[1])
        labels = list(labels_set)
    # Construct CSV rows
    rows = []
    for i in range(len(labels)):
        for j in range(len(labels)):
            target = labels[i]
            predicted = labels[j]
            count = pixel_metrics[f'class_{target}_as_class_{predicted}']
            rows.append([target, predicted, count])
    # Write the CSV
    with open(outfile, 'w') as f:
        writer = csv.writer(f)
        writer.writerows(rows)


DEFAULT_COLOR_MAP = {
    # class: (r, g, b, a)
    0: (0, 0, 0, 0),
    1: (0, 0, 255, 0.4),
    2: (0, 255, 0, 0.4),
}


DEFAULT_SIZE = (480, 270)  # (w, h)


def generate_thumbnail(
        image_filepath, prediction_filepath, out_filepath,
        color_map=DEFAULT_COLOR_MAP, size=DEFAULT_SIZE
):
    """
    Generate a thumbnail with a given image and prediction by overlaying
    the two images and resizing

    Args:
        image_filepath (str): The filepath of the image
        prediction_filepath (str): The filepath of the prediction
        out_filepath (str): Where to store the generated thumbnail
        color_map (dict): Optional, the color map to apply to the prediction.
            Entries should be in the form {class: (r, g, b, a)}
        size (tuple): thumbnail size to generate in the format (width, height)
    """
    width, height = size

    # Load image and prediction and resize
    image = imageio.imread(str(image_filepath), pilmode='RGB')
    prediction = imageio.imread(str(prediction_filepath), pilmode='L')

    image = cv2.resize(image, size, interpolation=cv2.INTER_NEAREST)
    prediction = cv2.resize(prediction, size, interpolation=cv2.INTER_NEAREST)

    # With inspiration from:
    # https://github.com/BlueRiverTechnology/brt-devkit/pull/238#discussion_r491148771
    # Map the prediction pixel values using the color_map
    mapped_prediction = np.zeros(prediction.shape[0:2] + (4,), dtype='float16')
    for lclass, rgba in color_map.items():
        mapped_prediction[prediction == lclass] = rgba
    # Extract mapped prediction RGB
    prediction_rgb = mapped_prediction[..., 0:3]
    # Extract alpha, add 3rd dimension for broadcasting
    prediction_alpha = mapped_prediction[..., 3:4]
    # Vectorized blend of the prediction and the image and save
    thumbnail = ((1 - prediction_alpha) * image + prediction_alpha * prediction_rgb)
    imageio.imsave(str(out_filepath), thumbnail.astype('uint8'), check_contrast=False)
