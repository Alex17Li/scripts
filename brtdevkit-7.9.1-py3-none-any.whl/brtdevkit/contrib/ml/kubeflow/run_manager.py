#!/usr/bin/env python3
"""
Kubeflow Pipeline Run Manager.

Authors:
    Alex Jolicoeur <alex.jolicoeur@bluerivertech.com>

Copyright 2022, Blue River Technology
"""

import abc
import logging
import math
import re
import time

import boto3
import pandas as pd

from brtdevkit import config  # noqa: F401
from brtdevkit.core.api import error
from brtdevkit.ml.core import kubeflow

KUBEFLOW_STATUS_ERROR = "Error"
KUBEFLOW_STATUS_FAILED = "Failed"
KUBEFLOW_STATUS_RUNNING = "Running"
KUBEFLOW_STATUS_SUCCEEDED = "Succeeded"
KUBEFLOW_STATUSES = (
    KUBEFLOW_STATUS_ERROR,
    KUBEFLOW_STATUS_FAILED,
    KUBEFLOW_STATUS_RUNNING,
    KUBEFLOW_STATUS_SUCCEEDED,
)


class RunManager(abc.ABC):

    DEFAULT_MAX_PARALLEL_RUNS = 5  # The number of parallel runs to manage.
    DEFAULT_KFP_POLL_INTERVAL = 300  # A conservative 5 minute KFP status polling interval.

    def __init__(
        self,
        pipeline_id: str,
        base_params=None,
        callback=None,
        max_parallel_runs: int = DEFAULT_MAX_PARALLEL_RUNS,
        kfp_poll_interval: int = DEFAULT_KFP_POLL_INTERVAL,
    ):
        """
        Args:
            pipeline_id (str): The KFP pipeline ID.
            base_params (dict, optional): The base pipeline run parameters - those not included in
                the params_csv_filepath CSV.
            callback (func, optional): A callback that will be run when a pipeline run finishes.
                The parameter is a "run_detail" object, as returned by brtdevkit's
                KubeflowPipelineRun.retrieve() method.
            max_parallel_runs (int, optional): The number of parallel runs to manage.
                Defaults to DEFAULT_MAX_PARALLEL_RUNS.
            kfp_poll_interval (int, optional): The KFP API polling interval.
                Defaults to DEFAULT_KFP_POLL_INTERVAL.
        """
        # Params
        self.pipeline = kubeflow.KubeflowPipeline.retrieve(id=pipeline_id)
        self.base_params = base_params or {}
        self.callback = callback
        self.max_parallel_runs = max_parallel_runs
        self.kfp_poll_interval = kfp_poll_interval

        # Logger configuration
        logging.basicConfig()
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)

        # Data structures
        self.watchlist = []

    @abc.abstractmethod
    def create_pipeline_run(self, **kwargs):
        """Interface for pipeline run creation, since some pipelines may not
        be created through brtdevkit like below.

        Args:
            kwargs (kwargs): Kubeflow pipeline run parameters from the input CSV.

        Returns:
            str - The Run ID from the brtdevkit.ml.core.kubeflow.KubeflowPipelineRun object.
        """
        raise NotImplementedError(
            f"Children of {self.__class__.__name__} should implement this method."
        )

    @abc.abstractmethod
    def run(self):
        raise NotImplementedError(
            f"Children of {self.__class__.__name__} should implement this method."
        )


class CSVRunManager(RunManager):
    def __init__(self, params_csv_filepath: str, **kwargs):
        """
        Args:
            params_csv_filepath (str): A local filepath to a CSV containing run parameters per row.
            pipeline_id (str): The KFP pipeline ID.
            base_params (dict, optional): The base pipeline run parameters - those not included in
                the params_csv_filepath CSV.
            callback (func, optional): A callback that will be run when a pipeline run finishes.
                The parameter is a "run_detail" object, as returned by brtdevkit's
                KubeflowPipelineRun.retrieve() method.
            max_parallel_runs (int, optional): The number of parallel runs to manage.
                Defaults to DEFAULT_MAX_PARALLEL_RUNS.
            kfp_poll_interval (int, optional): The KFP API polling interval.
                Defaults to DEFAULT_KFP_POLL_INTERVAL.

        Raises:
            FileNotFoundError: If the params CSV file is not found.
        """
        # Read the input CSV into a pandas DataFrame
        self.params_df = pd.read_csv(params_csv_filepath)
        super().__init__(**kwargs)

    def run(self):
        """Run the pipeline manager. Queues and watches pipeline runs, maintaining a specified
        number of concurrent runs.
        """
        while not self.params_df.empty or (self.params_df.empty and self.watchlist):
            # The outer loop - Run until each job finishes.
            while not self.params_df.empty and len(self.watchlist) < self.max_parallel_runs:
                # The first inner loop - Create a pipeline run if there is space in the watchlist.
                # Dequeue the run parameters from the inputs DataFrame.
                run_params = dict(self.params_df.iloc[0])
                self.params_df = self.params_df[1:]
                # Create a pipeline run.
                run_id = self.create_pipeline_run(**run_params)
                self.logger.info(f"Started run: {run_id}")
                self.watchlist.append(run_id)

            # Sleep between queuing and status updates. z Z z
            self.logger.debug(f"Sleeping for {self.kfp_poll_interval}s")
            time.sleep(self.kfp_poll_interval)

            for run_id in self.watchlist:
                # The final inner loop - Check the watchlist and update run status
                run_detail = kubeflow.KubeflowPipelineRun.retrieve(id=run_id)
                time.sleep(1)  # Be polite and sleep 1s between brtdevkit API requests.
                status = run_detail["run"]["status"]
                if status == KUBEFLOW_STATUS_RUNNING:
                    continue
                if self.callback is not None:
                    # Call the run finished callback function.
                    self.callback(run_detail)
                # Update the run watchlist.
                self.watchlist.remove(run_id)
                self.logger.info(f"Run finished: {run_id} - {status}")


class SQSRunManager(RunManager):
    def __init__(self, queue_url: str, **kwargs):
        """
        Args:
            queue_url (str): The SQS Queue URL.
            pipeline_id (str): The KFP pipeline ID.
            base_params (dict, optional): The base pipeline run parameters - those not included in
                the params_csv_filepath CSV.
            callback (func, optional): A callback that will be run when a pipeline finishes.
                The parameters are a "run_id", and "status".
            max_parallel_runs (int, optional): The number of parallel runs to manage.
                Defaults to DEFAULT_MAX_PARALLEL_RUNS.
            kfp_poll_interval (int, optional): The KFP API polling interval.
                Defaults to DEFAULT_KFP_POLL_INTERVAL
        """
        # Validate the SQS queue url, and extract the region name.
        self.queue_url = queue_url
        self.queue_region, self.queue_name = self._parse_queue_url(self.queue_url)
        # Create the SQS client.
        self.sqs_client = boto3.client("sqs", region_name=self.queue_region)
        super().__init__(**kwargs)

    def requeue_pipeline_run(self, run_detail):
        """Send a message back to the queue for this failed pipeline run object.

        Args:
            run_detail (KubeflowPipelineRun): The KubeflowPipelineRun object from brtdevkit.
        """
        raise NotImplementedError(
            f"Children of {self.__class__.__name__} should implement this method."
        )

    @classmethod
    def _parse_queue_url(cls, queue_url):
        """Parse necessary metadata from the SQS Queue URL (such as the AWS region_name), and
        validate its format.

        Args:
            queue_url (str): The SQS Queue URL.

        Raises:
            ValueError: If the SQS Queue URL format is invalid.

        Returns:
            str: The AWS region_name for the SQS Queue URL.
            str: The SQS Queue name.
        """
        # https://sqs.us-west-1.amazonaws.com/123456789012/my-queue
        pattern = r"^https://sqs\.(?P<region>.+)\.amazonaws\.com/\d+/(?P<queue_name>.+)$"

        match = re.match(pattern, queue_url)
        if match is None:
            raise ValueError(f"Invalid SQS Queue URL: {queue_url}")
        return match.group("region"), match.group("queue_name")

    def _receive_message(self):
        """Receive a single message from the configured SQS queue.

        Returns:
            dict or None: the SQS message content.
        """
        # Possible boto exceptions:
        # SQS.Client.exceptions.OverLimit
        try:
            response = self.sqs_client.receive_message(
                QueueUrl=self.queue_url,
                MaxNumberOfMessages=1,
                # Use double the KFP pipeline poll interval as the initial message
                # visibility timeout.
                VisibilityTimeout=math.ceil(2 * self.kfp_poll_interval),
            )
        except self.sqs_client.exceptions.OverLimit as e:
            # Just log the exception for now.
            self.logger.exception(e)
            response = {}

        messages = response.get("Messages")
        return messages[0] if messages else None

    def _parse_message(self, message: dict):
        """Parse the SQS message body for the Kubeflow Pipeline Run parameters.

        Args:
            message (dict): The SQS message dictionary.

        Raises:
            NotImplementedError: Children of RunManager should implement this method.
        """
        raise NotImplementedError("Children of RunManager should implement this method.")

    def _delete_message(self, receipt_handle: str):
        """Delete an SQS message from the queue.

        Args:
            receipt_handle (str): The message receipt handle (associated with a Kubeflow run ID).
        """
        # Possible boto exceptions:
        # SQS.Client.exceptions.ReceiptHandleIsInvalid
        # SQS.Client.exceptions.QueueDoesNotExist
        try:
            self.sqs_client.delete_message(QueueUrl=self.queue_url, ReceiptHandle=receipt_handle)
        except (
            self.sqs_client.exceptions.ReceiptHandleIsInvalid,
            self.sqs_client.exceptions.QueueDoesNotExist,
        ) as e:
            # Just log the exception for now.
            self.logger.exception(e)

    def _run_loop_iteration(self):
        """A single loop of the ImageImportManager processor. Receives messages from the
        configured SQS queue, creates pipeline runs, and tracks their status.
        """
        # Outer loop - leasing tasks from the SQS queue.
        while len(self.watchlist) < self.max_parallel_runs:
            # First inner loop - If there is space in the pool, lease a task from SQS
            # and create a pipeline run.
            message = self._receive_message()
            if message is None:
                # Queue is empty, exit this inner loop.
                self.logger.info("The SQS queue is empty")
                break

            # ReceiptHandle is expected to exist in the SQS message.
            receipt_handle = message["ReceiptHandle"]
            run_params = self._parse_message(message)
            if run_params is None:
                continue
            self.logger.info(f"Received SQS message: {run_params}")

            try:
                # Create a pipeline run.
                run_id = self.create_pipeline_run(**run_params)
                # Delete the message from the SQS queue.
                self._delete_message(receipt_handle)
            except error.APIError as e:
                self.logger.error(f"API request error: {e}")
                continue
            self.logger.info(f"Started Kubeflow run: {run_id}")
            self.watchlist.append({"run_id": run_id, "receipt_handle": receipt_handle})

        # Sleep between queuing and status updates. z Z z
        self.logger.debug(f"Sleeping for {self.kfp_poll_interval}s")
        time.sleep(self.kfp_poll_interval)

        for run_obj in self.watchlist:
            # The final inner loop - Check the watchlist and update run status
            run_id = run_obj["run_id"]
            try:
                run_detail = kubeflow.KubeflowPipelineRun.retrieve(id=run_id)
            except error.APIError as e:
                self.logger.error(f"API request error: {e}")
                continue
            time.sleep(1)  # Be polite and sleep 1s between brtdevkit API requests.

            status = run_detail["run"]["status"]
            if status == KUBEFLOW_STATUS_RUNNING:
                continue
            if self.callback is not None:
                # Call the run finished callback function.
                self.callback(run_detail)

            # Update the run watchlist, remove the element for the current run_id.
            self.watchlist = list(filter(lambda x: x["run_id"] != run_id, self.watchlist))
            self.logger.info(f"Kubeflow run finished: {run_id} - {status}")

    def run(self):
        """Run the pipeline manager processing loop."""
        while True:
            self._run_loop_iteration()
