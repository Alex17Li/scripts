""" run_watcher.py -- Defines a Kubeflow pipeline utility class
KubeflowRunWatcher to provide programmatic access to pipeline run
properties including but not limited to:
- Run status
- Run outputs
- DAG representation

Useful for diagnosing and following pipeline runs and for
tracking run status in integration tests from Python.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivertech.com>
Copyright 2021, Blue River Technology
"""

import io
import json
import os
import re
import sys
import time
from collections import namedtuple
from contextlib import redirect_stdout
from typing import List
from urllib.error import HTTPError

from colorama import Fore

from brtdevkit.ml.core.kubeflow import KubeflowPipelineRun
from brtdevkit.util.aws.s3 import S3


# Class adapted from https://stackoverflow.com/a/15586020
class Reprinter:
    def __init__(self):
        self._text = ''

    def __moveup(self, lines):
        sys.stdout.write("\x1b[A" * lines)

    def reprint(self, text):
        # Clear previous text by overwritig non-spaces with spaces
        self.__moveup(self._text.count("\n"))
        sys.stdout.write(re.sub(r"[^\s]", " ", self._text))

        # Print new text
        lines = min(self._text.count("\n"), text.count("\n"))
        self.__moveup(lines)
        sys.stdout.write(text)
        self._text = text


# KubeflowNode: Contains node metadata for a node in the pipeline DAG
KubeflowNode = namedtuple(
    'KubeflowNode',
    'node_name template_name display_name phase children'
)


# KubeflowOutput: Contains the artifact metadata and associated node
KubeflowOutput = namedtuple(
    'KubeflowOutput',
    'node output_artifact_name s3_bucket s3_key'
)


class KubeflowRunWatcher:
    """ KubeflowRunWatcher contains various high-level API constructs to
    interact with and view the state of a pipeline run """
    def __init__(self, run_id: str):
        self._s3 = S3()
        self._run_id = run_id
        self.refresh()

    @property
    def run_id(self) -> str:
        """ run_id of the pipeline run """
        return self._run_id

    @property
    def status(self) -> str:
        """ status of the pipeline run """
        return self._run_details['run']['status']

    @property
    def nodes(self) -> List[KubeflowNode]:
        """ nodes in the pipeline run """
        return self._nodes

    @classmethod
    def pretty_print_node(cls, node):
        """ Get pretty description of the node """
        color_code = Fore.RESET
        if node.phase == 'Succeeded':
            color_code = Fore.GREEN
        elif node.phase in ('Failed', 'Error'):
            color_code = Fore.RED
        elif node.phase == 'Running':
            color_code = Fore.CYAN
        elif node.phase == 'Pending':
            color_code = Fore.YELLOW
        elif node.phase == 'Skipped':
            color_code = Fore.LIGHTBLACK_EX
        return f"{node.display_name or node.template_name} ({color_code}{node.phase}{Fore.RESET})"

    # Shamelessly taken from
    # https://github.com/kubeflow/pipelines/blob/fe6f073e4e3a7952b6c834a9c6937070391c9481/sdk/python/kfp/_client.py#L244
    @classmethod
    def _is_ipython(cls):
        """Returns whether we are running in notebook."""
        try:
            import IPython
            ipy = IPython.get_ipython()
            if ipy is None:
                return False
        except ImportError:
            return False
        return True

    def refresh(self):
        """ Refresh the stored pipeline run state from the server """
        self._run_details = KubeflowPipelineRun.retrieve(self._run_id)
        # Order matters!
        self._refresh_workflow_manifest()
        self._refresh_display_names()
        self._refresh_nodes()
        self._refresh_topological()

    def _refresh_workflow_manifest(self):
        """ Update the cached JSON parsed workflow manifest """
        self._workflow_manifest = json.loads(
            self._run_details.pipeline_runtime['workflow_manifest'])

    def _refresh_display_names(self):
        """ Update the cached display names for each template name """
        display_names = {}
        for template in self._workflow_manifest['spec']['templates']:
            name = template['name']
            _display_name = template['metadata']['annotations'].get(
                'pipelines.kubeflow.org/task_display_name', None)
            display_names[name] = _display_name
        self._display_names = display_names

    def _refresh_nodes(self):
        """ Update the cached nodes on the pipeline run """
        try:
            manifest_nodes = self._workflow_manifest['status']['nodes'].items()
        except KeyError:
            self._nodes = []
            return
        nodes = []
        for node_name, node_details in manifest_nodes:
            template_name = node_details['templateName']
            display_name = self._display_names.get(template_name, None)
            children = node_details.get('children', [])
            phase = node_details['phase']
            node = KubeflowNode(node_name, template_name, display_name, phase, children)
            nodes.append(node)
        self._nodes = nodes

    def _refresh_topological(self):
        """ Get the topological order of the nodes using DFS based algo """
        node_dict = {node.node_name: node for node in self._nodes}
        node_names = set(node_dict.keys())
        temporary_marks = set()
        permanent_marks = set()
        topological_list = []

        def visit(node_name):
            """ Subroutine to visit nodes recursively """
            if node_name in permanent_marks:
                return
            if node_name in temporary_marks:
                assert False, "Invalid DAG representation"

            temporary_marks.add(node_name)

            for child in node_dict[node_name].children:
                visit(child)

            temporary_marks.remove(node_name)
            permanent_marks.add(node_name)
            topological_list.insert(0, node_dict[node_name])

        while len(permanent_marks) < len(node_names):
            node_to_visit = next(iter((node_names - permanent_marks)))
            visit(node_to_visit)
        self._topological_sort = topological_list

    def show_topological(self):
        # The root node represents the overall pipeline
        if len(self._topological_sort) == 0:
            print(
                "Pipeline has not started... "
                "Try again in a few seconds or check its status on Kubeflow"
            )
            return
        print(f'Pipeline: {self.pretty_print_node(self._topological_sort[0])}')
        if len(self._topological_sort) > 1:
            print('Topological Sort of Pipeline Steps:')
            for i, node in enumerate(self._topological_sort[1:], 1):
                print(f'{i}. {self.pretty_print_node(node)}')

    def follow_topological(self, polling_interval_s=10, num_retries=5):
        polling_interval_s = max(polling_interval_s, 3)
        is_ipython = self._is_ipython()
        if is_ipython:
            from IPython.display import clear_output
        else:
            reprinter = Reprinter()
        ellipses = ''
        start = time.time()
        while True:
            ellipses = (ellipses + '.') if len(ellipses) < 10 else '.'
            with io.StringIO() as ostream, redirect_stdout(ostream):
                self.show_topological()
                out = ostream.getvalue()
            duration = int(time.time() - start)
            out = (
                f"Following Kubeflow Run {self._run_id}{ellipses}\n"
                f"{out}"
                f"Time Watching: {duration}s\n"
            )
            if is_ipython:
                clear_output(wait=True)
                print(out)
            else:
                reprinter.reprint(out)
            if self.status in ('Succeeded', 'Failed', 'Error'):
                break
            time.sleep(polling_interval_s)
            try:
                self.refresh()
            except HTTPError as e:
                num_retries = num_retries - 1
                if num_retries == 0:
                    raise e
                print(f"Attempt # {num_retries}: Following Kubeflow Run {self._run_id}")

    def retrieve_s3_outputs(
            self, node_name: str = None, template_name: str = None,
            display_name: str = None, output_artifact_name: str = None
    ) -> List[KubeflowOutput]:
        """ Retrieve the S3 outputs of the pipeline run. Filter the outputs using the
        optional arguments.
        Args:
            node_name (str): If provided, will match on the node name (node ID)
            template_name (str): If provided, will match on the template name
            display_name (str): If provided, will match on the display name
            output_artifact_name (str): If provided, will match on the artifact name
        Returns:
            Filtered list of type KubeflowOutput
        """
        outputs = []

        s3_bucket = (self._workflow_manifest['status']
                     ['artifactRepositoryRef']
                     ['artifactRepository']
                     ['s3']
                     ['bucket'])

        for node in self._nodes:
            try:
                node_details = self._workflow_manifest['status']['nodes'][node.node_name]
                for artifact in node_details['outputs']['artifacts']:
                    try:
                        _output_artifact_name = artifact['name']
                        s3_key = artifact['s3']['key']
                        output = KubeflowOutput(node, _output_artifact_name, s3_bucket, s3_key)
                        outputs.append(output)
                    except KeyError:
                        # The output artifact's S3 location is not populated
                        # This can happen if the artifact is declared in the
                        # pipeline step but not populated by the step code.
                        pass
            except KeyError:  # The node has not completed or has no output artifacts
                pass

        filtered_outputs = []
        for output in outputs:
            if (
                (node_name and node_name != output.node.node_name)
                or (template_name and template_name != output.node.template_name)  # NOQA
                or (display_name and display_name != output.node.display_name)  # NOQA
                or (output_artifact_name and output_artifact_name != output.output_artifact_name)  # NOQA
            ):
                continue
            filtered_outputs.append(output)
        return filtered_outputs

    def download_output(self, output: KubeflowOutput, filename: os.PathLike) -> bool:
        """ Download an output to a file.
        Args:
            output (KubeflowOutput): The output to download
            filename (os.PathLike): The path to download the output to
        Returns:
            Boolean, True if download successful, False if not
        """
        return self._s3.download_file(output.s3_bucket, output.s3_key, filename)
