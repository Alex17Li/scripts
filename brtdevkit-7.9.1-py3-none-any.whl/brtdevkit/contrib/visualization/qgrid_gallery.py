"""
Author: Tim Roberts <timothy.roberts@bluerivertech.com>

Copyright 2020, Blue River Technology
"""

import base64
import os

import cv2
import qgrid
from IPython.display import Javascript, display

ORIG_IMAG = "orig_image"
SAVE_PATH_ARTIFACTS = "save_path_artifacts"


def load_compress(filepath, scale_percent=.05):
    """
    Read an image file and stringify its resized jpeg representation.

    Args:
        filepath (`str`): image filepath.
        scale_percent (`float`): a number in (0, 1] that represents the
            percentage of the original image height/width to shrink the image to.

    Returns:
        `bytestring`: base-64 byte-string encoding of image.
    """
    try:
        img = cv2.imread(filepath)

        if img is None:
            print("second try")
            img = cv2.imread(os.path.expanduser("~/" + filepath))

    except Exception:
        try:
            img = cv2.imread(os.path.expanduser("~/" + filepath))
        except Exception:
            return b""

    if img is None:
        return b""
    width = int(img.shape[1] * scale_percent)
    height = int(img.shape[0] * scale_percent)
    dim = (width, height)
    resized = cv2.resize(img, dim, interpolation=cv2.INTER_NEAREST)
    is_success, im_buf_arr = cv2.imencode(".jpg", resized)
    byte_im = im_buf_arr.tobytes()
    return base64.b64encode(byte_im).decode()


class QGridGallery:
    """
    A class composing a standard :class:`qgrid.qgrid` and a functionality to render
    images and links in the context of the qgrid table view.
    """

    def __init__(
        self, df,
        display_columns=None, image_path_columns=None, link_path_columns=None,
        hyper_path_prefix=None
    ):
        """
        Args:
            image_path_columns (`list` of `str`): The names of columns containing
                base64-encoded image bytestrings,
                to be turned into embedded HTML images.
                See the return value of :meth:`load_compress`.
            link_path_columns (`list` of `str`): The names of columns containing
                paths that should be turned into HTML links.
            hyper_path_prefix (`str`): prefix to be added to all hyperlinked paths. Note:
                in some cases it is necessary to use "./files/" for Jupyterlab
                notebook paths to work correctly
        """
        if not display_columns:
            display_columns = list(df.columns)

        self._image_columns = []
        self._image_path_columns = image_path_columns if image_path_columns else []
        self._link_path_columns = link_path_columns if link_path_columns else []
        self._hyper_path_prefix = hyper_path_prefix or ""
        self._df = df.copy()

        # augment the input dataframe with blank binar-data image columns
        if self._image_path_columns:
            for ipc in self._image_path_columns:
                new_img_col = ipc + "_image"
                self._image_columns.append(new_img_col)
                self._df.loc[:, new_img_col] = b""

        # put images then images/links at the end
        display_columns_trunc = set(display_columns) - (
            set(self._image_columns) | set(self._image_path_columns) | set(self._link_path_columns)
        )
        display_columns_trunc = [el for el in display_columns if el in display_columns_trunc]
        self._display_columns = display_columns_trunc + (
            self._image_columns + self._image_path_columns + self._link_path_columns
        )

        # Set widget properties and handler
        qgrid_widget = qgrid.show_grid(
            self._df[self._display_columns], show_toolbar=False,
            grid_options={
                'forceFitColumns': True, 'rowHeight': 100,
                'highlightSelectedCell': True, 'maxVisibleRows': 5
            },
            column_options={'maxWidth': 150}
        )
        handler = self.get_qgrid_handler_fun()
        qgrid_widget.on("viewport_changed", handler)

        self.qgrid_widget = qgrid_widget

    def get_qgrid_image_js(self):
        """
        Render the JavaScript necessary to
        replace QGrid base64-encoded image column(s) with image-rendering html,
        and QGrid artifact column(s) with link-rendering html.

        Returns:
            :class:`Ipython.display.Javascript`: Rendered Javascript.
        """
        def image_formatter(col):
            return """
                if (x.id === '%s') {
                    x.formatter = (r, c, v, cd, dc) =>
                    (v = "<img src=%s" + v + "%s></img>");
                }
            """ % (col, "'data:image/jpeg;base64,", "'")

        def path_formatter(col, link_text):
            return """
                if (x.id === '%s') {
                    x.formatter = (r, c, v, cd, dc) =>
                    (v = "<a href='%s" + v + "'%s>%s</a>");
                }
            """ % (col, self._hyper_path_prefix, " target='_blank'", link_text)

        js_str = """\
        window.slick_grid.setColumns(window.slick_grid.getColumns().map(x => {
            %s
            %s
            %s
            return x
        }));
        """ % (
            "".join([image_formatter(col) for col in self._image_columns]),
            "".join([path_formatter(col, "Image") for col in self._image_path_columns]),
            "".join([path_formatter(col, "Artifact") for col in self._link_path_columns]),
        )
        javascript = Javascript(js_str)
        return javascript

    def get_qgrid_handler_fun(self):
        """
        Creates a callback function for a qgrid widget that updates the visible portion of the
        widget's underlying dataframe by converting image path columns to image bytestrings.

        Args:
            image_columns (`list` of `str`): list of column names that contain image data.

        Returns:
            `function`: a qgrid event callback.
        """
        image_columns = list(self._image_columns)

        def handler(event, qgrid_w):
            try:
                df_tmp = qgrid_w.get_changed_df()
                start, end = event.get("new")
                start_pad, end_pad = max(0, start - 5), min(len(df_tmp), end + 5)
                for image_col in image_columns:
                    empty = df_tmp.iloc[start_pad:end_pad].loc[:, image_col].apply(lambda x: len(x) == 0)
                    # setting 'df' attribute, as suggested in the docs, leads to indexing errors...
                    eix = qgrid_w._df.index.isin(empty.index)  # NOQA
                    qgrid_w._df.loc[eix, image_col] = df_tmp.loc[eix, SAVE_PATH_ARTIFACTS].apply(load_compress)
                display(self.get_qgrid_image_js())
            except Exception as e:
                print(e)

        # Ensure that this handler is only registered at the widget level, not the module level.
        qgrid.off("All", handler)
        return handler

    def show(self):
        """
        Display this widget in a Jupyter notebook.
        """
        display(self.qgrid_widget)
        display(self.get_qgrid_image_js())
