"""
Utilities for interacting with the Labelbox graphQL API.

Author: Christian Howes <christian.howes@bluerivert.com>
Copyright 2020, Blue River Technology
"""
import json
import time
from typing import List

from graphqlclient import GraphQLClient

from brtdevkit.util.logger import Logger

log = Logger('LabelboxContrib')

GET_RECENT_LABELS_FOR_DATASET = """
query GetRecentLabelsForDataset($datasetId: ID!, $minUpdated: DateTime!,
                                $maxUpdated: DateTime!,
                                $skip: Int!, $first: PageSize!){
  dataset(where:{id: $datasetId}){
    dataRows(skip: $skip, first: $first,
             where:{labels_some:{updatedAt_gte: $minUpdated,
                                 updatedAt_lte: $maxUpdated}}){
      id
      createdAt
      externalId
      labels {
        id
        createdAt
        updatedAt
      }
    }
  }
}
"""

GET_DATASET_IDS = """
query GetDatasets($skip: Int!, $first: PageSize!){
  datasets(skip: $skip, first: $first){
    id
  }
}
"""


class LabelboxClient:
    """
    A wrapper around a GraphQL client connected to Labelbox.
    """
    LABELBOX_API_ENDPOINT = 'https://api.labelbox.com/graphql'

    def __init__(self, labelbox_api_key: str):
        """
        Create the GraphQL connection.

        The user must provide their own Labelbox API key. Currently
        (21-May-2020) Labelbox only supports API keys with admin level access.
        Please be careful with your keys!!

        Follow instructions
        https://labelbox.com/docs/api/getting-started#create_api_key to
        create your API key.
        """
        # Create the GraphQL Client.
        self.client = GraphQLClient(self.LABELBOX_API_ENDPOINT)
        self.client.inject_token(f'Bearer {labelbox_api_key}')

    def graphql_request(self, query_str: str, args: dict = None,
                        max_retries: int = 3, retry_count: int = 0):
        """
        A wrapper for GraphQLClient.execute() that includes retry logic in the
        event that the GraphQL request fails.

        Args:
            query_str (str): The GraphQL query string.
            args (dict): The arguments to inject into the GraphQL
                query string.
            max_retries (int): The maximum number of times to retry
                the request.
            retry_count (int): The current retry iteration count.
        Returns:
            dict: successful GraphQL API response, otherwise :const:`None`
                if there were errors in the GraphQL query request.
        Raises:
            IOError: If the maximum number of retries was reached without a
                successful response.
        """
        args = args or {}
        try:
            res_str = self.client.execute(query_str, args)
        # Check for a client disconnect, timeout, or rate-limiting exception.
        except IOError as e:
            # Retry the request, if allowed, otherwise raise an IOError.
            if retry_count <= max_retries:
                time.sleep(retry_count ** 2)
                return self.graphql_request(query_str, args,
                                            retry_count + 1, max_retries)
            else:
                raise e

        res = json.loads(res_str)
        if 'errors' in res.keys():
            log.error(f"GraphQL Request Error: {query_str}\n{res['errors'][0]['message']}")
            # This will trigger if the GraphQL query itself had errors.
            return None
        return res

    def paginated_graphql_request(self, query_str: str, args: dict = None,
                                  results_path: List[str] = None):
        """
        Given a query with `skip` and `first` params, fetch and return
        results. This acts as a generator function, and will return 1 result
        at a time, fetching new pages from the server as needed.

        Args:
            query_str (str): The GraphQL query string. Must include $skip and
                $first arguments.
            args (dict, default=None): The arguments to inject into the GraphQL
                query string.
            results_path (list(str), default=[]): The keys to dereference from
                the query results to return each row.
        Yields:
            dict: A result row.
        """
        skip = 0
        PAGE_SIZE = 100  # Max page size as specified by Labelbox.
        args = args or {}  # Make a new empty dict if None was specified.
        args['first'] = PAGE_SIZE

        while True:
            args['skip'] = skip
            res = self.graphql_request(query_str, args)

            if res.get('data'):
                rows = res['data']
                for path in results_path or []:
                    # if rows[path] is None, use an empty dict instead.
                    rows = rows.get(path) or {}
            else:
                # No data was returned
                break

            if len(rows) == 0:
                # No more data
                break

            log.debug(f'paginated_graphql_request just got {len(rows)} rows')
            for row in rows:
                yield row
            skip += PAGE_SIZE
