"""
The keys expected to be present in a training or testing sample.
Notice that such a sample is a `dict` and `SampleKeys`
is simply saying what the keys of that dict should contain.

Author: BRT CVML <shasta-cvml@bluerivert.com>
Copyright 2020, Blue River Technology
"""
from enum import Enum


class SampleKeys(str, Enum):
    """
    A torch training sample is a dictionary with these keys.
    """

    image = 'image'
    label = 'label'
    img_id = 'img_id'
    prediction = 'prediction'
