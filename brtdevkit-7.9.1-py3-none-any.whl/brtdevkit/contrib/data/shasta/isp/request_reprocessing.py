"""
DEPRECATED: See MESASW-1502

Wrappers and utilities to interact with ISP Reprocessing Queues.
Includes functions to submit and receive reprocessing requests.
Author: Ajay Penmatcha <ajay.penmatcha@bluerivertech.com>
Copyright 2021, Blue River Technology
"""

import functools
import json
from enum import Enum

import boto3

from brtdevkit import config
from brtdevkit.util.aws import AWS_PROJECT_ID, AWS_REGION_DEFAULT


@functools.total_ordering
class ISPQueueName(Enum):
    """ Enumeration of SQS queue names for ISP processing. One queue
    per priority per environment. Environment determined automatically
    from current config. """
    LOW_PRIORITY = f'isp_low_priority_{config.ENV}'
    MEDIUM_PRIORITY = f'isp_medium_priority_{config.ENV}'
    HIGH_PRIORITY = f'isp_high_priority_{config.ENV}'

    # Define order from low -> high priority
    def __lt__(self, b, priority_values={
        LOW_PRIORITY: 0,
        MEDIUM_PRIORITY: 1,
        HIGH_PRIORITY: 2
    }):
        return priority_values[self.value] < priority_values[b.value]


class ISPReprocessRequestManager:
    """ ISP queue utility to send and receive ISP reprocess requests. """
    def __init__(
            self, queue: ISPQueueName, region: str = AWS_REGION_DEFAULT,
            aws_access_key_id: str = None, aws_secret_access_key: str = None,
            override_queue_url: str = None
    ):
        """ Initialize an ISPReprocessRequestManager object.
        Args:
            queue (ISPQueueName): The queue name to initialize with
            region (str): The AWS region the queue is in
            aws_access_key_id (str): AWS Access Key ID to use for queue connection.
                If not provided, will use default brtdevkit credentials.
            aws_secret_access_key (str): AWS Secret Access Key to use for queue connection.
                If not provided, will use default brtdevkit credentials.
            override_queue_url (str): Manually set the queue URL instead of inferring it
                from other parameters
        """
        self.queue_url = override_queue_url or \
            f'https://sqs.{region}.amazonaws.com/{AWS_PROJECT_ID}/{queue.value}'

        self.sqs = boto3.client(
            'sqs',
            region_name=region,
            aws_access_key_id=aws_access_key_id or config.Credentials.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=aws_secret_access_key or config.Credentials.AWS_SECRET_ACCESS_KEY,
        )

    def request_reprocessing(self, image_id: str, target_rom_version: str):
        """ Send an ISP reprocess request to the queue.
        Args:
            image_id (str): The Aletheia image ID to reprocess
            target_rom_version (str): The ISP ROM to reprocess to
        Returns:
            dict: The SQS response
        """
        assert image_id and isinstance(image_id, str)
        assert target_rom_version and isinstance(target_rom_version, str)
        return self.sqs.send_message(
            QueueUrl=self.queue_url,
            MessageBody=json.dumps({
                'image_id': image_id,
                'target_rom_version': target_rom_version
            }),
            DelaySeconds=0,
        )
