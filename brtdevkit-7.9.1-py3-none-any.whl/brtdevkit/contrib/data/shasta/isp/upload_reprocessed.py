"""
Functionality to enforce constaints on how ISP reprocessed images will be uploaded
back to Mesa as defined here:

https://docs.google.com/document/d/1Hy5FuIY1-jiQhM_BaCZ2HJAHJ23bxqiX-M9wP4V4YFY/

Author: Taylor Ritenour <taylor.ritenour@bluerivertech.com>

Copyright 2020, Blue River Technology
"""

import hashlib
from datetime import datetime

import dateutil.parser
import PIL.Image

from brtdevkit.data import Image, ImageGroup
from brtdevkit.util import logger

log = logger.Logger('ISP Reprocessing')


MAX_CHUNK_LENGTH = 64 * 1024  # 64KiB
DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"


def make_content_hash(filepath):
    """Get the content hash for the Image file.

    Returns:
        str - The MD5 hash for the Image file.
    """
    md5 = hashlib.md5()
    with open(filepath, 'rb') as image_file:
        # Read in chunks of 64MB.
        for chunk in iter(lambda: image_file.read(MAX_CHUNK_LENGTH), b''):
            md5.update(chunk)
    return md5.hexdigest()


def get_image_size(image_filepath):
    """Get the image size

    Returns:
        width: width of the image
        height: height of the image
    """
    image = PIL.Image.open(image_filepath)
    # image.size is in the order of width, height.
    return image.size


def upload_reprocessed_image(filepath, raw_image_id, revision):
    """Add the reprocessed image defined at filepath to the group of images as defined by

    https://docs.google.com/document/d/1Hy5FuIY1-jiQhM_BaCZ2HJAHJ23bxqiX-M9wP4V4YFY/

    Args:
        filepath (str): path to the reprocessed image
        raw_image_id (str): ID of the Image model that the RAW image was processed from
        revision (str): The new ISP version name

    Returns:
        Boolean whether upload was completed or not

    Raises:
        brtdevkit.core.api.error.BadRequestError if missing raw_image or associated group
    """
    log.info(f"Adding ISP version {revision} for {filepath}")

    orig_raw_img = Image.retrieve(raw_image_id)
    image_group_data = ImageGroup.retrieve(orig_raw_img['group_id'])

    # Check if there is an image with isp artifacts already in the group for the raw uuid you processed.
    isp_processing_image = next((x for x in image_group_data['data']
                                 if x.get('processing_type') == 'ISP' and x.get('uuid') == orig_raw_img.get('uuid')),
                                None)
    if isp_processing_image:
        same_isp_version_artifact = next((x for x in isp_processing_image['artifacts']
                                          if x.get('revision') == revision), None)
        if same_isp_version_artifact:
            log.info(
                f"ISP Version {revision} has already been uploaded for this image group. Skipping")
            return False

    resp_data = Image.upload_artifact_image(filepath)
    width, height = get_image_size(filepath)

    new_artifact_data = {
        "kind": 'nrg',
        "content_hash": make_content_hash(filepath),
        "s3_key": resp_data['s3_key'],
        "s3_bucket": resp_data['s3_bucket'],
        "web_s3_key": resp_data['s3_key'],
        "web_s3_bucket": resp_data['s3_bucket'],
        "width": width,
        "height": height,
        "processed_at": datetime.strftime(datetime.utcnow(), DATETIME_FORMAT),
        "processing_type": 'ISP',
        "revision": revision,
    }

    if isp_processing_image:
        # Add onto the existing ISP image
        Image.add_artifact(isp_processing_image['id'], **new_artifact_data)
    else:
        # Create the new image
        new_image_dict = orig_raw_img.to_dict()
        new_image_dict.pop('id', None)
        new_image_dict.pop('created_by', None)
        new_image_dict['collected_on'] = datetime.strftime(dateutil.parser.isoparse(new_image_dict['collected_on']), DATETIME_FORMAT)
        new_image_dict['mesa_version'] = "ISP_REPROCESSING"
        new_image_dict['annotations'] = []
        new_image_dict['type'] = 'nrg'
        new_image_dict['processing_type'] = 'ISP'
        new_image_dict['artifacts'] = [x for x in new_image_dict['artifacts'] if x['kind'] == 'raw']
        new_image_dict['artifacts'][0]['processing_type'] = 'ISP'
        new_image_dict['artifacts'].append(new_artifact_data)
        # Let any ID fields on the artifacts be populated by the DB
        for artifact in new_image_dict['artifacts']:
            artifact.pop('id', None)
            artifact.pop('_id', None)

            # This library cannot assume that all fields returned in the GET can be used in
            # the POST, for these artifact objects as well as objects like images or
            # annotations.
            #
            # As a short term fix, these are the fields that are causing issues.
            # In the longer term, what fields are allowed or not needs to be documented.
            for field in ['image', 'updated_at', 'created_at', 'project_name', 'web_url']:
                artifact.pop(field, None)
        # TODO: Check that all objects only have fields that are allowed by the POST API call
        Image.create(**new_image_dict)
    return True
