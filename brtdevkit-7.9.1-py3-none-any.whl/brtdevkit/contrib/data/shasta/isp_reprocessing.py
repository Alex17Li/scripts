# Maintain this import location until the next major release
# when it should be deprecated

import warnings

warnings.simplefilter('always', DeprecationWarning)
warnings.warn(
    ("This import location will be removed in a future release. "
     "Import via brtdevkit.contrib.data.shasta.isp.upload_reprocessed"),
    DeprecationWarning
)

from .isp.upload_reprocessed import *  # NOQA
