"""
Shasta CVML Default Pixel Values per class.

Author: BRT CVML <shasta-cvml@bluerivert.com>
Copyright 2020, Blue River Technology
"""
from enum import IntEnum, unique


@unique
class PixelVal(IntEnum):
    DIRT = 0
    WEED = 1
    CROP = 2

    @classmethod
    def num_classes(cls):
        return len(cls)
