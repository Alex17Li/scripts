## Shasta High-res Image Alignment

Contents:
- Overview
- Alignment algorithm
- Requesting alignment
- Processing an alignment request

### Overview
High-res image alignment is designed to provide a version of the high-res DCM image that
is aligned to the NRG DCM image, which is the image labelers label. The aligned high-res
image offers better context than the non-aligned image as a helper artifact during
labeling. The utilities here and the infrastructure managed by Shasta implement the
necessary components to request and perform high-res alignment at scale.

### Alignment algorithm
See [alignment.py](./alignment.py) for details. The alignment algorithm is invoked via
align_image_using_subregions_where_possible().

A version identifier named \_\_version\_\_ is contained in the alignment&#46;py file. The
identifier is used to determine whether for a given alignment request, if an existing
high-res-aligned image of the latest version exists. If it does, the request can be
skipped to avoid duplication. Therefore, \_\_version\_\_ should be bumped anytime a
change to the alignment algorithm is made which a user would want to result in a new
high-res-aligned artifact should it be requested even if a high-res-aligned artifact of
the previous version already existed. There is currently no logic which depends
specifically on the major, minor or patch numbers.

### Requesting alignment
See [request_alignment.py](./request_alignment.py) for details. Request alignment via
`AlignmentRequestManager`. Example:
```
from brtdevkit.contrib.data.shasta.image_alignment.request_alignment import AlignmentRequestManager
request_manager = AlignmentRequestManager()
request_manager.request_alignment(
    'nrg_image_id',
    # See optional parameters in the docstring
)
```

### Processing an alignment request
See [process_alignment_request.py](./process_alignment_request.py) for details.
Alignment request processing should normally happen via the Shasta Lambda function.
However, there are some cases where it can be useful to test the processing code locally.
Users can invoke `process_request()` with a sample request dictionary to run alignment,
validation, and upload locally.

Also see: https://gerrit.bluerivertech.com/plugins/gitiles/shasta/+/refs/heads/master/brt/ingest/alignment/

Linked from: https://gerrit.bluerivertech.com/plugins/gitiles/shasta/+/refs/heads/master/brt/ingest/alignment/README.md
