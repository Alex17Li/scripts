"""
Utility class to interact with High-Res alignment queues.
Includes functions to submit and process reprocessing requests.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivertech.com>
Copyright 2021, Blue River Technology
"""

import json
from typing import Optional

import boto3

from brtdevkit.core import BadRequestError
from brtdevkit.data import Image, ImageGroup

from .alignment import __version__ as alignment_version

_DEFAULT_JPG_COMPRESSION_QUALITY = 90
_MINIMUM_JPG_COMPRESSION_QUALITY = 75


class AlignmentRequestError(Exception):
    pass


class AlignmentRequestManager:
    """ Alignment queue utility to send high-res alignment requests. """

    default_queue_url = 'https://sqs.us-west-2.amazonaws.com/759721480024/alignment'

    def __init__(self, override_queue_url: str = None):
        """
        Initialize an AlignmentRequestManager object.

        Args:
            aws_access_key_id (str): AWS Access Key ID to use for queue connection.
                If not provided, will use default brtdevkit credentials.
            aws_secret_access_key (str): AWS Secret Access Key to use for queue connection.
                If not provided, will use default brtdevkit credentials.
            override_queue_url (str): Override the default alignment queue URL for testing purposes
        """
        self.queue_url = override_queue_url or self.default_queue_url
        self.sqs = boto3.client('sqs', region_name='us-west-2')

    def request_alignment(
            self, nrg_image_id: str, high_res_corrected_artifact_id: Optional[str] = None,
            jpg_compression_quality: Optional[float] = None, alignment_parameters: Optional[dict] = None):
        """
        Send an alignment request to the queue.
        *See validate_alignment_request() docstring for additional request parameter details*

        Args:
            nrg_image_id (str): The Aletheia nrg image ID to align to
            high_res_corrected_artifact_id (str): Optionally specify which artifact to align
            jpg_compression_quality (int): Optional JPG compression quality of aligned artifact in range 0-100
            alignment_parameters (dict): Optional parameters to send to alignment fn.

        Returns:
            dict: The SQS response
        """
        request_dict = {
            'nrg_image_id': nrg_image_id,
            'high_res_corrected_artifact_id': high_res_corrected_artifact_id,
            'jpg_compression_quality': jpg_compression_quality,
            'alignment_parameters': alignment_parameters
        }
        request_dict = {k: v for k, v in request_dict.items() if v is not None}
        request_dict, _ = self.validate_alignment_request(request_dict, add_missing=True)

        return self.sqs.send_message(
            QueueUrl=self.queue_url,
            MessageBody=json.dumps(request_dict),
            DelaySeconds=0,
        )

    @classmethod
    def validate_alignment_request(cls, request_dict: dict, add_missing: bool = True):
        """
        An alignment request comes in the form of:
        {
            "nrg_image_id": <Aletheia NRG image ID> (Required),
            "high_res_corrected_artifact_id":
                <ID of the high res corrected artifact to align>
                (Optional, can be inferred with add_missing=True. Will be inferred to any of the
                high_res_corrected kind artifacts on the image group of the nrg image),
            "jpg_compression_quality":
                <Quality 0-100 with which to save the aligned high-res JPEG>
                (Optional, defaults to _DEFAULT_JPG_COMPRESSION_QUALITY with add_mising=True)
            "alignment_parameters":
                <dictionary of kwargs to pass to alignment fn> (Optional, defaults to {} with add_missing=True)
        }
        This function validates the request by checking:
        1. All required values exist
        2. The artifacts exist in the proper configuration on Aletheia
        3. Filling in missing request parameters if add_missing is specified.

        Args:
            request_dict (dict): The unvalidated request dictionary
            add_missing (bool): Add missing request parameters

        Returns:
            (dict | (Image, Image)) - Returns a tuple of the validated request dictionary and a
                                    tuple of the NRG Image and high-res-corrected artifact Image.
        """

        # Extract request paramters from the dictionary
        nrg_image_id = request_dict['nrg_image_id']
        high_res_corrected_artifact_id = request_dict.get('high_res_corrected_artifact_id', None)
        jpg_compression_quality = request_dict.get('jpg_compression_quality', None)
        alignment_parameters = request_dict.get('alignment_parameters', None)

        # Get the NRG image and verify it has an NRG artifact
        try:
            nrg_image = Image.retrieve(nrg_image_id)
        except BadRequestError as e:
            raise AlignmentRequestError(f'Could not retrieve image {nrg_image_id}') from e
        if not any([artifact['kind'] == 'nrg' for artifact in nrg_image['artifacts']]):
            raise AlignmentRequestError(f'nrg_image_id {nrg_image_id} has no artifact of kind nrg')

        # Get the other images in the NRG image group and get the high res corrected artifact(s)
        group_images = ImageGroup.retrieve(nrg_image.group_id)['data']
        high_res_artifacts = [
            artifact for image in group_images
            for artifact in image['artifacts']
            if artifact['kind'] == 'high_res_corrected'
        ]
        if len(high_res_artifacts) == 0:
            raise AlignmentRequestError(
                f'artifact of kind high_res_corrected not found in group {nrg_image.group_id}')

        # See if the requested artifact ID exists, otherwise default to the last eligible artifact in the list
        if high_res_corrected_artifact_id:
            if not any([artifact['_id'] == high_res_corrected_artifact_id for artifact in high_res_artifacts]):
                raise AlignmentRequestError(
                    f'artifact of kind high_res_corrected and id {high_res_corrected_artifact_id} '
                    f'not found in group {nrg_image.group_id}')
        elif add_missing:
            request_dict['high_res_corrected_artifact_id'] = high_res_artifacts[-1]['_id']
        else:
            raise AlignmentRequestError(
                'high_res_corrected_artifact_id unspecified. Use add_mising=True to fill in with default.')

        # Validate JPG compression quality
        if jpg_compression_quality:
            if not isinstance(jpg_compression_quality, int):
                raise AlignmentRequestError('jpg_compression_quality must be of type int')
            if jpg_compression_quality < _MINIMUM_JPG_COMPRESSION_QUALITY:
                raise AlignmentRequestError(f'jpg_compression_quality must be at least {_MINIMUM_JPG_COMPRESSION_QUALITY}')
        elif add_missing:
            request_dict['jpg_compression_quality'] = _DEFAULT_JPG_COMPRESSION_QUALITY
        else:
            raise AlignmentRequestError(
                'jpg_compression_quality unspecified. Use add_missing=True to fill in with default.')

        # Validate alignment parameters
        if alignment_parameters:
            if not isinstance(alignment_parameters, dict):
                raise AlignmentRequestError('alignment_parameters must be of type dict')
        elif add_missing:
            request_dict['alignment_parameters'] = {}
        else:
            raise AlignmentRequestError('alignment_parameters unspecified. Use add_missing=True to fill in with default.')

        # Retrieve the high-res-corrected image API object
        high_res_image_id = next(
            image['id'] for image in group_images
            if any([artifact['_id'] == request_dict['high_res_corrected_artifact_id'] for artifact in image['artifacts']]))
        high_res_image = Image.retrieve(high_res_image_id)

        desired_artifact_metadata = {
            'aligned_to_artifact_ID': request_dict['high_res_corrected_artifact_id'],
            'alignment_version_for_lucid_tri200s_cc': alignment_version,
        }
        try:
            existing_aligned = next(
                artifact for image in group_images
                for artifact in image['artifacts']
                if artifact.get('metadata', {}).items() >= desired_artifact_metadata.items()
            )
            raise AlignmentRequestError(
                f'Existing aligned artifact found {existing_aligned["_id"]} with metadata {desired_artifact_metadata}')
        except StopIteration:
            existing_aligned = None

        return request_dict, (nrg_image, high_res_image)
