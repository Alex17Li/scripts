"""
Tools to align a pair of images (for example to align a high res DCM image to a AR233 NRG DCM
image captured concurrently).

To align the 2021 high res images (from Lucid TRI200S-CC) to AR233 NRG, use the function
'align_image_using_subregions_where_possible'.

TODO (Ben): for identifying 'bad' homographies, it would be better to use homography decomposition.

Author: Ben Cline <ben.cline@bluerivertech.com>
Copyright 2021, Blue River Technology
"""
from functools import partial

import cv2
import numpy as np
import pandas as pd

# Update this when algorithm changes affecting the output are made
__version__ = '1.0.0'


def get_sift_keypoints_and_matches(im1, im2, n_features):
    """ Create keypoints using SIFT, and find matches with brute force matcher.

    Args:
        im1 (np.ndarray): image to be aligned.
        im2 (np.ndarray): target image.
        n_features (int): number of features to retain.

    Returns:
        keypoints1 (list[cv2.KeyPoint]): list of keypoints corresponding to im1
        keypoints2 (list[cv2.KeyPoint]): list of keypoints corresponding to im2
        matches (list[cv2.DMatch]): list of matches
    """
    im1Gray = cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY)
    im2Gray = cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY)

    sift = cv2.SIFT_create(n_features)

    keypoints1, descriptors1 = sift.detectAndCompute(im1Gray, None)
    keypoints2, descriptors2 = sift.detectAndCompute(im2Gray, None)

    if (descriptors1 is None) or (descriptors2 is None):
        matches = []
    else:
        matcher = cv2.BFMatcher.create(normType=cv2.NORM_L2)
        matches = matcher.match(descriptors1, descriptors2)

    return keypoints1, keypoints2, matches


def filter_matches_by_ratio(matches, ratio):
    """ Identify good matches, based on lower distance to the train keypoint
    than other matches with the same train keypoint. As proposed by Lowe 2004
    in Distinctive Image Features from Scale-Invariant Keypoints (used ratio of
    0.8).

    Args:
        matches (list[cv2.DMatch]): list of matches

    Returns:
        selected_matches (list[cv2.DMatch]): list of filtered matches
    """
    def filter_group(df, ratio):
        # When we have just a single match for the point, keep the match
        if len(df) == 1:
            return df
        else:
            df = df.sort_values('distance', ascending=True)
            if df['distance'].iloc[0] < ratio * df['distance'].iloc[1]:
                return df.head(1)  # good match
            else:
                return df.iloc[:0]  # empty df
    df = pd.DataFrame(matches, columns=['match'])
    df['distance'] = df.match.apply(lambda x: x.distance)
    df['trainIdx'] = df.match.apply(lambda x: x.trainIdx)
    df['queryIdx'] = df.match.apply(lambda x: x.queryIdx)
    filtered = df.groupby('trainIdx').apply(lambda x: filter_group(x, ratio))
    selected_matches = filtered['match'].tolist()
    return selected_matches


def filter_matches_by_distance(matches, keypoints1, keypoints2, threshold_distance):
    """ Identify good matches, based on assumption that keypoints should be in a similar
    region of each image to be a desirable match.

    Args:
        keypoints1 (list[cv2.KeyPoint]): list of keypoints corresponding to im1
        keypoints2 (list[cv2.KeyPoint]): list of keypoints corresponding to im2
        matches (list[cv2.DMatch]): list of matches
        threshold_distance (int | float): maximum distance between two keypoints
            in pixels

    Returns:
        selected_matches (list[cv2.DMatch]): list of filtered matches
    """
    selected_matches = []
    for i, match in enumerate(matches):
        points1 = keypoints1[match.queryIdx].pt
        points2 = keypoints2[match.trainIdx].pt
        dist = np.sqrt((points1[0] - points2[0])**2 + (points1[1] - points2[1])**2)
        if dist < threshold_distance:
            selected_matches.append(match)
    return selected_matches


def get_scale_factors_for_corners(H, width, height):
    """ Find the scale factor to convert the four corners of an image from homogenous to
    Euclidean space. Can be used as part of an ad hoc approach to identifying bad homographies.

    TODO (Ben): for identifying 'bad' homographies, it would be better to use homography
    decomposition.

    Args:
        H (np.ndarray): homography matrix (eg. returned by cv2.findHomography)
        width (int): width of image
        height (int): height of image

    Returns:
        np.ndarray: scale factor for each corner
    """
    # Indexing from top_right
    top_left = np.array([0, 0, 1])
    top_right = np.array([width, 0, 1])
    bottom_left = np.array([0, height, 1])
    bottom_right = np.array([width, height, 1])
    scale_factors = []
    for pt in [top_left, top_right, bottom_left, bottom_right]:
        scale_factor = 1 / np.matmul(H, pt)[-1]
        scale_factors.append(scale_factor)
    return np.array(scale_factors)


def _align_region(base, target, max_features=3000, feature_type='sift',
                  filter_by_distance=True, filter_by_ratio=True,
                  threshold_distance_pixels=600, threshold_for_filter_by_ratio=0.8,
                  check_scale_factor=False, threshold_for_normalized_scale_factor=.2,
                  homography_method=cv2.RHO):
    """ Aligns a pair of images. Assumes that any resizing has already been done.
    Aligns the base to target (using the entire images, not subregions.

    TODO (Ben): for identifying 'bad' homographies, it would be better to use
    homography decomposition.

    Args:
        base (np.ndarray): image to be aligned
        target (np.ndarray): image to align to
        max_features (int): number of features to initially create before filtering
        feature_type (str): currently only 'sift' is supported
        filter_by_distance (bool): whether to apply distance-based filtering of matches
        filter_by_ratio (bool): whether to apply ratio test to filter matches
        threshold_distance_pixels (int | float): distance threshold to use if applying
            distance filter to matches
        threshold_for_filter_by_ratio (float): ratio to use for ratio test if applying
            ratio filter to matches
        check_scale_factor (bool): whether to check whether homography is likely
            to be acceptable based on a threshold for normalized scale factor.
        threshold_for_normalized_scale_factor (float): absolute value indicating acceptable
            normalized scale factor
        homography_method (int): cv2 constant indicating which algorithm to use for computing
            the homography matrix

    Returns:
        aligned_base (np.ndarray | bool): aligned version of base if alignment succeeds, or
            False if alignment fails
    """
    # Get keypoints
    if feature_type == 'sift':
        keypoints1, keypoints2, matches = get_sift_keypoints_and_matches(base,
                                                                         target, max_features)
    else:
        raise ValueError('Feature type: {} is not implemented'.format(feature_type))

    # Filter matches
    selected_matches = matches
    if filter_by_ratio and (len(selected_matches) > 0):
        selected_matches = filter_matches_by_ratio(matches, ratio=threshold_for_filter_by_ratio)
    if filter_by_distance and (len(selected_matches) > 0):
        selected_matches = filter_matches_by_distance(matches, keypoints1,
                                                      keypoints2, threshold_distance_pixels)

    # At least 4 corresponding point sets to calculate Homography in function 'findHomography'
    if len(selected_matches) <= 4:
        return False

    # Transform base image
    points1 = np.zeros((len(selected_matches), 2), dtype=np.float32)
    points2 = np.zeros((len(selected_matches), 2), dtype=np.float32)

    for i, match in enumerate(selected_matches):
        points1[i, :] = keypoints1[match.queryIdx].pt
        points2[i, :] = keypoints2[match.trainIdx].pt

    H, mask = cv2.findHomography(points1, points2, method=homography_method)

    # Check for failed homography
    if H is None:
        return False

    if check_scale_factor:
        scale_factors = get_scale_factors_for_corners(H, base.shape[1], base.shape[0])
        # Protecting against division by 0
        scale_factors = scale_factors[scale_factors != 0]
        normalized_scale_factors = np.abs(1 - 1 / scale_factors)
        if normalized_scale_factors.max() > threshold_for_normalized_scale_factor:
            return False

    aligned_base = cv2.warpPerspective(base, H, (target.shape[1], target.shape[0]),
                                       flags=cv2.INTER_LANCZOS4)
    return aligned_base


def _align_by_subregions(base, target, height, width, buffer_size, alignment_fn):
    """ Aligns a pair of images, by processing each subregion (ie. tile) seperately.

    Args:
        base (np.ndarray): image to be aligned
        target (np.ndarray): image to align to
        height (int): height of subregions
        width (int): width of subregions
        buffer_size (int): buffer around the subregion to use during alignment
        alignment_fn (callable): alignment function that takes two args, (base, target)

    Returns:
        output (np.ndarray | bool): aligned version of base if alignment succeeds, or
            False if alignment fails
    """
    n_subregion_rows = np.ceil(target.shape[0] / height).astype(np.int32)
    n_subregion_cols = np.ceil(target.shape[1] / width).astype(np.int32)
    output = np.zeros(target.shape, dtype=np.uint8)
    for j in range(n_subregion_cols):
        for i in range(n_subregion_rows):
            top = i * height
            if i + 1 == n_subregion_rows:
                bottom = target.shape[0]
            else:
                bottom = (i + 1) * height
            left = j * width
            if j + 1 == n_subregion_cols:
                right = target.shape[1]
            else:
                right = (j + 1) * width
            top_padded = max(0, top - buffer_size)
            bottom_padded = min(bottom + buffer_size, target.shape[0])
            left_padded = max(0, left - buffer_size)
            right_padded = min(right + buffer_size, target.shape[1])
            top_delta = top - top_padded
            bottom_delta = bottom_padded - bottom  # noqa: F841
            left_delta = left - left_padded
            right_delta = right_padded - right  # noqa: F841
            aligned_image = alignment_fn(base[top_padded: bottom_padded,
                                              left_padded: right_padded, :],
                                         target[top_padded: bottom_padded,
                                                left_padded: right_padded, :])
            if isinstance(aligned_image, np.ndarray):
                output[top:bottom, left:right, :] = aligned_image[top_delta:top_delta + height,
                                                                  left_delta: left_delta + width, :]
            else:
                return False
    return output


def check_if_image_has_large_black_regions(im, kernel_size=50):
    """Checks for large black regions, which are a indication of failed alignment
    an aligned image. Cropping the border is recommended before using this function,
    as non-failed aligned images often have black regions along the border.

    Args:
        im (np.ndarray): image, channels last
        kernel_size (int): kernel size to use for erosion

    Returns:
        has_large_black_regions (bool): whether image has large black regions
    """
    black_pixels = (im == 0).all(axis=2)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    black_pixels_eroded = cv2.erode(black_pixels.astype(np.uint8), kernel)
    has_large_black_regions = black_pixels_eroded.mean() > 0
    return has_large_black_regions


def align_image_using_subregions_where_possible(base, target, max_features=3000,
                                                feature_type='sift', filter_by_distance=True,
                                                filter_by_ratio=True,
                                                threshold_distance_pixels=600,
                                                threshold_for_filter_by_ratio=0.7,
                                                rescale_target_to_base_height=True,
                                                subregion_buffer=600,
                                                grids_for_alignment=None,
                                                check_scale_factor=True,
                                                threshold_for_normalized_scale_factor=0.2
                                                ):
    """Aligns a pair of images. As a default, iterates through several alignment approaches that
    provide higher accuracy but may fail more often:
    * Initially tries to align using a fine subregion grid (2x4)
    * If that fails, aligns using a coarser subregion grid (2x2)
    * If that fails, aligns using a coarser subregion grid (1x2)
    * If that fails, aligns the entire image.

    By design, this function always returns an image, even if alignment fails. This is intended to
    support labeling workflows that expect this function to output an image. If alignment fails,
    the base image is returned. Such cases of failed alignment are indicate by also returning
    grid_for_alignment = False.

    Args:
        base (np.ndarray): image to be aligned (eg. Lucid TRI200S-CC image)
        target (np.ndarray): image to align to (eg. AR233 NRG image)
        max_features (int): number of features to initially create before filtering
        feature_type (str): currently only 'sift' is supported
        filter_by_distance (bool): whether to apply distance-based filtering of matches
        filter_by_ratio (bool): whether to apply ratio test to filter matches
        threshold_distance_pixels (int | float): distance threshold to use if applying
            distance filter to matches
        threshold_for_filter_by_ratio (float): ratio to use for ratio test if applying
            ratio filter to matches
        rescale_target_to_base_height (bool): rescaling the images to have the same height,
            which is useful if the base is larger than the target
        subregion_buffer (int): buffer around the subregion to use during alignment
        grids_for_alignment (list[list[int, int]] | None): subregions grids to use for
            alignment (in descending order of number of subregions). None for using defaults.
        check_scale_factor (bool): whether to check whether homography is likely
            to be acceptable based on a threshold for normalized scale factor.
        threshold_for_normalized_scale_factor (float): absolute value indicating acceptable
            normalized scale factor

    Returns:
        aligned (np.ndarray): aligned version of base if alignment succeeds, or,
            if alignment fails, the base image
        grid_for_alignment (tuple[int] | bool): image aligned using m, n subregions, or
            False if alignment fails
    """
    if rescale_target_to_base_height:
        scale_factor = base.shape[0] / target.shape[0]
        target = cv2.resize(target,
                            dsize=(int(np.round(scale_factor * target.shape[1])), base.shape[0]),
                            interpolation=cv2.INTER_LANCZOS4)
    _default_grids_for_alignment = [[2, 4], [2, 2], [1, 2], [1, 1]]
    grids_for_alignment = _default_grids_for_alignment if grids_for_alignment is None else \
        grids_for_alignment

    for grid_for_alignment in grids_for_alignment:
        n_subregion_rows = grid_for_alignment[0]
        n_subregion_cols = grid_for_alignment[1]
        if (n_subregion_rows == n_subregion_cols == 1):
            aligned = _align_region(
                base=base, target=target, max_features=max_features,
                feature_type=feature_type,
                filter_by_distance=filter_by_distance,
                filter_by_ratio=filter_by_ratio,
                threshold_distance_pixels=threshold_distance_pixels,
                threshold_for_filter_by_ratio=threshold_for_filter_by_ratio,
                check_scale_factor=check_scale_factor,
                threshold_for_normalized_scale_factor=threshold_for_normalized_scale_factor)
        else:
            subregion_height = np.ceil(target.shape[0] / n_subregion_rows).astype(np.int32)
            subregion_width = np.ceil(target.shape[1] / n_subregion_cols).astype(np.int32)
            alignment_fn = partial(
                _align_region, max_features=max_features,
                feature_type=feature_type,
                filter_by_distance=filter_by_distance,
                filter_by_ratio=filter_by_ratio,
                threshold_distance_pixels=threshold_distance_pixels,
                threshold_for_filter_by_ratio=threshold_for_filter_by_ratio,
                check_scale_factor=check_scale_factor,
                threshold_for_normalized_scale_factor=threshold_for_normalized_scale_factor)
            aligned = _align_by_subregions(base=base, target=target, height=subregion_height,
                                           width=subregion_width, buffer_size=subregion_buffer,
                                           alignment_fn=alignment_fn)
        if isinstance(aligned, np.ndarray):
            return aligned, grid_for_alignment

    return base, False
