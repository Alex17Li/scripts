"""
Alignment processing handler.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivertech.com>
Copyright 2021, Blue River Technology
"""

from datetime import datetime

import skimage.io

from brtdevkit import __version__ as brtdevkit_version
from brtdevkit.data import Image, ImageGroup
from brtdevkit.data.core.image import DATETIME_FORMAT
from brtdevkit.util import logger

from .alignment import __version__ as alignment_version
from .alignment import align_image_using_subregions_where_possible as align
from .request_alignment import AlignmentRequestManager

log = logger.Logger('Alignment Request Processing')


def process_request(request_dict: dict):
    """ Processes an alignment request. Downloads artifacts, runs alignment
    and uploads results. Designed to run in Lambda.

    Args:
        request_dict (dict): The request body dictionary
    """

    # Validate the request parameters and retrieve the Image DB objects that will be aligned
    log.info('Validating request parameters...')
    request_dict, images = AlignmentRequestManager.validate_alignment_request(
        request_dict, add_missing=True)
    nrg_image_id = request_dict['nrg_image_id']  # noqa: F841
    high_res_corrected_artifact_id = request_dict['high_res_corrected_artifact_id']
    jpg_compression_quality = request_dict['jpg_compression_quality']
    alignment_parameters = request_dict['alignment_parameters']
    log.info('Validating request parameters... [DONE]')

    # Download the artifacts on the images that will be aligned
    log.info('Downloading artifacts...')
    nrg_image, high_res_image = images
    nrg_artifact = next(artifact for artifact in nrg_image.artifacts if artifact['kind'] == 'nrg')
    nrg_image_artifact_data = skimage.io.imread(nrg_artifact['web_url'])
    high_res_artifact = next(
        artifact for artifact in high_res_image['artifacts']
        if artifact['_id'] == high_res_corrected_artifact_id)
    high_res_image_artifact_data = skimage.io.imread(high_res_artifact['web_url'])
    log.info('Downloading artifacts... [DONE]')

    # Run alignment and save the aligned image
    log.info('Aligning artifacts...')
    aligned, grid = align(
        high_res_image_artifact_data, nrg_image_artifact_data, **alignment_parameters)
    aligned_path = '/tmp/aligned.jpg'
    skimage.io.imsave(aligned_path, aligned, quality=jpg_compression_quality)
    log.info('Aligning artifacts... [DONE]')

    log.info('Performing one more validation before upload...')
    AlignmentRequestManager.validate_alignment_request(request_dict)
    log.info('Performing one more validation before upload... [DONE]')

    log.info('Uploading to Aletheia...')
    group_images = ImageGroup.retrieve(nrg_image.group_id)['data']
    try:
        existing_high_res_aligned_image = next(
            image for image in group_images
            if image.get('mesa_version', None) == 'high_res_aligned')
    except StopIteration:
        existing_high_res_aligned_image = None
    artifact_metadata = {
        'kind': 'high_res_aligned',
        'filepath': aligned_path,
        'metadata': {
            'aligned_to_artifact_ID': high_res_corrected_artifact_id,
            'alignment_version_for_lucid_tri200s_cc': alignment_version,
            'alignment_brtdevkit_version': brtdevkit_version,
            'aligned_at': datetime.strftime(datetime.utcnow(), DATETIME_FORMAT),
            'alignment_grid': grid,
            'request_dict': request_dict
        }
    }
    # If the high_res_aligned image exists, just add the new artifact. Otherwise,
    # create the image and the artifact
    if existing_high_res_aligned_image:
        log.info(
            f'Located existing high_res_aligned image {existing_high_res_aligned_image["id"]}. '
            'Appending artifact to existing image.')
        Image.create_and_upload_artifact(existing_high_res_aligned_image['id'], artifact_metadata)
    else:
        log.info('No existing high_res_aligned artifact found. Upload will create image.')
        metadata = high_res_image.to_dict_recursive()
        metadata.pop('artifacts')  # Overwrite with aligned artifact
        metadata.pop('id')  # DB sets this
        metadata.pop('gnss')  # create_and_upload() computes this from latitude and longitude
        metadata['mesa_version'] = 'high_res_aligned'
        Image.create_and_upload([artifact_metadata], metadata)
    log.info('Uploading to Aletheia... [DONE]')
