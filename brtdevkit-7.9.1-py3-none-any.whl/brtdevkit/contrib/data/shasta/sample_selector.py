"""
Aletheia Datapoint to Shasta Data Sample Transormation functions.

Aletheia Datapoint may contain lists of artifacts and annotations with different types.
    - artifacts
    - annotations

Shasta Data Samples can only have a single image and a single label:
Sample:
    - image
    - label

A mapping between datapoints and samples is required, but it must be flexible enough to be replaced.

Author: BRT CVML <shasta-cvml@bluerivert.com>
Copyright 2020, Blue River Technology
"""
from tempfile import TemporaryFile

import numpy as np
from imageio import imread

from brtdevkit.contrib.data.shasta import PixelVal, SampleKeys


class ArtifactSelectorBase(object):
    def __init__(self, s3_client):
        """Abstract base for Artifact to Sample mapping classes.

        Args:
            s3_client (s3.S3()): AWS S3 API from brtdevkit.
        """
        self.s3_client = s3_client

    def load_s3_image(self, bucket, key):
        with TemporaryFile() as tmp:
            self.s3_client.download_fileobj(bucket, key, tmp)
            image = imread(tmp)
        return image

    def standardize_label(self, gt, labelmap):
        if labelmap is not None and labelmap == {'1': 'crop', '2': 'weed'}:
            crops = gt == 1
            weeds = gt == 2
            gt = np.zeros_like(gt)
            gt[np.where(crops)] = PixelVal.CROP
            gt[np.where(weeds)] = PixelVal.WEED

        # Force class pixel values to remain within the number of classes.
        gt[gt > max(PixelVal)] = 0
        gt[gt < min(PixelVal)] = 0
        return gt

    def verify_label_pixel_values(self, gt):
        """ Verify label integrity at the pixel value level.
        Args:
            gt (numpy.ndarray): label image.

        Returns:
            (bool): Label verified to have correct pixel values.
        """
        allowed_pixel_vals = set([v.value for v in PixelVal])
        for unique_val in np.unique(gt):
            if unique_val not in allowed_pixel_vals:
                return False
        return True

    def __call__(self, datapoint):
        """Return a Shasta Sample from the given Aletheia datapoint.

        Args:
            datapoint (dict): single datapoint in dict format representing a row from the db.

        Returns:
            sample (dict): Shasta sample with desired image, label and img_id.
        """
        raise NotImplementedError


class ArtifactKindSelector(ArtifactSelectorBase):
    def __init__(self, s3_client, artifact_kinds, return_annotation=True):
        """Select artifacts in decreasing order of preference.

        Args:
            s3_client (s3.S3()): AWS S3 API from brtdevkit.
            artifact_kinds (list(str)): Acceptable artifact kinds in decreasing order of preference.
            return_annotation (bool): Check for active annotation or return without annotation.
        """
        super().__init__(s3_client)
        self.artifact_kinds = artifact_kinds
        self.return_annotation = return_annotation

    def _get_artifact_in_decreasing_order_of_preference(self, artifacts):
        for artifact_kind in self.artifact_kinds:
            for a in artifacts:
                if a['kind'] == artifact_kind:
                    return a
        return None

    def _match_annotation(self, anno):
        if not anno['is_active_version']:
            return False
        elif anno['state'] != 'ok':
            return False
        elif anno['style'] != 'pixelwise':
            return False
        elif 'label_map' not in anno:
            return False
        elif 's3_key' not in anno:
            return False
        elif 's3_bucket' not in anno:
            return False
        return True

    def __call__(self, datapoint):
        """Return a Shasta Sample from the given Aletheia datapoint. This callable is meant to be
        used as a simple function that returns a sample given a datapoint.

        Args:
            datapoint (dict): single datapoint in dict format representing a row from the db.

        Returns:
            sample (dict): Shasta sample with desired image, label and img_id.
        """
        if '_id' in datapoint:
            datapoint_id = datapoint['_id']
        elif 'id' in datapoint:
            datapoint_id = datapoint['id']
        else:
            raise KeyError(f'Could not find id in {datapoint}')

        assert 'artifacts' in datapoint
        artifact = self._get_artifact_in_decreasing_order_of_preference(datapoint['artifacts'])
        if artifact is None:
            return None
        assert 's3_bucket' in artifact and 's3_key' in artifact

        image = self.load_s3_image(artifact['s3_bucket'], artifact['s3_key'])

        if self.return_annotation:
            assert 'annotations' in datapoint
            anno = None
            # If there is only a single annotation it is likely part of an annotation dataset.
            # Annotation datasets are keyed by annos and therefore this annotation was chosen
            # by the dataset creator.
            if len(datapoint['annotations']) == 1:
                anno = datapoint['annotations'][0]
            else:
                for a in datapoint['annotations']:
                    if self._match_annotation(a):
                        anno = a
            if anno is None:
                return None
            assert 'label_map' in anno and 's3_key' in anno and 's3_bucket' in anno

            label = self.load_s3_image(anno['s3_bucket'], anno['s3_key'])
            # Standardize label map to Shasta standard.
            label = self.standardize_label(label, anno['label_map'])
            # Verify that pixel values are correct.
            assert self.verify_label_pixel_values(label)
        else:
            label = np.zeros(image.shape[:2], dtype=np.uint8)

        sample = {
            SampleKeys.image: image,
            SampleKeys.label: label,
            SampleKeys.img_id: datapoint_id,
        }
        return sample
