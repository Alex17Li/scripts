""" Utility functions for CV.

Author: Asav Patel <asav.patel@bluerivert.com>

Copyright 2020, Blue River Technology
"""

import numpy as np
import skimage.transform as skt
from PIL import Image, ImageDraw


def extract_labels_from_area(label, polygons):
    """
    Extract pixels from the given label image and label them with given dataclass

    Args:
        label (np.ndarray) : uint8 single channel label
        polygons (dict) : polygon with list of (x,y) cordinates with their corresponding data class.

            Example::

                {
                    1: [
                        [(589, 238), (935, 238), (935, 935), (589, 935)],
                        [(198.185, 291.377), (353.203, 370.322), (216.844, 539.694)]
                       ],
                    2: [[(1500, 238), (1708, 898), (1918, 904), (1766, 162)]]
                }

    Returns:
        :class:`tuple` of (:class:`numpy.ndarray`, :class:`numpy.ndarray`):
            polygon mask and label image with extracted pixel values from given polygon.
    """
    polygon_mask = Image.new('L', (label.shape[1], label.shape[0]), 0)

    for data_class, class_polygons in polygons.items():
        for p in class_polygons:
            ImageDraw.Draw(polygon_mask).polygon(p, outline=data_class, fill=data_class)
    polygon_mask = np.array(polygon_mask)
    extracted_label_mask = np.zeros([label.shape[0], label.shape[1]], dtype=np.uint8)

    polygon_area_idx = np.where(polygon_mask > 0, label, 0) > 0
    extracted_label_mask[polygon_area_idx] = polygon_mask[polygon_area_idx]

    return polygon_mask, extracted_label_mask


def bounding_box_to_coordinates(bounding_box):
    """
    Converts bounding box to list of (x,y) coordinates

    Args:
        bounding_box (dict) : bounding box representation from Tartarus.

            Example::

                {
                    'top_left': [1381, 289], 'bottom_right': [1516, 384],
                    'confidence': 1.0, 'data_class': 2
                }

    Returns:
        :class:`list`: of (x, y) coordinates
    """
    try:
        top_x, top_y = bounding_box['top_left']
        bottom_x, bottom_y = bounding_box['bottom_right']
    except KeyError:
        raise

    bbox_xy = [
        (top_x, top_y), (top_x, bottom_y),
        (bottom_x, bottom_y), (bottom_x, top_y)
    ]
    return bbox_xy


def polygon_to_coordinates(polygon):
    """
        Converts polygon to list of (x,y) coordinates

        Args:
            polygon (dict): polygon representation from Tartarus.

                Example::

                    [{'x': 198.185, 'y': 291.377},
                    {'x': 353.203, 'y': 370.322},
                    {'x': 216.844, 'y': 539.694},
                    {'x': 132.158, 'y': 331.567}]

        Returns:
            :class:`list`: of (x, y) coordinates
        """
    try:
        polygon_xy = [(p['x'], p['y']) for p in polygon]
    except KeyError:
        raise
    return polygon_xy


def colorize_segmentation(image, label, alpha=0.5):
    """
    Pixelseg colorization
    Args:
        image (np.ndarray) : uint8 image
        label (np.ndarray) : uint8 label array with values of 0, 1, 2
        alpha: (float) : opacity of the color overlay - where zero is translucent and one is opaque.
    Returns:
        :class:`numpy.ndarray`: image with color overlay of weed/crop predictions
    """
    colorized = image.copy()
    # if the image and prediction shape don't match, resize image to match the prediction/label
    colorized = skt.resize(colorized, label.shape, order=1, mode='constant',
                           anti_aliasing=False, preserve_range=False) * 255.0
    red = [alpha * 255.0, 0.0, 0.0]
    green = [0.0, alpha * 255.0, 0.0]

    crops = np.where(label == 1)
    weeds = np.where(label == 2)
    colorized[crops] = (1 - alpha) * colorized[crops] + green
    colorized[weeds] = (1 - alpha) * colorized[weeds] + red
    return colorized.astype(np.uint8)
