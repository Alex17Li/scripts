""" Utility functions to generate ndvi mask for a given image

Author: Asav Patel <asav.patel@bluerivert.com>,
Copyright 2020, Blue River Technology
"""

import cv2
import numpy as np
from skimage.filters import threshold_otsu


def generate_ndvi(red, nir, shadow_threshold=50):
    """
        Method which returns  ndvi image from given red and nir channel.
        Args:
            red (np.ndarray) : 8 bit numpy array for red channel
            nir (np.ndaarray) : 8 bit numpy array for nir channel
            shadow_threshold (int) : shadow threshold to use in the image
        Returns:
            np.ndarray : 8 bit single channel ndvi image
    """
    red = red.astype(np.float)
    nir = nir.astype(np.float)

    idx = np.where(nir < shadow_threshold)
    red[idx] = 0
    nir[idx] = 0

    # adding very small number in divisor to avoid divide by zero error
    ndvi = ((nir - red) / (nir + red + 1e-6)) * 255.0
    ndvi[idx] = 0

    # get rid of negative pixel values
    idx = ndvi < 0.0
    ndvi[idx] = 0.0

    # cap pixels values to 255
    idx = ndvi > 255.0
    ndvi[idx] = 255.0

    return ndvi.astype(np.uint8)


def process_plant_finder(ndvi, ndvi_threshold, use_otsu=False, morph=True):
    """
        Run plant finder on the given ndvi image.
        Args:
            ndvi (np.ndarray) : uint8 ndvi image
            ndvi_threshold (float) : ndvi threshold.
            use_otsu (boolean) : to apply otsu threshold.
            morph (boolean) : To apply dialation and erosion operations on the image
        Returns:
            np.ndarray: uint8 plant mask image (where pixelvalue 1 represents a plant)
    """

    filtered = cv2.bilateralFilter(ndvi, 5, 75, 75)

    # Otsu Threshold
    if use_otsu:
        otsu_thresh = 0.0
        idx = np.where(ndvi != 0)
        try:
            otsu_thresh = threshold_otsu(ndvi[idx])

        except ValueError:
            pass

        if otsu_thresh < (ndvi_threshold * 255):
            otsu_thresh = ndvi_threshold * 255

        _thresh_val, plant = cv2.threshold(filtered, otsu_thresh, 255, cv2.THRESH_BINARY)
    else:
        # Constant Threshold
        _thresh_val, plant = cv2.threshold(filtered, ndvi_threshold * 255, 255, cv2.THRESH_BINARY)

    plant[np.where(plant == [255])] = [1]

    if morph:
        # Erode
        kernel1 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (1, 1))
        plant = cv2.erode(plant, kernel1, iterations=1)

        # Dilate
        kernel2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
        plant = cv2.dilate(plant, kernel2, iterations=1)

    return plant
