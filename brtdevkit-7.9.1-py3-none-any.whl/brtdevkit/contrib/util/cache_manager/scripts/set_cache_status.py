""" set_cache_status.py -- Utility to set cache status.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2020, Blue River Technology
"""

import argparse
import logging

from brtdevkit.contrib.util.cache_manager import CacheManager


def set_cache_status(cache_mnt_path, cache_path, status):
    """
    Args:
        cache_mnt_path (str): The root cache directory
        cache_path (str): The path within the cache to poll
        status (str): Cache status to set
    """
    cm = CacheManager(cache_mnt_path)
    logging.info(f'Setting cache status to {status}')
    cm.set_status(cache_path, status)


def main():
    logging.basicConfig(level='INFO')

    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_mnt_path", type=str, required=True)
    parser.add_argument("--cache_path", type=str, required=True)
    parser.add_argument("--status", type=str, required=True)
    args = parser.parse_args()

    set_cache_status(
        cache_mnt_path=args.cache_mnt_path,
        cache_path=args.cache_path,
        status=args.status,
    )


if __name__ == "__main__":
    main()
