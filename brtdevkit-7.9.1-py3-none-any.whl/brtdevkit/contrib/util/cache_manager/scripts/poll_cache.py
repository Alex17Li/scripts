""" poll_cache.py -- Cache polling built on top of
Cache Manager. Designed for use in model training workflow.
Detailed design can be found here:
https://docs.google.com/document/d/1YnvlOzuexoNumbx5jGYzoj9pDhdzy70zziyWDTWHQ5M/edit#

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2020, Blue River Technology
"""

import argparse
import logging
from datetime import datetime
from time import sleep

from brtdevkit.contrib.util.cache_manager import CacheManager


def poll_cache(cache_mnt_path, cache_path, out_status_file, max_heartbeat_wait_s, max_wait_s,
               poll_interval, assume_control_if_not_ready):
    """
    Polls a particular cache using the brtdevkit cache manager service. If the cache is in
    any state other than in_progress, write the state out to a file and return, and optionally
    take control if the cache is not ready. "take control" = sending a heartbeat and setting
    the cache status to in_progress.

    If the cache is already in progress, wait while also listening for heartbeats which should
    be being sent regularly by the process which set the cache in_progress. If too much time has
    passed since the last heartbeat, it is possible that other process died. Write out status and
    exit, and optionally take control here too.

    Finally, even if heartbeats are being logged, if a maximum wait time is exceeded, exit and
    take control if desired.

    Args:
        cache_mnt_path (str): The root cache directory
        cache_path (str): The path within the cache to poll
        out_status_file (str): The path of the file to write the final status to
        max_heartbeat_wait_s (str): The number of seconds after that last heartbeat to wait
            until exiting.
        max_wait_s (str): The maximum amount of time to wait even if heartbeats are being
            recieved.
        poll_interval (int): The number of seconds to wait in between cache polling
        assume_control_if_not_ready (bool): If true, and if the cache is not
            ready when this function exits, will set the cache status to IN_PROGRESS, and
            send a heartbeat, indicating the caller plans on taking control of the populating
            the cache.
    """

    def write_status(cm):
        status = cm.get_status(cache_path)
        with open(out_status_file, 'w+') as f:
            f.write(status)
        logging.info(f'Recorded status {status}')

    cm = CacheManager(cache_mnt_path)
    status = cm.get_status(cache_path)

    # If cache is not in progress, indicate as such and return
    if status != CacheManager.CACHE_STATUS_IN_PROGRESS:
        logging.info(f'Cache discovered in status {status}')
        if status != CacheManager.CACHE_STATUS_READY and assume_control_if_not_ready:
            logging.info('Assuming control over cache')
            cm.set_status(cache_path, CacheManager.CACHE_STATUS_IN_PROGRESS)
            cm.send_heartbeat(cache_path)
        write_status(cm)
        return 0

    # Otherwise start polling
    start = datetime.utcnow().timestamp()
    while True:
        now = datetime.utcnow().timestamp()
        status = cm.get_status(cache_path)
        last_heartbeat = cm.get_heartbeat(cache_path) or 0

        logging.info(f'Polling cache at {now}')
        logging.info(f'Status: {status}')
        logging.info(f'Last heartbeat: {last_heartbeat}')

        # The cache is ready
        if status == CacheManager.CACHE_STATUS_READY:
            write_status(cm)
            return 0

        # It's been too long since the last heartbeat
        if now - last_heartbeat > max_heartbeat_wait_s:
            # Optionally update the state send a heartbeat indicating
            # we plan to take control of the cache
            logging.info(f'Maximum heartbeat wait time of {max_heartbeat_wait_s}s exceeded')
            if assume_control_if_not_ready:
                logging.info('Assuming control over cache')
                cm.set_status(cache_path, CacheManager.CACHE_STATUS_IN_PROGRESS)
                cm.send_heartbeat(cache_path)
            write_status(cm)
            return 0

        # We've waited too long for the cache even if we are recieving heartbeats
        if now - start > max_wait_s:
            # Optionally update the state send a heartbeat indicating
            # we plan to take control of the cache
            logging.info(f'Maximum overall wait time of {max_wait_s}s exceeded')
            if assume_control_if_not_ready:
                logging.info('Assuming control over cache')
                cm.set_status(cache_path, CacheManager.CACHE_STATUS_IN_PROGRESS)
                cm.send_heartbeat(cache_path)
            write_status(cm)
            return 0
        logging.info(f'Going to sleep for {poll_interval}s')
        sleep(poll_interval)
        logging.info('\n')


def main():
    logging.basicConfig(level='INFO')

    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_mnt_path", type=str, required=True)
    parser.add_argument("--cache_path", type=str, required=True)
    parser.add_argument("--out_status_file", type=str, required=True)
    parser.add_argument("--max_heartbeat_wait_s", type=int, required=True)
    parser.add_argument("--max_wait_s", type=int, required=True)
    parser.add_argument("--poll_interval", type=int, required=True)
    parser.add_argument("--assume_control_if_not_ready", action='store_true')
    args = parser.parse_args()

    poll_cache(
        cache_mnt_path=args.cache_mnt_path,
        cache_path=args.cache_path,
        out_status_file=args.out_status_file,
        max_heartbeat_wait_s=args.max_heartbeat_wait_s,
        max_wait_s=args.max_wait_s,
        poll_interval=args.poll_interval,
        assume_control_if_not_ready=args.assume_control_if_not_ready,
    )


if __name__ == "__main__":
    main()
