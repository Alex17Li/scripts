""" keep_alive.py -- Simple cache keep alive utility which
sends periodic heartbeats to cache.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2020, Blue River Technology
"""

import argparse
import logging
from datetime import datetime
from time import sleep

from brtdevkit.contrib.util.cache_manager import CacheManager


def cache_keep_alive(cache_mnt_path, cache_path, heartbeat_interval_s, max_time_s=None):
    """
    Args:
        cache_mnt_path (str): The root cache directory
        cache_path (str): The path within the cache to poll
        heartbeat_interval_s (int): The number of seconds to wait in between sending heartbeats
        max_time_s (int): Maximum number of seconds to execute keep alive. Infinite if None
    """
    cm = CacheManager(cache_mnt_path)
    start = datetime.utcnow().timestamp()
    while True:
        now = datetime.utcnow().timestamp()
        if max_time_s and now - start >= max_time_s:
            break
        logging.info(f'Sending heartbeat at {now}')
        cm.send_heartbeat(cache_path)
        sleep(heartbeat_interval_s)


def main():
    logging.basicConfig(level='INFO')

    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_mnt_path", type=str, required=True)
    parser.add_argument("--cache_path", type=str, required=True)
    parser.add_argument("--heartbeat_interval_s", type=int, required=True)
    parser.add_argument("--max_time_s", type=int, required=False)
    args = parser.parse_args()

    cache_keep_alive(
        cache_mnt_path=args.cache_mnt_path,
        cache_path=args.cache_path,
        heartbeat_interval_s=args.heartbeat_interval_s,
        max_time_s=args.max_time_s
    )


if __name__ == "__main__":
    main()
