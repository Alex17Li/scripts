""" cache_manager.py -- Cache manager service

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2020, Blue River Technology
"""

import datetime
import json
import os
from pathlib import Path
from time import sleep

from atomicwrites import atomic_write


class CacheException(Exception):
    pass


class CacheManager:
    """ Cache manager service that uses a locally mounted filesystem
    to store both cache state and cache files. Cache state is maintained
    per directory and is accessed and modified by providing the relative path
    from the cache manager's root path which is set at initialization time.
    CacheManager class is complemented by console scripts in ./scripts that
    provide cli interfaces to common cache operations. """

    CACHE_STATUS_NX_CACHE = 'nxcache'
    CACHE_STATUS_READY = 'ready'
    CACHE_STATUS_IN_PROGRESS = 'in_progress'
    CACHE_STATUS_INVALID = 'invalid'

    _DEFAULT_TIME_S_BETWEEN_SAFE_READS = 0.25

    CACHE_STATUSES = (
        CACHE_STATUS_NX_CACHE,
        CACHE_STATUS_READY,
        CACHE_STATUS_IN_PROGRESS,
        CACHE_STATUS_INVALID,
    )

    CACHE_STATE_FILE_NAME = '.CACHESTATE'
    _CACHE_STATUS_KEY = 'state'
    _CACHE_HEARTBEAT_KEY = 'heartbeat'

    def __init__(self, cache_dir: Path):
        if isinstance(cache_dir, str):
            cache_dir = Path(cache_dir)
        if not os.path.isdir(cache_dir):
            raise CacheException(f'{cache_dir} is not a directory')
        self._cache_dir = cache_dir

    def full_path(self, path: Path) -> Path:
        """ Transforms cache relative path into full path """
        return self._cache_dir / path

    def _cache_state_path(self, path: Path) -> Path:
        return self._cache_dir / path / self.CACHE_STATE_FILE_NAME

    def _read_json_safely(self, path: Path, max_attempts=10,
                          time_between_attempts=_DEFAULT_TIME_S_BETWEEN_SAFE_READS):
        attempts = 1
        while attempts <= max_attempts:
            # Try to read the file and make sure it didn't change
            # underneath us
            try:
                with open(path, 'r') as f:
                    before = f.read()
                    f.seek(0)
                    json_rep = json.load(f)
                    f.seek(0)
                    after = f.read()
                    if before == after:
                        return json_rep
            except json.JSONDecodeError:
                continue
            sleep(time_between_attempts)
            attempts += 1

    def get_status(self, path: Path):
        """ Get cache status for a cache relative path """
        fpath = self.full_path(path)
        if not os.path.isdir(fpath):
            return self.CACHE_STATUS_NX_CACHE

        cache_state_path = self._cache_state_path(path)
        if not os.path.isfile(cache_state_path):
            return self.CACHE_STATUS_INVALID

        state = self._read_json_safely(cache_state_path)
        cache_status = state[self._CACHE_STATUS_KEY]

        if cache_status not in self.CACHE_STATUSES:
            return self.CACHE_STATUS_INVALID

        return cache_status

    def set_status(self, path: Path, status):
        """ Set cache status for a cache relative path """
        valid_statuses = (
            self.CACHE_STATUS_READY, self.CACHE_STATUS_IN_PROGRESS, self.CACHE_STATUS_INVALID)
        if status not in valid_statuses:
            raise CacheException(f'status must be in: {valid_statuses}')
        os.makedirs(self.full_path(path), exist_ok=True)
        cache_state_path = self._cache_state_path(path)
        try:
            state = self._read_json_safely(cache_state_path)
        except FileNotFoundError:
            state = {}
        state[self._CACHE_STATUS_KEY] = status
        with atomic_write(cache_state_path, overwrite=True) as f:
            json.dump(state, f)

    def send_heartbeat(self, path: Path):
        """ Set cache heartbeat. Hearbeats indicate that the process sending the heartbeat
        is still responsible for and is currently working on hydrating that particular cache.
        The cache must be in state ready or in_progress """
        valid_statuses = (self.CACHE_STATUS_READY, self.CACHE_STATUS_IN_PROGRESS)
        if self.get_status(path) not in valid_statuses:
            raise CacheException(f'cache must be in status {valid_statuses}')
        cache_state_path = self._cache_state_path(path)
        state = self._read_json_safely(cache_state_path)
        state[self._CACHE_HEARTBEAT_KEY] = datetime.datetime.utcnow().timestamp()
        with atomic_write(cache_state_path, overwrite=True) as f:
            json.dump(state, f)

    def get_heartbeat(self, path: Path):
        """ Get cache heartbeat if it exists """
        cache_state_path = self._cache_state_path(path)
        if not os.path.isfile(cache_state_path):
            return None
        state = self._read_json_safely(cache_state_path)
        try:
            heartbeat = state[self._CACHE_HEARTBEAT_KEY]
            return heartbeat
        except (json.JSONDecodeError, KeyError):
            return None

    @property
    def cache_dir(self):
        return self._cache_dir
