""" contrib/util/spyglass/spyglass.py -- Spyglass related utility functions.
Many of these functions are used by workflow steps.

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2020, Blue River Technology
"""

import dateutil
import haversine
import numpy as np
from botocore.exceptions import ClientError

from brtdevkit.core.db.athena import AthenaClient
from brtdevkit.data import Analysis, AnnotationJob
from brtdevkit.util import logger

log = logger.Logger('Spyglass')

# Initialize client to fetch images from the data lake
athena = AthenaClient()


def geohash_image_sample(image_df, samples_per_meter=1):
    """ Geohash a dataframe of images with a given precision.
    Primarily used with Spyglass, which requires non-overlapping labeled data
    to create its annotation tiles.

    For a machine log, keeps all images from the same timestamp. That keeps all images from
    all cameras at a given time stamp.

    Args:
        image_df (pandas.Dataframe): Dataframe of images retrieved through DB connector.
        samples_per_meter (int): The number of samples points per meter.
    Returns:
        pandas.Dataframe: Sampled geohashed dataframe
    """
    assert 's3_path' in image_df, "Your dataframe doesn't have an s3_path attribute. We can't differentiate which logs " + \
        "each image are from without it. This is probably a sign your images are not from 2021."

    uuids = []
    for s3_path in image_df['s3_path'].unique():
        image_log_df = image_df[image_df['s3_path'] == s3_path]

        # Find the start and end points
        start_point = image_log_df.loc[image_log_df['collected_on'].idxmin()]
        end_point = image_log_df.loc[image_log_df['collected_on'].idxmax()]

        # Assume a linear trajectory between start and end point and linearly interpolate sample points.
        # TODO(david): Assuming a linear trajectory may be bold. For 99% of our full logs right now the machine is driving straight.
        # Someday we may need to handle the machine turning or doing turns in the field.
        len_meters = haversine.haversine((start_point['latitude'], start_point['longitude']),
                                         (end_point['latitude'], end_point['longitude']), unit='m')

        assert len_meters < 2000, "There's over 2km distance between points you're trying to sample from. This means your samples" + \
            "are probably coming from radically different logs."

        num_samples = samples_per_meter * len_meters

        # If no samples specified, just return the start point.
        if num_samples == 0:
            latitude_samples = [start_point['latitude']]
            longitude_samples = [start_point['longitude']]
        else:
            t = np.arange(0, num_samples + 1) / num_samples
            latitude_samples = start_point['latitude'] + t * \
                (end_point['latitude'] - start_point['latitude'])
            longitude_samples = start_point['longitude'] + t * \
                (end_point['longitude'] - start_point['longitude'])

        # Find the closest sample to each sample point.
        # TODO(david): Use a pose interpolater to select closest point. The gps frequency is slower than the image capture frequency.
        # Which means multiple images can be associated with a single lat lon coordinate. Without a pose interpolater, the "closest" image,
        # could be multiple images. Without a way to know which is closest, sometimes you can sample images less uniform that desired.
        for x, y in zip(latitude_samples, longitude_samples):
            dist_df = (image_log_df['latitude'] - x)**2 + (image_log_df['longitude'] - y)**2

            # Grab that image and all other images at that time stamp (images from the other cameras).
            # TODO(david): instead of grabbing all cameras from the same time stamp, sample by camera location. However, there is currently
            # no camera index attribute, so there's no way to know the relative location of cameras.
            closest_collected_on_time = image_log_df.loc[dist_df.idxmin()]['collected_on']
            uuids.extend(
                image_log_df[
                    image_log_df['collected_on'] == closest_collected_on_time
                ]['uuid'].tolist()
            )

    return image_df[image_df['uuid'].isin(uuids)]


def filter_image_times(image_df, start_time=None, end_time=None):
    if start_time:
        # Ignoring timezone because Aletheia does not keep track of timezone. It assumes utc.
        start_datetime = dateutil.parser.parse(start_time, ignoretz=True)
        image_df = image_df.drop(image_df[image_df.collected_on < start_datetime].index)
    if end_time:
        # Ignoring timezone because Aletheia does not keep track of timezone. It assumes utc.
        end_datetime = dateutil.parser.parse(end_time, ignoretz=True)
        image_df = image_df.drop(image_df[image_df.collected_on > end_datetime].index)
    return image_df


def export_spyglass_annotation_job(
        vendor,
        annotation_job_parameters,
        spyglass_id,
        acceptable_annotation_filter,
        filter_start_time=None,
        filter_end_time=None):
    """ Send out an annotation job for a given spyglass analysis. This function generates
    a geohashed sample of images from the given spyglass analysis, determines which images
    do not yet have an appropriate annotation, sends those images out for labeling to the
    selected vendor with the given annotation job parameters, and then sets triggers on the
    spyglass analysis so the analysis updates when labeled data becomes available. This function
    requires user input during its invocation!!!!

    Args:
        vendor (str): 'labelbox'. The labeling vendor to send the job to
        annotation_job_parameters (dict): The parameters to use with the annotation job API,
            NOT including the list of Image IDs.
        spyglass_id (str): Analysis ID of the Spyglass run who's images to send out for labeling
        acceptable_annotation_filter (string): The annotation level filter which will be applied to
            image annotations to determine which images already have acceptable annotations and
            do not need to be sent out again. Formatted as a SQL WHERE statement.
        filter_start_time (str): Start time for filtering images by `collected_on`
        filter_end_time (str) End time for filtering images by `collected_on`

    Returns:
        tuple(AnnotationJob, Analysis): The new AnnotationJob, and the updated Spyglass Analysis
    """

    # Retrieve the existing spyglass analysis and associated image UUIDs
    spyglass_analysis = Analysis.retrieve(spyglass_id)
    image_uuids = spyglass_analysis.image_uuids

    # See if all the images have been imported
    sql = f'''
    SELECT id, collected_on, latitude, longitude, s3_path, uuid,
    EXISTS(
        SELECT id FROM annotation_shasta
        WHERE annotation_shasta.image = image_shasta.id
        AND {acceptable_annotation_filter}
    ) AS has_acceptable_annotation
    FROM image_shasta
    WHERE CONTAINS(
        (
            SELECT cast(JSON_PARSE(analysis.image_uuids__json) as ARRAY<VARCHAR>) FROM analysis
            WHERE id = '{spyglass_id}'
        ),
        uuid
    )
    '''
    log.info('Querying for images related to this analysis.')
    try:
        images = athena.get_df(sql)
    except ClientError as e:
        log.error('There was an error querying for images, please double-check your annotation filters.')
        raise e

    if len(images) < len(image_uuids):
        log.warn(f'Only {len(images)}/{len(image_uuids)} images are imported. Continue?')
        input("Press ENTER to continue or Ctrl-C to quit.\n")

    log.info('Deduplicating Spyglass images via geohashing...')
    filtered_images = filter_image_times(
        images,
        filter_start_time,
        filter_end_time,
    )
    geosampled_images = geohash_image_sample(filtered_images)
    geosampled_image_uuids = list(geosampled_images.to_dict()['uuid'].values())
    log.info(
        f'Selected {len(geosampled_images)} '
        f'out of {len(images)} total images in DB.'
    )

    # Find images that contain acceptable annotations, and thus will be excluded from the
    # annotation job.
    images_to_exclude = geosampled_images.loc[geosampled_images.has_acceptable_annotation]

    if len(images_to_exclude) > 0:
        excluded_image_uuids = list(images_to_exclude.to_dict()['uuid'].values())
    else:
        excluded_image_uuids = list()  # Empty list
    log.info(f'{len(excluded_image_uuids)}/{len(geosampled_images)} have acceptable annotations.')

    # Construct the set of images to send out for the annotation job
    job_image_uuids = list(set(geosampled_image_uuids) - set(excluded_image_uuids))
    job_images = images[images.uuid.isin(job_image_uuids)]
    if len(job_images) == 0:
        log.info('No images qualify to be sent for labeling. Quitting...')
        return
    job_image_ids = [str(id) for id in job_images['id']]

    # Prompt and send out the job
    input(
        f'Ready to send out {len(job_image_ids)} images for labeling? '
        'Press ENTER to continue or Ctrl-C to quit'
    )
    job = AnnotationJob.create(
        vendor,
        image_ids=job_image_ids,
        **annotation_job_parameters,
    )
    log.info('Annotation Job sent.')

    # Return the new job and the spyglass analysis
    return job, spyglass_analysis
