"""ListObject datastructure for API Bindings so we can add methods to the list objects

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

from brtdevkit.core.api.api_object import APIObject
from brtdevkit.core.api.api_requestor import APIRequestor
from brtdevkit.core.api.error import InvalidRequestError


class ListObject(APIObject):
    OBJECT_NAME = "list"

    def __init__(self, values, endpoint=None):
        """
          Args:
              values (dict): The key value pairs to initialize the object with
              endpoint (str): Optional endpoint to use when fetching pages. If
                              not provided, will be inferred from the API resource
                              class found on the first page
        """
        super().__init__(values)
        self._endpoint = endpoint

    def auto_paging_iter(self):
        """
            converts list object into paginated iterator and makes subsequent calls to API
        """
        page = self["data"]
        if len(page) == 0:
            raise InvalidRequestError("no matching resource found with given parameter(s)")
        resource_class = type(page[0])
        endpoint = self._endpoint or resource_class.ENDPOINT
        while True:
            for item in page:
                yield item
            next_page = getattr(self, 'next_page', False)
            if not next_page:
                return
            requestor = APIRequestor()
            params = self.params.to_dict()
            params.update({"page": next_page})
            response = requestor.request("get", endpoint, params=params)
            page = [resource_class(item) for item in response.data['data']]
            setattr(self, 'next_page', response.data['next_page'])

    def __iter__(self):
        return getattr(self, "data", []).__iter__()

    def __len__(self):
        return getattr(self, "total_count", 0)
