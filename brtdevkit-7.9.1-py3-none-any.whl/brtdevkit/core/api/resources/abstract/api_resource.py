"""abstract class for APIBindings
"""
from brtdevkit.core import APIObject, APIRequestor, error
from brtdevkit.core.api.error import InvalidRequestError


class APIResource(APIObject):

    # ENDPOINT constant must be defined in implementing classes.

    @staticmethod
    def request(method, url, params=None, headers=None):
        # TODO (eric): APIRequestor might work better as a util function, rather than an object
        requestor = APIRequestor()
        return requestor.request(method, url, params=params, headers=headers)

    def __init__(self, values, **params):
        """
          Args:
              id (str) : id of the object/resource
              params (dict) : any extra parameters
        """
        super().__init__(values)
        self._retrieve_params = params

    @classmethod
    def retrieve(cls, id, **params):
        response = cls.request('get', f"{cls.ENDPOINT}/{id}", params)
        if not response:
            raise InvalidRequestError(f"Matching request not found: id={id}, param={params}")
        return cls(response.data, **params)

    @classmethod
    def index_information(cls):
        if not hasattr(cls, 'OBJECT_NAME'):
            raise error.InvalidRequestError(
                'Could not determine the collection to retrieve index information for. '
                'The calling class must define an OBJECT_NAME attribute for this purpose.'
            )
        response = cls.request('get', f'/indexes/{cls.OBJECT_NAME}')
        return response.data

    def refresh(self):
        response = self.request("get", self.instance_url, params=self._retrieve_params)
        self.refresh_from(response.data)

    @property
    def instance_url(self):
        if not isinstance(self.id, (int, str)):
            message = (
                f"Could not determine which URL to request: {type(self).__name__} instance has"
                f"invalid ID: {self.id}, {type(self.id)}. ID should be of type `str` (or `int`)"
            )
            raise error.InvalidRequestError(message, "id")
        return f"{type(self).ENDPOINT}/{self.id}"
