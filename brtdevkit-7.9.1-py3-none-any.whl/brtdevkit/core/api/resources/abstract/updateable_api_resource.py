""" updatable_api_resource.py - APIResource class
for any API bindings updatable via PATCH

Authors:
    Asav Patel <asav.patel@bluerivert.com>
    Ajay Penmatcha <ajay.penmatcha@bluerivert.com>

Copyright 2019, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import APIResource
from brtdevkit.core.api.swagger import include_docs


class UpdateableAPIResource(APIResource):

    def __init_subclass__(cls, **kwargs):
        """
        Runs each time this base class is subclassed, attaches a `.explain` function to each
        API binding this base class provides, pulling the documentation from
        an OpenAPI specification.
        """
        super().__init_subclass__(**kwargs)
        try:
            ENDPOINT = cls.ENDPOINT
            OBJECT_NAME = cls.OBJECT_NAME
            detail_endpoint = ENDPOINT + "/{" + OBJECT_NAME + "_id}"
        except AttributeError:
            # No ENDPOINT variable is present on the subclass
            return
        wrapper = include_docs(detail_endpoint, "patch")
        cls.modify = wrapper(cls.modify)
        cls.update = wrapper(cls.update)
        cls.save = wrapper(cls.save)

    @classmethod
    def modify(cls, sid, params):
        response = cls.request("patch", f"{cls.ENDPOINT}/{sid}", params)
        return cls(response.data, **params)

    def update(self, params):
        response = self.request("patch", f"{self.instance_url}", params)
        self.refresh_from(response.data)

    def save(self):
        params = self.to_dict_recursive()
        response = self.request("patch", self.instance_url, params)
        self.refresh_from(response.data)
