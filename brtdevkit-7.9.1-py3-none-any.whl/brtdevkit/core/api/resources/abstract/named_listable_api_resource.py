""" named_listable_api_resource.py - implements APIResource class. class for any API bindings which is listable and has a name attribute.

Author: David Evans <dave.evans@bluerivert.com>

Copyright 2021, Blue River Technology
"""
from brtdevkit.core.api.error import InvalidRequestError
from brtdevkit.core.api.resources.abstract import ListableAPIResource


class NamedListableAPIResource(ListableAPIResource):

    @classmethod
    def retrieve(cls, id=None, name=None, **params):
        # TODO (alex): What about if no dataset by Id is found?
        assert id or name, 'id or name required'
        if name:
            # If an API resource has a name api (like Dataset), then it will return a single result here.
            # If the API resource doesn't have a name api (like KubeflowPipeline), then we will iterate
            # through every item in the iterator, looking for the name
            for res in cls.auto_paging_iter(name=name, **params):
                if res.name == name:
                    id = res.id
                    break
        if id is None:
            raise InvalidRequestError(f"Could not retrieve resource: {cls.__name__} with name: {name}")
        return super(NamedListableAPIResource, cls).retrieve(id, **params)
