""" decorator which adds class methods to the nested resources

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

from __future__ import absolute_import, division, print_function

from brtdevkit.core import ListObject


def nested_resource_class_methods(resource, path=None, operations=None):
    """
    Args:
        resource (str): parent resource
        path (str): if path is different then resource name
        operations (list): list of allowed operations on nested resource.
            e.g. $ (["create", "retrieve", "update", "delete", "list"])
    """
    if path is None:
        path = f'{resource.OBJECT_NAME}'
    if operations is None:
        raise ValueError("operations list required")

    def wrapper(cls):
        def nested_resource_url(cls, id=None, nested_id=None):
            url = f"{cls.ENDPOINT}/"
            if id is not None:
                url += f"{id}/"
            url += f"{path}"
            if nested_id is not None:
                url += f"/{nested_id}"
            return url

        resource_url_method = f'{resource.OBJECT_NAME}s_url'
        setattr(cls, resource_url_method, classmethod(nested_resource_url))

        def nested_resource_request(cls, method, url, resource, **params):
            response = resource.request(method, url, params, headers=None)
            if response.data.get('data'):
                response.data['data'] = [resource(el) for el in response.data['data']]
                # store req param, so it can be reused in auto_paging_iter
                response.data['params'] = params
                return ListObject(response.data, endpoint=url)
            instance = resource(response.data)
            instance._retrieve_params = params
            return instance

        resource_request_method = f'{resource.OBJECT_NAME}s_request'
        setattr(
            cls, resource_request_method, classmethod(nested_resource_request)
        )

        for operation in operations:
            if operation == "create":

                def create_nested_resource(cls, id, **params):
                    url = getattr(cls, resource_url_method)(id)
                    return getattr(cls, resource_request_method)(
                        "post", url, resource, **params
                    )

                create_method = f'create_{resource.OBJECT_NAME}'
                setattr(
                    cls, create_method, classmethod(create_nested_resource)
                )

            elif operation == "retrieve":

                def retrieve_nested_resource(cls, id, nested_id, **params):
                    url = getattr(cls, resource_url_method)(id, nested_id)
                    return getattr(cls, resource_request_method)(
                        "get", url, resource, **params
                    )

                retrieve_method = f'retrieve_{resource.OBJECT_NAME}'
                setattr(
                    cls, retrieve_method, classmethod(retrieve_nested_resource)
                )

            elif operation == "update":

                def modify_nested_resource(cls, id, nested_id, **params):
                    url = getattr(cls, resource_url_method)(id, nested_id)
                    return getattr(cls, resource_request_method)(
                        "patch", url, resource, **params
                    )

                modify_method = f'modify_{resource.OBJECT_NAME}'
                setattr(
                    cls, modify_method, classmethod(modify_nested_resource)
                )

            elif operation == "delete":

                def delete_nested_resource(cls, id, nested_id, **params):
                    url = getattr(cls, resource_url_method)(id, nested_id)
                    return getattr(cls, resource_request_method)(
                        "delete", url, resource, **params
                    )

                delete_method = f'delete_{resource.OBJECT_NAME}'
                setattr(
                    cls, delete_method, classmethod(delete_nested_resource)
                )

            elif operation == "list":

                def list_nested_resources(cls, id, **params):
                    url = getattr(cls, resource_url_method)(id)
                    return getattr(cls, resource_request_method)(
                        "get", url, resource, **params
                    )

                list_method = f'list_{resource.OBJECT_NAME}'
                setattr(cls, list_method, classmethod(list_nested_resources))

            else:
                raise ValueError("Unknown operation: %s" % operation)

        return cls

    return wrapper
