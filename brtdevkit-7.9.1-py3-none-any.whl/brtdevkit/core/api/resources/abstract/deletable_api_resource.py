""" deletable_api_resource.py - implements APIResource class.
class for any API bindings which can be deleted

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

import functools

from brtdevkit.core.api.resources.abstract import APIResource
from brtdevkit.core.api.swagger import include_docs


class class_method_variant(object):
    """
    This class allows a method to be called as both a class and an instance method.
    """

    def __init__(self, class_method_name):
        self.class_method_name = class_method_name

    def __call__(self, method):
        self.method = method
        return self

    def __get__(self, obj=None, objtype=None):
        @functools.wraps(self.method)
        def _wrapper(*args, **kwargs):
            if obj is not None:
                return self.method(obj, *args, **kwargs)
            else:
                class_method = getattr(objtype, self.class_method_name)
                return class_method(*args, **kwargs)

        return _wrapper


class DeletableAPIResource(APIResource):

    def __init_subclass__(cls, **kwargs):
        """
        Runs each time this base class is subclassed, attaches a `.explain` function to each
        API binding this base class provides, pulling the documentation from an OpenAPI specification.
        """
        super().__init_subclass__(**kwargs)
        try:
            ENDPOINT = cls.ENDPOINT
            OBJECT_NAME = cls.OBJECT_NAME
            detail_endpoint = ENDPOINT + "/{" + OBJECT_NAME + "_id}"
        except AttributeError:
            # No ENDPOINT variable is present on the subclass
            return
        wrapper = include_docs(detail_endpoint, "delete")
        class_wrapper = class_method_variant("_cls_delete")
        # Wrap the original class method in a decorator that will include docs at `.delete.explain()`
        cls.delete = wrapper(cls.delete)
        # Now wrap this function in the `class_method_variant` wrapper
        cls.delete = class_wrapper(cls.delete)

    @classmethod
    def _cls_delete(cls, sid, **params):
        response = cls.request("delete", f"{cls.ENDPOINT}/{sid}", **params)
        return cls(response.data, **params)

    def delete(self, **params):
        response = self.request("delete", self.instance_url, params)
        self.refresh_from(response.data)
