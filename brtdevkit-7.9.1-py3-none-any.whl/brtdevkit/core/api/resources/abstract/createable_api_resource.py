""" creatable_api_resource.py - implements APIResource class.
class for any API bindings which can be created

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import APIResource
from brtdevkit.core.api.swagger import include_docs


class CreateableAPIResource(APIResource):

    def __init_subclass__(cls, **kwargs):
        """
        Runs each time this base class is subclassed, attaches a `.explain` function to each
        API binding this base class provides, pulling the documentation from
        an OpenAPI specification.
        """
        super().__init_subclass__(**kwargs)
        try:
            ENDPOINT = cls.ENDPOINT
        except AttributeError:
            # No ENDPOINT variable is present on the subclass
            return
        wrapper = include_docs(ENDPOINT, "post")
        cls.create = wrapper(cls.create)

    @classmethod
    def create(cls, **params):
        """
        Args:
            params (dict) : any extra parameters
        Returns:
            APIObject
        """
        response = cls.request("post", cls.ENDPOINT, params, headers=None)
        return cls(response.data, **params)
