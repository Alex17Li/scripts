""" listable_api_resource.py - implements APIResource class.
class for any API bindings which is listable

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

from brtdevkit.core import ListObject
from brtdevkit.core.api.error import InvalidRequestError
from brtdevkit.core.api.resources.abstract import APIResource
from brtdevkit.core.api.swagger import include_docs


class ListableAPIResource(APIResource):

    def __init_subclass__(cls, **kwargs):
        """
        Runs each time this base class is subclassed, attaches a `.explain` function to each
        API binding this base class provides, pulling the documentation from
        an OpenAPI specification.
        """
        super().__init_subclass__(**kwargs)
        try:
            ENDPOINT = cls.ENDPOINT
        except AttributeError:
            # No ENDPOINT variable is present on the subclass
            return
        wrapper = include_docs(ENDPOINT, "get")
        cls.list = wrapper(cls.list)

    @classmethod
    def auto_paging_iter(cls, *args, **params):
        return cls.list(*args, **params).auto_paging_iter()

    @classmethod
    def list(cls, **params):
        """
        Args:
            params (dict) : any extra url parameters
        Returns:
            generator : generator to iterate over list values
        """
        response = cls.request("get", cls.ENDPOINT, params)
        # add appropriate object types in the response
        # to convert it into proper object
        if not response:
            raise InvalidRequestError(f"Matching resource not found: params={params}")
        response.data['data'] = [cls(item) for item in response.data['data']]
        response.data['params'] = params  # store req param, so it can be reused in auto_paging_iter
        return ListObject(response.data)
