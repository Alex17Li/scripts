""" http_client.py - a wrapper around requests

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""
import threading

import requests


class HTTPClient(object):
    name = requests.__name__

    def __init__(self, timeout=80, session=None):
        self._thread_local = threading.local()
        self._session = session
        self._timeout = timeout

    def request(self, method, url, headers=None, post_data=None, stream=False, **kwargs):
        if getattr(self._thread_local, "session", None) is None:
            self._thread_local.session = self._session or requests.Session()

        return self._thread_local.session.request(
            method,
            url,
            headers=headers,
            json=post_data,
            timeout=self._timeout,
            stream=stream,
            **kwargs
        )

    def close(self):
        if getattr(self._thread_local, "session", None) is not None:
            self._thread_local.session.close()
