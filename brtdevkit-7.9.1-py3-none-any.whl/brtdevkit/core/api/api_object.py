""" api_object.py : base class for Aletheia's API bindings
                    this class converts APIResponse into APIObject
                    and provides object attribute "type" access to the response contents

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

import json


class APIObject(dict):
    def __init__(self, values):
        """
          Args:
              values (dict): the key value pairs to initialize the object with
        """
        super().__init__(values)
        self.refresh_from(values)

    def __setattr__(self, k, v):
        """
            converts json response keys and values into object attributes
        """
        if k[0] == "_" or k in self.__dict__:
            return super(APIObject, self).__setattr__(k, v)
        self[k] = v
        return None

    def __getattr__(self, k):
        """
            provides access to object attributes
        """
        try:
            return self[k]
        except KeyError as err:
            raise AttributeError(*err.args)

    def refresh_from(self, values):
        for k, v in values.items():
            if isinstance(v, dict):
                v = type(self)(v)
            super().__setitem__(k, v)

    def __str__(self):
        return json.dumps(self.to_dict_recursive(), sort_keys=True, indent=2)

    def to_dict(self):
        return {**self}

    def to_dict_recursive(self):
        d = self.to_dict()
        for k, v in d.items():
            if isinstance(v, APIObject):
                d[k] = v.to_dict_recursive()
        return d
