"""api_response.py : a wrapper class to convert JSON response into specific format,
                    so response can be converted into APIObjects.
                    caller of this class is responsible of catching json exception because
                    this also tries to load response_body as json

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

import json


class APIResponse(object):
    def __init__(self, body, code, headers, format="json"):
        self.body = body
        self.code = code
        self.headers = headers
        # return the raw body, and try to parse JSON response
        self.body = body
        if format == "json":
            self.data = json.loads(body or "{}")  # for empty body in successful requests
        else:
            self.data = None

    @property
    def request_id(self):
        return self.headers.get('request-id', None)
