"""error.py - this module is centralized place to define all API errors

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""


class APIError(Exception):
    """Base API Exception class.
    """
    def __init__(self, message=None, http_body=None, http_status=None, headers=None):
        super().__init__(message)

        self.message = message
        self.http_body = http_body
        self.http_status = http_status
        self.headers = headers or {}
        self.request_id = self.headers.get("request-id", None)

    def __str__(self):
        msg = str(self.message) if self.message else "<empty message>"
        return f"Request {self.request_id}: {msg}" if self.request_id else msg

    def __repr__(self):
        return f"{self.__class__.__name__}" \
               f"(message={self.message}, http_body={self.http_body}, " \
               f"http_status={self.http_status}, request_id={self.request_id})"


class APIConnectionError(APIError):
    def __init__(self, should_retry=False, **kwargs):
        super().__init__(**kwargs)
        self.should_retry = should_retry


class ServiceUnavailableError(APIError):
    pass


class InvalidRequestError(APIError):
    pass


class ResourceAlreadyExistsError(APIError):
    pass


class AuthenticationError(APIError):
    pass


class ForbiddenError(APIError):
    pass


class BadRequestError(APIError):
    pass


STATUS_CODE_TO_ERROR = {
    400: BadRequestError,
    401: AuthenticationError,
    403: ForbiddenError,
    404: InvalidRequestError,
    405: InvalidRequestError,
    409: ResourceAlreadyExistsError,
    503: ServiceUnavailableError
}
