"""
Utilities for interfacing with a Swagger/OpenAPI specification file,
including adding docs to relevent API bindings.

Authors:
    Corey Sutphin <corey.sutphin@bluerivertech.com>

Copyright 2021, Blue River Technology
"""
import logging

import yaml

from brtdevkit.core.api.api_requestor import APIRequestor

# Global variable to hold the OpenAPI specification file for the Tartarus API
API_SPEC = None
API_SPEC_ENDPOINT = "/apispec_1.json"

logger = logging.getLogger('brtdevkit')


class colors:
    """
    Used to format the color of text in the terminal
    """
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def get_api_spec():
    return API_SPEC


def set_api_spec(spec):
    global API_SPEC
    API_SPEC = spec


def fetch_api_spec():
    """Fetch the OpenAPI specification file from the server and cache it."""
    requestor = APIRequestor()
    resp = requestor.request(url=API_SPEC_ENDPOINT, method="get")
    return resp.data


def get_endpoint_docs(endpoint, method):
    """Construct a help string from an OpenAPI specification for the given endpoint and HTTP method.
    Args:
        endpoint (str) : Endpoint for the API call, ex: '/images'
        method (str) : The HTTP method to send to the endpoint, ex: 'post'
    Returns:
        (str) - The help text for the endpoint/method
    """
    # If the API specification is not cached, pull it from the server.
    if not API_SPEC:
        spec = fetch_api_spec()
        set_api_spec(spec)
    help_string = "\n"
    paths = API_SPEC["paths"]
    endpoint_docs = paths.get(endpoint, {})
    action_docs = endpoint_docs.get(method)

    if not endpoint_docs or not action_docs:
        logger.warning(
            f"Attempted to access documentation for a {method.upper()} "
            f"request to {endpoint} that does not exist."
        )
        return ""

    # Write the summary, endpoint, and HTTP method
    summary = action_docs.get("summary", "").replace("<br/>", "\n")
    help_string += f"{colors.BOLD}{summary}{colors.ENDC}\n"
    help_string += (
        f"Endpoint: {colors.BOLD}{endpoint}{colors.ENDC}\n"
        f"HTTP Method: {colors.BOLD}{method.upper()}{colors.ENDC}\n"
    )

    # Write the description containing Authentication and Permission information
    description = action_docs.get("description", "").replace("<br/>", "\n")
    help_string += f"{description}"

    # Write the parameters for this endpoint
    params = action_docs.get("parameters", [])
    path_params = [p for p in params if p["in"] == "path"]
    query_params = [p for p in params if p["in"] == "query"]
    body_params = [p for p in params if p["in"] == "body"]
    if path_params:
        help_string += f"\n{colors.BOLD}Path Parameters{colors.ENDC}"
        help_string += f"\n{yaml.dump(path_params)}"
    if query_params:
        help_string += f"\n{colors.BOLD}Query Parameters{colors.ENDC}"
        help_string += f"\n{yaml.dump(query_params)}"
    if body_params:
        help_string += f"\n{colors.BOLD}Request Body{colors.ENDC}"
        definitions = API_SPEC["definitions"]
        for param in body_params:
            body_schema = param.get("schema", {})
            if body_schema:
                ref = body_schema.get("$ref")
                if ref:
                    # Extract the schema properties from the definition found in $ref
                    schema_name = ref.split("/")[-1]
                    schema = definitions.get(schema_name)
                    help_string += f"\n{yaml.dump(schema)}"
                else:
                    # Body schema has properties but no defined $ref
                    properties = body_schema.get('properties', {})
                    help_string += f"\n{yaml.dump(properties)}"
            else:
                help_string += f"\n{yaml.dump(param)}"

    return help_string


def include_docs(endpoint, method):
    """
    Decorator that adds a `.explain` method to the wrapped function.
    Calling the .explain method will print the docs for the supplied endpoint/action.

    Args:
        endpoint (str) : Endpoint for the API call
        method (str) : The HTTP method to send to the endpoint
    Returns:
        (function) - The wrapped function containing the `.explain` method
    """
    def wrap(f):
        def _wrapper(*args, **kwargs):
            return f(*args, **kwargs)
        _wrapper.explain = lambda: print(get_endpoint_docs(endpoint, method))
        return _wrapper
    return wrap
