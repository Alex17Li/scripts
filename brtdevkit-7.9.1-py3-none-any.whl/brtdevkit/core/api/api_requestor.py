"""api_requestor.py - a wrapper class to call Aletheia specific APIs.
    to call any Aletheia specific APIs this class needs to be used.
    this class takes care of getting and refreshing access_tokens from Aletheia server
    and generates appropriate headers and converts the responses into appropriate objects.

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

import json
import platform
import time
import uuid
from json.decoder import JSONDecodeError
from urllib.parse import urlencode, urlsplit, urlunsplit

import requests

import brtdevkit
from brtdevkit import config
from brtdevkit.core.api import error, http_client
from brtdevkit.core.api.api_response import APIResponse
from brtdevkit.util.logger import Logger

log = Logger('APIRequestor')


class APIRequestor:
    access_token = None

    def __init__(self):
        self._client = http_client.HTTPClient()

    def request(self, method, url, params=None, headers=None, format="json"):
        """
        Makes an API call for the given url. converts response object to APIResource.
            Args:
                method (str) : htttp method (get, post etc)
                url (str) : url for the resource
                params (dict) : url params
                headers (dict) : if extra headers needed to supply in addition of default headers
                format (str): expected format of the response, "json" or "text"
            Returns:
                resp (APIResponse) : APIResponse object
        """

        rbody, rcode, rheaders = self.request_with_retries(method.lower(), url, params, headers)
        resp = self.interpret_response(rbody, rcode, rheaders, format=format)
        return resp

    def handle_error_response(self, rbody, rcode, resp, rheaders):
        """
        Handles error response and raises appropriate exceptions from error.py.
            Args:
                rbody (str) : response body
                rcode (str) : http status code
                resp (str) : response message
                rheaders (str) : response headers
            Raises:
                APIError: raises type of an APIError
        """
        try:
            error_data = resp.get("error") or json.loads(rbody)
        except (KeyError, TypeError):
            error_data = (
                f"Invalid response object from API: "
                f"{rbody} (HTTP response code was {rcode})"
            )
            raise error.APIError(error_data, rbody, rcode, rheaders)

        log.error(f"API error received | error_code : {rcode}, error_message : {error_data}")
        error_class = error.STATUS_CODE_TO_ERROR.get(rcode, error.APIError)
        raise error_class(error_data, rbody, rcode, rheaders)

    def request_headers(self, method):
        """
        Returns Aletheia specific request headers.
            Args:
                 method (str) : http method
            Returns:
                dict : returns request headers dict
        """
        if not (brtdevkit.api_key or brtdevkit.refresh_token):
            raise error.AuthenticationError(
                'Neither a refresh token nor an api key was found. '
                f'Please add a refresh tokens in your ~/.brt/{config.CREDENTIALS_FILENAME}. '
                'you can get a refresh token from https://aletheia.brtws.com/profile')
        ua = {
            "bindings_version": brtdevkit.__version__,
            "lang": "python",
            "publisher": "brtdevkit",
            "httplib": self._client.name,
        }
        for attr, func in [
            ("lang_version", platform.python_version),
            ("platform", platform.platform),
            ("uname", lambda: " ".join(platform.uname()))
        ]:
            try:
                ua[attr] = func()
            except Exception as e:
                ua[attr] = f'!! {e}'

        headers = {
            "X-brtdevkit-Client-User-Agent": json.dumps(ua),
            "User-Agent": f"brtdevkit {brtdevkit.__version__}",
        }
        if brtdevkit.refresh_token:
            if not self.access_token:
                self._set_access_token(self._client)
            headers["Authorization"] = f"Bearer {self.access_token}"
        else:  # if brtdevkit.api_key is not null
            headers["API-Key"] = brtdevkit.api_key

        if method == "post":
            headers["Content-Type"] = "application/json"
            headers.setdefault("Idempotency-Key", str(uuid.uuid4()))

        return headers

    @classmethod
    def _set_access_token(cls, client):
        """
        Fetches new access token from Aletheia server.
            Returns:
                 str : access tokens
            Raises:
                AuthenticationError : on failure to get API keys
                InvalidRequestError : on failure to load response json
        """
        # get api_key from refresh_token
        if not brtdevkit.refresh_token:
            raise error.AuthenticationError(
                'Missing Refresh tokens. Can not get access_tokens. '
                f'Please add refresh tokens in your ~/.brt/{config.CREDENTIALS_FILENAME}')
        token_url = f'{brtdevkit.api_base}/oauth/token'
        token_headers = {'refresh_token': brtdevkit.refresh_token}
        response = client.request(
            'post', token_url, headers={"Content-Type": "application/json"}, post_data=token_headers
        )
        try:
            rbody = json.loads(response.content)
        except JSONDecodeError:
            raise error.InvalidRequestError(f"Could not retrieve access tokens from: {token_url}")

        if response.status_code > 200:
            raise error.AuthenticationError(
                f"Failed to get API keys. error: {rbody.get('message')}"
            )
        cls.access_token = rbody['access_token']

    def request_with_retries(self, method, url, params=None, supplied_headers=None):
        """
        Mechanism for issuing an API call, also retries on APIConnectionError.
            Args:
                method (str) : http method
                url (str) : resource url
                params (dict) : url params
                supplied_headers (dict) : additional headers if needed for the request
            Returns:
                rbody (str) : response body
                rcode (str) : http status code
                rheaders (str) : response headers
            Raises:
                APIConnectionError: if response is none after retries

        """
        abs_url = f"{brtdevkit.api_base}{url}"
        if method == "get":
            if params:
                encoded_params = urlencode(params)
                scheme, netloc, path, base_query, fragment = urlsplit(abs_url)
                if base_query:
                    encoded_params = f"{base_query}&{encoded_params}"
                abs_url = urlunsplit((scheme, netloc, path, encoded_params, fragment))
            post_data = None
        elif method in ["post", "put", "patch", "delete"]:
            post_data = params or {}
        else:
            raise error.APIConnectionError(
                message=(
                    f"Unrecognized HTTP method {method}. "
                    "This may indicate a bug in the API bindings."))

        retry_sleep_time_base = 2
        exponential_backoff_base = 2
        for attempt in range(brtdevkit.max_network_retries):
            headers = self.request_headers(method)
            if supplied_headers is not None:
                for key, value in supplied_headers.items():
                    headers[key] = value

            log.debug(f"Request to api: {method}, path = {abs_url}")
            if method == "post":
                log.debug(f"Post details: {post_data}")

            # Set the retry backoff time if we are not on the last attempt
            retry_sleep_time = retry_sleep_time_base * exponential_backoff_base ** attempt \
                if attempt < brtdevkit.max_network_retries - 1 else 0
            try:
                response = self._client.request(method, abs_url, headers, post_data)
                rbody, rcode, rheaders = response.content, response.status_code, response.headers
            except TypeError:
                log.error("""Warning: It looks like your installed version of the
                    "requests" library is not compatible with brtdevkit\'s
                    usage thereof. (HINT: The most likely cause is that
                    your "requests" library is out of date. You can fix
                    that by running "pip install -U requests".)""")
                raise
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                log.error(f"Timeout/Connection error, sleeping for {retry_sleep_time} second(s)")
                time.sleep(retry_sleep_time)
                log.debug(f"Initiating retry #{attempt + 1} for request {method} {url}")
                continue
            except requests.exceptions.RequestException:
                log.error("Unexpected error communicating with API Server")
                raise

            if rcode == 401:
                log.error(f'API Authentication failed. rcode: {rcode}, message: {rbody}')
                if brtdevkit.refresh_token:
                    log.info('API access token expired. Refreshing tokens now.')
                    self._set_access_token(self._client)
                elif brtdevkit.api_key:
                    raise error.AuthenticationError(
                        f"API key authentication failed with key={brtdevkit.api_key}")
                continue

            if rcode in (502, 503, 504):
                log.error(
                    f"API server responded with retryable 5XX rcode: {rcode}, message: {rbody}. "
                    f"Sleeping for {retry_sleep_time} second(s).")
                time.sleep(retry_sleep_time)
                log.debug(f"Initiating retry #{attempt + 1} for request {method} {url}")
                continue

            log.debug(f"API response. url: {abs_url}, response_code: {rcode}")
            if rheaders.get('Content-Type', None) == 'application/json':
                log.debug(f"API response body: {rbody}")
            return rbody, rcode, rheaders

        raise error.APIConnectionError(
            message=f"API server is unresponsive after {brtdevkit.max_network_retries} retries")

    def interpret_response(self, rbody, rcode, rheaders, format="json"):
        """
        Converts json response into APIResponse class and raise exception if unable to convert.
            Args:
                rbody (str) : response body
                rcode (str) : http status code
                rheaders (str) : response headers
                format (str): expected format of the response, "json" or "text"
            Returns:
                resp (APIResponse) : APIResponse class
            Raises:
                APIError : APIError based on http status code
        """
        try:
            resp = APIResponse(rbody, rcode, rheaders, format=format)
        except Exception:
            error_data = ("Invalid response object from API: "
                          f"{rbody} (HTTP response code was {rcode})")
            raise error.APIError(error_data, rbody, rcode, rheaders)
        if not (200 <= rcode < 300):
            self.handle_error_response(rbody, rcode, resp.data, rheaders)

        return resp
