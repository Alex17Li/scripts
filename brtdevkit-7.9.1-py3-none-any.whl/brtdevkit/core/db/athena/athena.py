"""athena.py - class to connect to AWS Athena

Author:
    Corey Sutphin <corey.sutphin@bluerivertech.com>
    Erin Kim <erin.kim@bluerivertech.com>
    Kirill Makhonin <kirill.makhonin@bluerivertech.com>
Copyright 2021, Blue River Technology

The goal is a light-weight interface over AWS Data Wrangler(wrangler) to support end-user querying.
Assumptions:
    1. Most users will never need to know or have access to wrangler
    2. A interface similar to what already exists in the devkit for connecting to Mongo would be preferred
"""
import json
import os

import awswrangler as wr
import pandas as pd

import brtdevkit.config as config
from brtdevkit.util.aws.refreshable_boto_session import AutoRefreshBotoSession

DEFAULT_DATABASE_ENV_NAME = "BRT_DEFAULT_ATHENA_DATABASE"


class AthenaClient:

    DEFAULT_CATALOG_NAME = "mesa-data-catalog"
    DEFAULT_DATABASE = f"{DEFAULT_CATALOG_NAME}-{config.BASE_ENV}"
    DEFAULT_MAX_CACHE_SECONDS = 900
    DEFAULT_MAX_CACHE_QUERY_INSPECTIONS = 100

    def __init__(self):
        self.wr = wr
        self.boto3_session = AutoRefreshBotoSession().get_session()
        self.default_database = os.getenv(DEFAULT_DATABASE_ENV_NAME, self.DEFAULT_DATABASE)

    @classmethod
    def _deserialize_json_columns(cls, df):
        """Find all columns with a `__json` suffix and deserialize them.

        Args:
            df (pandas.DataFrame): the dataframe for which we are deserializing JSON columns

        Returns:
            pandas.DataFrame: the dataframe with deserialized JSON columns
        """
        columns = df.columns
        for col in columns:
            if col.endswith('__json'):
                df[col.replace("__json", "")] = df[col].apply(
                    lambda x: None if pd.isna(x) else json.loads(x))
                df.drop(col, axis=1, inplace=True)

        return df

    @classmethod
    def _create_deserialize_json_generator(self, df_iterator):
        """Wraps a given iterator of dataframes so that we can deserialize JSON
        columns each time a dataframe is yielded.

        Args:
            df_iterator (iterator): an iterator of dataframes
        Returns
            iterator: an iterator of dataframes with deserialized JSON columns
        """
        for df in df_iterator:
            yield self._deserialize_json_columns(df)

    def get_df(
        self,
        query_string,
        chunksize=None,
        use_cache=False,
        max_cache_seconds=None,
        max_cache_query_inspections=None,
        database=None,
        ctas_approach=True,
        deserialize_json_cols=False
    ):
        """Get results of an Athena SQL query as a Pandas DataFrame.
        Args:
            query_string (str): The SQL string containing the query to execute.
            chunk_size (int): If passed, returns an iterator that contains results in batches. Each batch is its own dataframe.
                              Defaults to None, which indicates no batching.
            use_cache (bool): Whether or not to look for cached results for this query. Defaults to False.
            max_cache_seconds (int): Only used if use_cache=True. Only queries executed in the last
                                     `max_cache_seconds` seconds will be considered for cached results.
                                     Defaults to 900 seconds.
            max_cache_query_inspections (int): Only used if use_cache=True. Number of past queries to examine
                                               for cached results. Defaults to 100 queries.
            database (str): The name of the database the Athena query should execute in. Defaults to the
                            primary data lake database for the current environment.
            ctas_approach (bool): Whether the client should use Create Table As Select (ctas) approach.
                                  see https://github.com/awslabs/aws-data-wrangler/blob/main/tutorials/006%20-%20Amazon%20Athena.ipynb
            deserialize_json_cols (bool): Whether or not to deserialize JSON columns. Defaults to False.
        """
        args = {
            'sql': query_string,
            'database': database or self.default_database,
            'chunksize': chunksize,
            'ctas_approach': ctas_approach,
            'ctas_database_name': 'default',
            'boto3_session': self.boto3_session
        }
        if use_cache:
            args['max_cache_seconds'] = max_cache_seconds or self.DEFAULT_MAX_CACHE_SECONDS
            args['max_cache_query_inspections'] = (
                max_cache_query_inspections or self.DEFAULT_MAX_CACHE_QUERY_INSPECTIONS)

        result = self.wr.athena.read_sql_query(**args)
        if deserialize_json_cols:
            if chunksize:
                result = self._create_deserialize_json_generator(result)
            else:
                result = self._deserialize_json_columns(result)
        return result

    def list_databases(self):
        '''
        List all of the databases in Athena.

        Returns:
            pandas.DataFrame: a dataframe containing the names of the databases
        '''
        return self.wr.catalog.databases(boto3_session=self.boto3_session)

    def list_tables(self, database=None):
        '''
        List all of the tables in a given database.

        Args:
            database (str):
                The name of the database to list tables for.
                Defaults to the primary data lake database for the current
                environment.

        Returns:
            pandas.DataFrame: a dataframe containing the names of the tables
        '''
        database = database or self.default_database
        return self.wr.catalog.tables(database=database, boto3_session=self.boto3_session)

    def get_table(self, table, database=None):
        """
        Get the schema of a given table.

        Args:
            table (str): the name of the table

        Returns:
            pandas.Dataframe: a dataframe containing the schema of the table
        """
        database = database or self.default_database
        return self.wr.catalog.table(database=database, table=table, boto3_session=self.boto3_session)

    def get_table_types(self, table, database=None):
        '''
        Get the types of the columns in a given table.

        Args:
            table (str):
                the name of the table
            database (str):
                The name of the database to list tables for.
                Defaults to the primary data lake database for the current
                environment.

        Returns:
            (dict) a dict containing key/value pairs of column name and type for
            the given table.
        '''
        database = database or self.default_database
        return self.wr.catalog.get_table_types(database=database, table=table)
