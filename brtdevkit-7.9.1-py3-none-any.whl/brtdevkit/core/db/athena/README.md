# Exploratory Queries With AthenaClient

The `athena` module provides a Python interface to use Amazon Athena for querying the Mesa Data Lake(MDL). Please see the [Mesa Data Lake](https://bluerivertechnology.atlassian.net/wiki/spaces/MESA/pages/2542534695/Mesa+Data+Lake) wiki page for more information on the data lake in general.

There are additional examples of querying the lake in the [athena notebook](https://github.com/BlueRiverTechnology/brt-devkit/blob/develop/docs/source/notebooks/athena.ipynb) within this repo.


- [Exploratory Queries With AthenaClient](#exploratory-queries-with-athenaclient)
  - [Installation & Requirements](#installation--requirements)
  - [Quickstart](#quickstart)
  - [Usage](#usage)
    - [Writing the Query](#writing-the-query)
      - [Querying Timestamps](#querying-timestamps)
      - [Doing Joins](#doing-joins)
      - [Working with Objects and Arrays](#working-with-objects-and-arrays)
      - [Querying Lists](#querying-lists)
    - [IMPORTANT Best practices for Writing Queries](#important-best-practices-for-writing-queries)
    - [Executing the Query](#executing-the-query)
  - [Migrating from `DBConnector` and the `Query` Module](#migrating-from-dbconnector-and-the-query-module)
    - [JSON objects/arrays](#json-objectsarrays)
    - [Annotations and Artifacts are not automatically joined with Images](#annotations-and-artifacts-are-not-automatically-joined-with-images)
    - [Annotations not unwound on images](#annotations-not-unwound-on-images)
    - [Replication lag between Mongo and the Mesa Data Lake](#replication-lag-between-mongo-and-the-mesa-data-lake)
  - [API Reference](#api-reference)
    - [AthenaClient](#athenaclient)
      - [**Class Attributes**](#class-attributes)
      - [**Instance Attributes**](#instance-attributes)
      - [**Instance Methods**](#instance-methods)


## Installation & Requirements

- [`brt-devkit 4.19.0+`](https://github.com/BlueRiverTechnology/brt-devkit/blob/develop/docs/source/notebooks/introduction.ipynb)
- Python 3.8+ (Python 3.9 recommended)
- AWS credentials must either be set up locally(`/.aws/credentials` file) or available to be configured in a Boto3 session

## Quickstart

The client for querying the MDL is powered by [Athena](https://aws.amazon.com/athena/), which relies on the [Presto query engine](https://prestodb.io/).

This is what a typical query ran against Athena on brtdevkit would look like:

```python
from brtdevkit.core.db.athena import AthenaClient


lake = AthenaClient()

# List all tables in the Mesa database
lake.list_tables()

# Get the details of a specific table
lake.get_table("annotation_shasta")

query = '''
SELECT
    id, state, label_policy, style
FROM
    annotation_shasta
WHERE
    label_policy = '5eb48622e154067231d8121b' AND
    state = 'ok' AND
    style = 'pixelwise'
'''
df = lake.get_df(query)
```

## Usage

The flow to query and manipulate data works in 2 steps:
1. Write the SQL query string
2. Execute the query and directly download a packaged Pandas dataframe


### Writing the Query

Queries are written in ANSI SQL. In depth discussion of SQL is out of scope of these docs, but here are a few references:

* https://sqlzoo.net/wiki/SQL_Tutorial
* https://tutorialsinhand.com/tutorials/ansi-sql/basics-of-ansi-sql/table-in-sql.aspx



Here we'll list some common querying situations and give a helpful place to get started with some of your own queries.

#### Querying Timestamps

Use the `TIMESTAMP` operator to convert a string to a timestamp for comparison or equality.

```sql
SELECT id, created_at, robot_name
FROM image_shasta
WHERE created_at > TIMESTAMP '2022-04-22'
```

```sql
SELECT id, created_at, robot_name
FROM image_shasta
WHERE created_at BETWEEN TIMESTAMP '2022-04-22' AND '2022-04-30'
```

#### Doing Joins

```sql
SELECT image_shasta.id,
    image_shasta.robot_name,
    annotation_shasta.id AS annotation_id,
    annotation_shasta.s3_bucket AS annotation_s3_bucket,
    annotation_shasta.s3_key AS annotation_s3_key,
    annotation_shasta.style AS annotation_style,
    annotation_shasta.state AS annotation_state
FROM image_shasta
JOIN annotation_shasta ON image_shasta.id = annotation_shasta.image
WHERE image_shasta.robot_name = 'DCM12' AND
    annotation_shasta.style = 'pixelwise' AND
    annotation_shasta.state != 'labeling'
LIMIT 10
```


#### Working with Objects and Arrays

Objects and arrays in Mongo are converted to JSON strings before being stored in the data lake. Additionally we append a `__json` suffix to every column that is processed in this way, so an array field like `image.weeds` will be stored as `image.weeds__json`. There are a number of utilities available to help query and work with data stored as JSON:

* [Presto JSON functions and operators](https://prestodb.io/docs/current/functions/json.html)
* [Athena docs on querying JSON](https://docs.aws.amazon.com/athena/latest/ug/querying-JSON.html)
* [Athena docs on querying Arrays](https://docs.aws.amazon.com/athena/latest/ug/querying-arrays.html)


**Deserializing JSON strings within a Pandas DataFrame**

```python
import json
import pandas as pd
query = '''
SELECT id, weeds__json
FROM image_shasta
limit 10
'''
df = lake.get_df(query)
# Convert the JSON strings to Python objects, handling cases where there are NA values
df['weeds'] = df['weeds__json'].apply(lambda x: None if pd.isna(x) else json.loads(x))
```

**Deserializing ALL JSON fields within a Pandas DataFrame**

We can pass in `deserialize_json_cols=True` to our `get_df` call to convert all JSON fields. This will look for all fields that end in `__json` and deserialize them. It will drop the `__json` suffix from the column name so `weeds__json` -> `weeds`.
*Note that this is done AFTER the DataFrame has been loaded into memory and may be slow for millions of rows.*

```python
query = '''
SELECT id, weeds__json
FROM image_shasta
limit 10
'''
df = lake.get_df(query, deserialize_json_cols=True)
df["weeds"]
```

**Convert JSON string back to an array in SQL**

```python
query = '''
SELECT id, cast(JSON_PARSE(weeds__json) as ARRAY<VARCHAR>) as weeds
FROM image_shasta
LIMIT 10
'''
df = lake.get_df(query)
df['weeds]  # Should already be an array of strings
```

**Convert JSON string back to an object in SQL**

```sql
SELECT id, CAST(JSON_PARSE(gnss__json) AS ROW(coordinates ARRAY(DOUBLE), type VARCHAR)) as gnss
FROM image_shasta
LIMIT 10
```

**Extracting a single field from an object in SQL**

```sql
SELECT id, JSON_FORMAT(JSON_EXTRACT(gnss__json, '$.coordinates')) AS gnss_coords
FROM image_shasta
LIMIT 10
```

```sql
SELECT id, JSON_FORMAT(JSON_EXTRACT(gnss__json, '$.coordinates[0]')) AS longitude, JSON_FORMAT(JSON_EXTRACT(gnss__json, '$.coordinates[1]')) AS latitude
FROM image_shasta
LIMIT 10
```

#### Querying Lists

Querying by a list of values through Athena is simple unless the list is large. This is because **there is a 262,144 character length limit for SQL queries through Athena**. Large lists will exceed this length limit and throw an error. Below we'll show how to query with lists and how to get around this length limitation.

**Querying with a small list of values**
```python
id_list = [
  '1',
  '2',
  '3'
]
sql = f'''
SELECT id
FROM image_shasta
WHERE id IN ('{"', '".join(id_list)}')
'''
```

**Querying a large list via chunking**

With large lists, it is necessary to use multiple queries on smaller chunks of the list.

```python
import pandas as pd

# Chunking through a large list of UUIDs
images = pd.DataFrame()
uuids = [...]
batch_size = 10000
for i in range(0, len(uuids), batch_size):
    start = i
    end = start + batch_size
    chunk = uuids[start:end]
    sql = f'''
    SELECT id, robot_name
    FROM image_shasta
    WHERE uuid IN ('{"', '".join(chunk)}')
    '''
    temp = athena.get_df(sql)
    images = pd.concat([images, temp])
```

**Querying a list through a SQL Subquery**

If the list you are querying on is a field in another table, then you can utilize a subquery to get around
the SQL length limitation. For example, an Analysis object has an `image_uuids` parameter containing all the UUIDs related to the analysis. If we wanted all images tied to this analysis, we can do the following:

```python
analysis_id = '6196d80a560684363b23f4df'
sql = f'''
SELECT id, s3_path
FROM image_shasta
WHERE CONTAINS((
    SELECT cast(JSON_PARSE(analysis.image_uuids__json) as ARRAY<VARCHAR>)
    FROM analysis
    WHERE id = '{analysis_id}'
), uuid)
'''
df = athena.get_df(sql)
```

### IMPORTANT Best practices for Writing Queries

With great power comes great responsibility. The SQL interface will give you a ton of flexibility in how you write queries, but it is important to understand the best practices for writing queries to avoid unnecessary computation and data download.

1. Avoid using `SELECT *`. Instead limit your query to only the columns you need.
2. Use `LIMIT` when possible to limit the rows returned, especially if just poking around.

### Executing the Query

There are a number of parameters the `AthenaClient` exposes that you can take advantage of when executing a query with the `get_df` method.

```python
def get_df(
        self,
        query_string,
        chunksize=None,
        use_cache=False,
        max_cache_seconds=None,
        max_cache_query_inspections=None,
        database=None,
        ctas_approach=True
    ):
        """Get results of an Athena SQL query as a Pandas DataFrame.
        Args:
            query_string (str): The SQL string containing the query to execute.
            chunk_size (int): If passed, returns an iterator that contains results in batches. Each batch is its own dataframe.
                              Defaults to None, which indicates no batching.
            use_cache (bool): Whether or not to look for cached results for this query. Defaults to False.
            max_cache_seconds (int): Only used if use_cache=True. Only queries executed in the last
                                     `max_cache_seconds` seconds will be considered for cached results.
                                     Defaults to 900 seconds.
            max_cache_query_inspections (int): Only used if use_cache=True. Number of past queries to examine
                                               for cached results. Defaults to 100 queries.
            database (str): The name of the database the Athena query should execute in. Defaults to the
                            primary data lake database for the current environment.
            ctas_approach (bool): Whether the client should use Create Table As Select (ctas) approach.
                                  see https://github.com/awslabs/aws-data-wrangler/blob/main/tutorials/006%20-%20Amazon%20Athena.ipynb
            deserialize_json_cols (bool): Whether or not to deserialize JSON columns. Defaults to False.
        """
```

## Migrating from `DBConnector` and the `Query` Module

There are a few known pain points of migrating your previous queries using the old tooling to this new Athena client. We list a few of them here. Please reach out to Mesa if you are having issues.

### JSON objects/arrays

Arrays and objects are converted to JSON strings before being stored in the data lake. Please see the docs in the `Writing the Query` section for tips on working with JSONified objects and arrays.

### Annotations and Artifacts are not automatically joined with Images
When querying images through the Query module, joins were done behind the scenes to get annotation and artifact data within the image object. In the data lake images, annotations, and artifacts are separate tables and you must use join data together using JOIN statements in your SQL.

### Annotations not unwound on images

The `Query` module by default "unwound" annotations when you queried images. This is not the case when querying the image collection through Athena. If your code was relying on there being `N` rows for each image where `N = number of annotations for that image`, then you will need to account for that in your query or in your business logic.

### Replication lag between Mongo and the Mesa Data Lake

Currently there is a 24 hour period of lag between MongoDB and the Mesa Data Lake. If an image was ingested today at 11AM it will be available in the lake the next day by about 9AM PST. We are working to shorten and eventually do away with this replication lag entirely.

## API Reference

### AthenaClient

**Class**

```
AthenaClient()
```

#### **Class Attributes**

None

#### **Instance Attributes**

None

#### **Instance Methods**

| name                                                                                                                                                                              | description                                                                  |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `get_df(query_string, chunksize=None, use_cache=False, max_cache_seconds=None, max_cache_query_inspections=None, database=None, ctas_approach=True, deserialize_json_cols=False)` | (pandas.DataFrame) Get results of an Athena SQL query as a Pandas DataFrame. |
| `list_databases()`                                                                                                                                                                | (pandas.DataFrame) List all of the databases in Athena.                      |
| `list_tables(database=None)`                                                                                                                                                      | (pandas.DataFrame) List all of the tables in a given database.               |
| `get_table(table, database=None)`                                                                                                                                                 | (pandas.DataFrame) Get the schema of a given table.                          |
| `get_table_types(table, database=None)`                                                                                                                                           | (dict) Get the types of the columns in a given table.                        |
