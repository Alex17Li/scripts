"""sql.py A lightweight abstraction layer over sql statements

Author: Erin Kim <erin.kim@bluerivertech.com>
Copyright 2021, Blue River Technology
"""


class SQLQuery:
    def __init__(self, table, columns=None):
        self.table = table
        self.columns = ",".join(columns) if columns else "*"
        self.filters = None
        self._limit = None
        self._join = None
        self._join_condition = None

    def where(self, *sql_filters):
        self.filters = sql_filters
        return self

    def limit(self, limit):
        self._limit = limit
        return self

    def join(self, table, condition):
        self._join = table
        self._join_condition = condition
        return self

    def __repr__(self):
        stmt = f"SELECT {self.columns}\nFROM {self.table}\n"
        if self._join:
            stmt = stmt + f"JOIN {self._join.name} ON {self._join_condition}\n"
        if self.filters:
            filters = [str(condition) for condition in self.filters]
            stmt = stmt + f"WHERE {' AND '.join(filters)}\n"
        if self._limit:
            stmt = stmt + f"LIMIT {self._limit}"

        return stmt


class Table:
    def __init__(self, database, name, schema):
        self.database = database
        self.name = name
        self.schema = schema
        self.columns = {
            col: Column(table=name, name=col, _type=_type) for col, _type in schema.items()}

    def __getattr__(self, column):
        if column in self.columns:
            return self.columns[column]
        else:
            super().__getattribute__(column)

    def select(self, *columns):
        return SQLQuery(self.name, columns)


class Column:
    def __init__(self, table, name, _type):
        self.table = table
        self.name = name
        self._type = _type
        # TODO: map athena type to python type
        self.python_type = None

    def __repr__(self):
        return f"{self.table}.{self.name}"

    def __eq__(self, value):
        if value is None:
            return ColumnOperator(self, "IS", value)
        return ColumnOperator(self, '=', value)

    def __ne__(self, value):
        if value is None:
            return ColumnOperator(self, "IS NOT", value)
        return ColumnOperator(self, '!=', value)

    def __gt__(self, value):
        return ColumnOperator(self, '>', value)

    def __ge__(self, value):
        return ColumnOperator(self, '>=', value)

    def __lt__(self, value):
        return ColumnOperator(self, '<', value)

    def __le__(self, value):
        return ColumnOperator(self, '<=', value)


class ColumnOperator:
    def __init__(self, column, operator, value):
        self.column = column
        self.operator = operator
        self.value = self.check_values(value)

    def __repr__(self):
        return f'{self.column} {self.operator} {self.value}'

    def check_values(self, value):
        if value is None:
            return "NULL"
        if isinstance(value, Column):
            return value
        if isinstance(value, str):
            return f"'{value}'"
        # TODO (erin): implement a python type attribute so we can do type check validations
        # if not isinstance(self.column.python_type, value):
        #     raise ValueError(f"type is {self.column.python_type} but value is {type(value)}")
        return value


class SQLQueryError(BaseException):
    pass
