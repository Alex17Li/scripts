"""
Utility module for working with pandas dataframes.

Authors:
    - JC Lanoë <jc.lanoe@bluerivertech.com>

Copyright 2022, Blue River Technology
"""
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from brtdevkit.util.aws.s3 import S3
from brtdevkit.util.logger import Logger

log = Logger('brtdevkit.util.dataframe_util')


def download_assets(
        df,
        directory,
        bucket_column_name='s3_bucket',
        key_column_name='s3_key'):
    """
    Downloads s3 assets of a given list

    Args:
        df (pandas.DataFrame): Dataframe containing the assets to download.
        directory (PathLike | str): the path that the assets will be saved to.
        bucket_column_name (str): the name of the column containing the s3 bucket.
        key_column_name (str): the name of the column containing the s3 key.

    Example:
        >>> athena = AthenaClient()
        >>> df = athena.get_df("SELECT * FROM annotation_shasta WHERE state = 'ok' LIMIT 1000")
        >>> download_assets(df, '/home/brt/data/assets')
    """
    s3_client = S3()

    def download(params):
        bucket, key, _id = params
        filepath = Path(f'{directory}/{key}')
        filepath.parent.mkdir(parents=True, exist_ok=True)
        successful_download = s3_client.download_file(
            bucket,
            key,
            f'{directory}/{key}',
        )
        if not successful_download:
            log.warn(
                f"Failed to download asset for row {_id} ({bucket}{key})"
            )
        return successful_download

    assets = []
    for _, row in df.iterrows():
        if any(key not in row for key in (bucket_column_name, key_column_name)):
            log.warn(f"{row['id']} has no s3 assets to download")
        elif isinstance(row[bucket_column_name], pd._libs.missing.NAType) \
                or isinstance(row[key_column_name], pd._libs.missing.NAType):
            log.warn(f"{row['id']} has no s3 assets to download")
        else:
            assets.append(
                (row[bucket_column_name], row[key_column_name], row['id'])
            )

    max_workers = multiprocessing.cpu_count() * 4
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        with tqdm(total=len(assets)) as pbar:
            try:
                futures = {
                    executor.submit(download, asset): asset for asset in assets
                }
                for _ in as_completed(futures):
                    pbar.update()
            except KeyboardInterrupt:
                log.warn('Cancelling download...')
                for future in futures:
                    future.cancel()
                executor.shutdown(wait=True)
                log.warn('Download cancelled')
                return None
            log.info(f'Downloaded {len(assets)} assets in {directory}')
