"""s3.py - class to download and retrieve files from s3

Author: Asav Patel <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""

import logging
import multiprocessing
from multiprocessing import cpu_count
from pathlib import Path

import botocore
from tqdm import tqdm

from brtdevkit.util.aws import AWS_REGION_DEFAULT
from brtdevkit.util.aws.refreshable_boto_session import AutoRefreshBotoSession

log = logging.getLogger('s3')


class S3(object):
    def __init__(
            self, region_name=AWS_REGION_DEFAULT, aws_access_key_id=None,
            aws_secret_access_key=None, max_pool_connections=25):
        client_config = botocore.config.Config(max_pool_connections=max_pool_connections)
        self.session = AutoRefreshBotoSession().get_session()
        self.client = self.session.client(
            's3',
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            config=client_config
        )

    def upload_file(self, bucket_name, key, file_path):
        """Upload a file object to an S3 bucket.

        Args:
            bucket_name (str): The S3 bucket name.
            key (str): The S3 object key.
            file_path (str): The path to the file to upload.
        Returns:
            bool - Whether the upload was successful or not.
        """
        try:
            with open(file_path, 'rb') as fileobj:
                self.client.upload_fileobj(Fileobj=fileobj, Bucket=bucket_name, Key=key)
            return True
        except botocore.exceptions.ClientError as e:
            log.error(f'S3 ClientError: {e}, {bucket_name}/{key}')
            return False

    def upload_fileobj(self, bucket_name, key, fileobj):
        """Upload a file object to an S3 bucket.

        Args:
            bucket_name (str): The S3 bucket name.
            key (str): The S3 object key.
            fileobj_path (BytesIO): The local path to the file object to upload.
        Returns:
            bool - Whether the upload was successful or not.
        """
        try:
            self.client.upload_fileobj(Fileobj=fileobj, Bucket=bucket_name, Key=key)
            return True
        except botocore.exceptions.ClientError as e:
            log.error(f'S3 ClientError: {e}, {bucket_name}/{key}')
            return False

    def download_fileobj(self, bucket_name, key, fileobj):
        """Download a file object from an S3 bucket to a file object in memory.

        Args:
            bucket_name (str): The S3 bucket name.
            key (str): The S3 object key.
            fileobj (io.IOBase): A file-like obj (implements a read and a write)
        Returns:
            bool - Whether the download was successful or not.
        """
        try:
            self.client.download_fileobj(Bucket=bucket_name, Key=key, Fileobj=fileobj)
            # set file pointer to begining of the file
            fileobj.seek(0)
            return True
        except botocore.exceptions.ClientError as e:
            log.error(f'S3 ClientError: {e}, {bucket_name}/{key}')
            return False

    def download_file(self, bucket_name, key, target_path):
        """Download a file object from an S3 bucket to a local target path.

        Args:
            bucket_name (str): The S3 bucket name.
            key (str): The S3 object key.
            target_path (str): The local path for the downloaded file.
        Returns:
            bool - Whether the download was successful or not.
        """
        try:
            self.client.download_file(Bucket=bucket_name, Key=key, Filename=target_path)
            return True
        except botocore.exceptions.ClientError as e:
            log.error(f'S3 ClientError: {e}, {bucket_name}/{key}')
            return False

    def delete_object(self, bucket, key):
        """ Delete an object from an S3 bucket.
        Args:
            bucket_name (str): Name of the S3 bucket.
            key (str): The full s3 key path.
        Returns:
            Bool - Whether the delete was successful or not.
        """
        try:
            self.client.delete_object(Bucket=bucket, Key=key)
            return True
        except botocore.exceptions.ClientError as e:
            log.error(f'S3 ClientError: {e}, {bucket}/{key}')
            return False

    def empty_bucket(self, bucket_name):
        """
        Delete all objects from an Amazon S3 bucket

        :param bucket_name: string of the bucket you want to empty
        """

        object_names = self.get_all_s3_keys(bucket_name)

        # Convert list of object names to appropriate data format
        objlist = [{'Key': obj} for obj in object_names]

        try:
            self.client.delete_objects(Bucket=bucket_name, Delete={'Objects': objlist})
        except botocore.exceptions.ClientError as e:
            log.error(e)
            return False
        return True

    def keys_with_prefix(self, bucket_name, prefix):
        """Get all S3 keys in a bucket_name with a given prefix

        Args:
            bucket_name (str): The S3 bucket name.
            prefix (str): The S3 key prefix
        Returns:
            list - List of S3 keys.
        """
        r = self.client.list_objects(Bucket=bucket_name, Prefix=prefix)
        return [c.get('Key') for c in r.get('Contents', [])]

    def get_all_s3_keys(self, bucket_name):
        """
        Get a list of all keys in an S3 bucket.

        :param bucket_name: string of the bucket you want all keys in
        """
        keys = []

        kwargs = {'Bucket': bucket_name}
        while True:
            resp = self.client.list_objects_v2(**kwargs)
            for obj in resp['Contents']:
                keys.append(obj['Key'])

            try:
                kwargs['ContinuationToken'] = resp['NextContinuationToken']
            except KeyError:
                break

        return keys

    def list_objects(self, bucket_name, prefix='', suffix=''):
        """Lists objects in the specified S3 bucket.
        Args:
            bucket_name (str) : Name of the S3 bucket.
            prefix (str) : Only fetch keys that start with this prefix.
            suffix (str or an iterable (list, tuple)) : Only fetch keys that end with this suffix,
        Returns:
            generator : returns the keys in the bucket
        """
        paginator = self.client.get_paginator("list_objects_v2")

        kwargs = {'Bucket': bucket_name}

        # We can pass the prefix directly to the S3 API.  If the user has passed
        # a tuple or list of prefixes, we go through them one by one.
        if isinstance(prefix, str):
            kwargs["Prefix"] = prefix
        for page in paginator.paginate(**kwargs):
            try:
                contents = page["Contents"]
            except KeyError:
                return

            for obj in contents:
                key = obj["Key"]
                if key.endswith(suffix):
                    yield obj


# Util functions to download files in parallel are below.
# make a s3_client per process
def _init_process(max_workers):
    global s3_client
    s3_client = S3(max_pool_connections=max_workers)


def _download_from_s3(s3_bucket_key_with_save_path):
    save_path, (s3_bucket, s3_key) = s3_bucket_key_with_save_path
    return Path(save_path).exists() or s3_client.download_file(s3_bucket, s3_key, str(save_path))


def parallel_download(save_path_with_bucket_key, max_workers=cpu_count() * 2):
    """
    Download files from S3 in parallel
    Args:
        bucket (str) : S3 bucket name
        save_path_with_bucket_key (dict) : Dictionary containing save_path & bucket, s3_key.
                                     eg. {"/mnt/ebs_vol/image_1.png" : ("bucket", "/dev/image1.png)}
        max_workers (int) : Max number of processes to use for downloading.
    """
    with multiprocessing.Pool(max_workers, initializer=_init_process, initargs=(max_workers,)) as p:
        with tqdm(total=len(save_path_with_bucket_key)) as pbar:
            # imap_unordered is very important here to get the best performance
            for _ in p.imap_unordered(_download_from_s3, save_path_with_bucket_key.items()):
                pbar.update()
    return
