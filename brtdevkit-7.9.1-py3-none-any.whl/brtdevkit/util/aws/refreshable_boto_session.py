import logging
from datetime import datetime

from boto3 import Session
from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

from brtdevkit import config
from brtdevkit.core.api.api_requestor import APIRequestor
from brtdevkit.util.aws import AWS_REGION_DEFAULT


class AutoRefreshBotoSession:
    request = APIRequestor().request

    def __init__(self, duration_seconds: int = 900, region: str = AWS_REGION_DEFAULT):
        self.duration_seconds = duration_seconds
        self.region = region

    def _create_refreshable_session(self):
        # get refreshable credentials
        refreshable_credentials = RefreshableCredentials.create_from_metadata(
            metadata=self._fetch_aws_credentials(),
            refresh_using=self._fetch_aws_credentials,
            time_fetcher=datetime.utcnow,
            method="sts-assume-role",
        )

        session = get_session()
        session._credentials = refreshable_credentials
        session.set_config_variable("region", self.region)
        autorefresh_session = Session(botocore_session=session)
        return autorefresh_session

    def _load_aws_credential(self):
        # Load newly fetched credentials into config
        credentials = {
            'AWS_ACCESS_KEY': self.meta_data['access_key'],
            'AWS_SECRET_ACCESS_KEY': self.meta_data['secret_key'],
        }
        for k, v in credentials.items():
            setattr(config.Credentials, k, v)

    def _fetch_aws_credentials(self):
        # Call '/credentials/aws_access_token' with requestor
        resp = AutoRefreshBotoSession.request('post', '/credentials/aws_access_token',
                                              params={'duration_seconds': self.duration_seconds})
        data = resp.data
        self.meta_data = {
            'access_key': data['Credentials']['AccessKeyId'],
            'secret_key': data['Credentials']['SecretAccessKey'],
            'token': data['Credentials']['SessionToken'],
            'expiry_time': data['Credentials']['Expiration']
        }
        self._load_aws_credential()
        return self.meta_data

    def get_session(self):
        boto_session = None
        try:
            boto_session = self._create_refreshable_session()
        except Exception as e:
            logging.warning('Failed to refresh AWS Credential')
            logging.warning(f'Some functionalities (S3, Athena, etc) not useable {e}')
            boto_session = Session(botocore_session=get_session())
        return boto_session
