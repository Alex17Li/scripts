import json
import logging
import os
import re
import warnings
from json import JSONDecodeError
from pathlib import Path

import requests

logger = logging.getLogger('brtdevkit.config')

# GLOBAL environment name.
ENV = None
# GLOBAL environment config object.
Config = None

# Environments
ENV_TEST = 'test'
ENV_LOCAL = 'local'
ENV_DEV = 'dev'
ENV_MESA_DEV = 'mesa-dev'
ENV_QA = 'qa'
ENV_MESA_QA = 'mesa-qa'
ENV_STAGING = 'staging'
ENV_MESA_STAGING = 'mesa-staging'
ENV_PROD = 'prod'
ENV_MESA_PROD = 'mesa-prod'
ENVS = (
    ENV_TEST, ENV_LOCAL,
    ENV_DEV, ENV_QA, ENV_STAGING, ENV_PROD,
    ENV_MESA_DEV, ENV_MESA_QA, ENV_MESA_STAGING, ENV_MESA_PROD,
)
ENV_DEFAULT = ENV_MESA_PROD

ENV = os.environ.get('BRT_ENV') or ENV_DEFAULT
if ENV not in ENVS:
    raise ValueError(f'bad env name {ENV}. expecting one of {ENVS}')

API_BASE_PROD_OLD_ACCOUNT = 'https://tartarus-api.brtws.com'
API_BASE_TEMPLATE_OLD_ACCOUNT = 'https://tartarus-{env}-api.brtws.com'
API_BASE_TEMPLATE_NEW_ACCOUNT = 'https://api.tartarus.{env}.mesa.brtws.com'


def get_credentials_filename(environment: str):
    """
    Get the credentials filename for the given environment.

    Args:
        environment (str): The environment name.
    Returns:
        str: The credentials filename.
    """
    return f'credentials.{environment}.json'


CREDENTIALS_FILENAME = get_credentials_filename(ENV)


def get_env_base(env):
    """
    Get the base environment name for the given environment.

    Example:
        mesa-dev -> dev

    Args:
        env (str): The environment name.
    Returns:
        str: The base environment.
    """
    return re.sub('^mesa-', '', env)


BASE_ENV = get_env_base(ENV)


def get_api_base(env):
    """
    Get the API base URL for the given environment.
    BRT_API_BASE env. used if provided

    Args:
        env (str): The environment name.
    Returns:
        str: The API base URL.
    """
    # We allow API HOST to be overwritten by BRT_API_BASE variable
    if os.getenv('BRT_API_BASE'):
        return os.getenv('BRT_API_BASE')

    if env == ENV_PROD:
        api_base = API_BASE_PROD_OLD_ACCOUNT
    elif env in (ENV_DEV, ENV_QA, ENV_STAGING):
        api_base = API_BASE_TEMPLATE_OLD_ACCOUNT.format(env=env)
    elif env in (ENV_MESA_DEV, ENV_MESA_QA, ENV_MESA_STAGING, ENV_MESA_PROD):
        base_env = re.sub('^mesa-', '', env)
        api_base = API_BASE_TEMPLATE_NEW_ACCOUNT.format(env=base_env)
    else:
        api_base = 'http://0.0.0.0:8080'
    return api_base


API_BASE = get_api_base(ENV)


DEFAULT_ASSET_DIR = '~/.brt/assets'
ASSET_DIR = os.environ.get('ASSET_DIR') or DEFAULT_ASSET_DIR

# GLOBAL credentials object.
Credentials = None


def load_json_config(filepath):
    """Loads key/values from a JSON file.

    Args:
        filepath (str): The path to the config file.
    Returns:
        dict - The config JSON data.
    Raises:
        Exception if the config file is missing or could not be read.
    """
    with open(filepath, 'r') as config_file:
        return json.load(config_file)


def load_env_config():
    """Load credentials values from OS environment variables.

    Returns:
        dict: A dictionary of credentials values.
    """
    keys = (
        'AWS_ACCESS_KEY_ID',
        'AWS_SECRET_ACCESS_KEY',
        'BRT_API_KEY',
        'BRT_REFRESH_TOKEN',
    )
    credentials = {}
    for key in keys:
        if os.environ.get(key):
            cred_key = re.sub(r'^BRT_', '', key)  # remove BRT_ prefix
            credentials[cred_key] = os.environ[key]
    return credentials


def get_mesa_refresh_token(
        databricks_api_token: str,
        databricks_host: str,
        mesa_api_base: str = API_BASE):
    """
    Download a refresh token from the Mesa API using a Databricks API token.

    Args:
        databricks_api_token (str): The Databricks API token.
        databricks_host (str): The Databricks host.
        mesa_api_base (str): The Mesa API base url.
    Returns:
        str: The refresh token.
    """
    response = requests.get(
        url=f'{mesa_api_base}/oauth/code',
        headers={
            'Authorization': f'Bearer {databricks_api_token}',
        },
        params={
            'databricks_api_endpoint': databricks_host,
        },
    )
    try:
        data = response.json()
        error_message = data.get('message')
    except Exception:
        error_message = response.text

    if response.status_code != 200:
        # Import here to avoid circular import
        from brtdevkit.core.api.error import APIError
        raise APIError(
            error_message,
            http_body=response.text,
            http_status=response.status_code,
        )

    return data['refresh_token']


def is_running_in_databricks():
    """
    Check if the code is running in Databricks.

    Returns:
        bool: True if running in Databricks, False otherwise.
    """
    return os.environ.get('DATABRICKS_RUNTIME_VERSION') is not None


def get_databricks_context():
    """
    Get the Databricks notebook context.

    Args:
        None
    Returns:
        dict: The Databricks notebook context.
    """
    if not is_running_in_databricks():
        raise EnvironmentError('brtdevkit is not running in Databricks')

    # Using an internal import since this is only usable in Databricks and a
    # Spark environment.
    # Modules imported into a Databricks notebook do not have a direct access
    # to the dbutils module, unline python code directly run from a notebook.
    from pyspark.dbutils import DBUtils
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)

    ctx = json.loads(
        dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
    )
    return ctx


def get_databricks_api_token_and_host():
    """
    Get the Databricks API token and host from the Databricks notebook context.

    Args:
        None
    Returns:
        tuple: The Databricks API token and host (token, host).
    """
    ctx = get_databricks_context()
    api_token = ctx['extraContext']['api_token']
    api_host = ctx['extraContext']['api_url']
    return api_token, api_host


def generate_all_credentials_files_in_databricks(
        databricks_api_token: str,
        databricks_api_host: str):
    """
    Generate all credentials files in Databricks.

    Args:
        None
    Returns:
        list: environments for which credentials that have been successfully
              downloaded to the Databricks cluster.
    """
    # Import here to avoid circular import
    from brtdevkit.core.api.error import APIError
    environment_successfully_downloaded = []
    for env in (ENV_MESA_DEV, ENV_MESA_QA, ENV_MESA_STAGING, ENV_MESA_PROD):
        mesa_api_endpoint = get_api_base(env)
        try:
            mesa_refresh_token = get_mesa_refresh_token(
                databricks_api_token,
                databricks_api_host,
                mesa_api_endpoint,
            )
        except APIError:
            logger.debug(
                f'[{env}]: Credentials not available for Databricks setup'
            )
            continue
        generate_mesa_credentials_file_from_refresh_token(
            mesa_refresh_token,
            env,
        )
        logger.info(f'[{env}]: Credentials loaded and ready to use')
        environment_successfully_downloaded.append(env)
    return environment_successfully_downloaded


def generate_mesa_credentials_file_from_refresh_token(
        mesa_refresh_token: str,
        environment: str):
    """
    Generate a credentials file from a Mesa refresh token.

    Args:
        mesa_refresh_token (str): The Mesa refresh token.
        environment (str): The environment name.

    Returns:
        dict: The credentials dictionary.
    """
    credentials = {
        'REFRESH_TOKEN': mesa_refresh_token,
    }
    credentials_filename = get_credentials_filename(environment)
    credentials_filepath = get_credentials_filepath(credentials_filename)
    with open(credentials_filepath, 'w') as f:
        json.dump(credentials, f)
    return credentials


def get_credentials_filepath(credentials_filename, create_dir=True):
    """
    Get the fully qualified path to the credentials file.

    Args:
        credentials_filename (str): The name of the credentials file.

    Returns:
        str: The fully qualified path to the credentials file.
    """
    path = Path(Path.home(), '.brt', credentials_filename)
    if create_dir:
        path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


class CredentialsLoader:
    """A singleton object for storing application credentials.

    Any credential defined in the credentials.json file will be converted as named
    to a `config.Credentials` instance attribute.

    Example of a ~/.brt/credentials.<env>.json file::

        {
            'aws_access_token': 'fake-aws-access-token',
            ...
        }

    where <env> is the one of :const:`ENVS`.
    """

    class __CredentialsLoader(object):
        def __init__(self, credentials_filename):
            credentials = {}

            # Attempt to load credentials from a local credentials file
            filepath = get_credentials_filepath(credentials_filename)
            other_filepath = filepath
            # try the base environment path if the file doesn't exist
            if not os.path.exists(filepath):
                filepath = get_credentials_filepath(get_credentials_filename(get_env_base(ENV)))
            file_error = None
            try:
                credentials = load_json_config(filepath)
            except (JSONDecodeError, FileNotFoundError) as e:
                file_error = e

            # Load any relevant environment variables that might be present
            credentials = {**credentials, **load_env_config()}

            # Pull over json keys/values to instance attributes.
            for k, v in credentials.items():
                setattr(self, k, v)

            # warning/error-handling for missing API credentials
            if not credentials.get('REFRESH_TOKEN') and not credentials.get('API_KEY'):
                if file_error:
                    # Raising file_error here, for backwards compatibility with how brtdevkit
                    # behaved before "credentials via environment variables" was supported
                    msg = f'Unable to read Aletheia user credential JSON file {filepath}'
                    if other_filepath != filepath:
                        msg += f' or {other_filepath}'
                    logger.error(msg)
                    raise file_error

                warnings.warn(
                    'No API refresh key or API key provided. '
                    f'HINT: Put your API refresh token or key in {filepath}, '
                    'or set as an environment variable (BRT_API_KEY or BRT_REFRESH_TOKEN).'
                    'Contact BRTDevkit dev team for questions.'
                )

    instance = None
    filename = None

    def __init__(self, credentials_filename):
        """Construct a credentials singleton object.

        Args:
            credentials_path (str): The credentials data filepath.
        """
        if not CredentialsLoader.instance or CredentialsLoader.filename != credentials_filename:
            # Construct the credentials singleton object.
            CredentialsLoader.instance = CredentialsLoader.__CredentialsLoader(credentials_filename)
            CredentialsLoader.filename = credentials_filename

    def __getattr__(self, key):
        return getattr(self.instance, key)


def load_credentials(environment: str = ENV) -> CredentialsLoader:
    """Loads credentials from a file into the config credentials global
    singleton object.

    Raises:
        Exception if the credentials file is missing or could not be read.
    """
    global Credentials
    credentials_filename = get_credentials_filename(environment)
    Credentials = CredentialsLoader(credentials_filename)
