"""MachineLog API controller

Authors:
    Alex Jolicoeur <alex.jolicoeur@bluerivertech.com>

Copyright 2020, Blue River Technology
"""
import pathlib
import sys
from concurrent import futures
from urllib.parse import urlparse

import pandas as pd
from tqdm.auto import tqdm

from brtdevkit import MAX_WORKERS
from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
)
from brtdevkit.util.aws.s3 import S3
from brtdevkit.util.logger import Logger

log = Logger('MachineLog')


class MachineLog(ListableAPIResource, CreateableAPIResource, UpdateableAPIResource):
    OBJECT_NAME = "machine_log"
    ENDPOINT = "/machine_logs"

    @staticmethod
    def download_from_df(
            target_dir: str,
            df: pd.DataFrame,
            multiprocess: bool = False) -> str:
        """Downloads log files from a Dataframe

        Args:
            target_dir (str): directory where flat buffer files would be downloaded
            df (pd.DataFrame): Pandas Dataframe generated from get_documents_df()
            multiprocess (bool): if enabled downloads multiple files parallelly
        Returns:
            str directory path where files are downloaded
        Raises:
            ValueError if invalid dataframe is passed.
        """
        try:
            df.collection_name == 'machine_log_part'
        except AttributeError:
            raise ValueError(
                "Invalid dataframe: Must be generated from collection 'machine_log_part'")

        s3_client = S3()
        target_dir = pathlib.Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        progress_bar = tqdm(
            unit_scale=True,
            leave=True,
            dynamic_ncols=True,
            file=sys.stdout,
            total=len(df))  # Approx files to be downloaded

        def _download_fb(s3_client, s3_url):
            url = urlparse(s3_url)
            bucket_name, s3_key = url.netloc, url.path.lstrip('/')
            filepath = pathlib.Path(target_dir, pathlib.Path(s3_key).name)
            key_downloaded = s3_client.download_file(bucket_name, s3_key, str(filepath))
            progress_bar.update(1)
            return key_downloaded

        if multiprocess:
            callbacks = []
            with futures.ThreadPoolExecutor(MAX_WORKERS) as executor:
                for row in df.itertuples():
                    callbacks.append(
                        executor.submit(_download_fb, s3_client, row.log_s3_path))
            futures.wait(callbacks)
        else:
            for row in df.itertuples():
                downloaded = _download_fb(s3_client, row.log_s3_path)
                if not downloaded:
                    log.warn(f'{row.log_s3_path} failed to download')

        progress_bar.close()
        return str(target_dir)
