""" API Bindings for label policy API.
    API Resource : /label_policies/
    Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
    for request parameters

Author: Eric Kim <eric.kim@bluerivert.com>
Copyright 2020, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    DeletableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
)


class LabelPolicy(
        ListableAPIResource, CreateableAPIResource, UpdateableAPIResource, DeletableAPIResource):
    OBJECT_NAME = 'label_policy'
    ENDPOINT = '/label_policies'
