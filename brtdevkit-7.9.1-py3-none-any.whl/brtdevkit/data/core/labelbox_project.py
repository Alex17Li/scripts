""" API Bindings for labelbox project API.
    API Resource : /labelbox/projects
    Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
    for request parameters

Author: Taylor Ritenour <taylor.ritenour@bluerivert.com>
Copyright 2019, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
)


class LabelboxProject(ListableAPIResource, CreateableAPIResource, UpdateableAPIResource):
    OBJECT_NAME = 'labelbox_project'
    ENDPOINT = '/labelbox/projects'
