""" API Bindings for annotation job API.
    API Resource : /annotation_job/
    Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
    for request parameters

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2019, Blue River Technology
"""
from enum import Enum

from brtdevkit.core.api.resources.abstract.createable_api_resource import (
    CreateableAPIResource,
)
from brtdevkit.core.api.resources.abstract.listable_api_resource import (
    ListableAPIResource,
)


class AnnotationJob(ListableAPIResource):
    OBJECT_NAME = 'annotation_job'
    ENDPOINT = '/annotation_jobs'

    class Vendor(Enum):
        FIGURE_8 = 'f8'
        MTURK = 'mturk'
        LABELBOX = 'labelbox'

    class F8AnnotationJob(CreateableAPIResource):
        OBJECT_NAME = 'f8_annotation_job'
        ENDPOINT = '/annotation_jobs/f8'

    class MTurkAnnotationJob(CreateableAPIResource):
        OBJECT_NAME = 'mturk_annotation_job'
        ENDPOINT = '/annotation_jobs/mturk'

    class LabelboxAnnotationJob(CreateableAPIResource):
        OBJECT_NAME = 'labelbox_annotation_job'
        ENDPOINT = '/annotation_jobs/labelbox'

    @classmethod
    def create(cls, vendor: Vendor, **params):
        """
        Args:
            vendor (Vendor) : The vendor to submit the job to
            params (dict) : any extra parameters
        Returns:
            APIObject
        """
        if vendor == cls.Vendor.FIGURE_8 or vendor == cls.Vendor.FIGURE_8.value:
            return cls(cls.F8AnnotationJob.create(**params))
        elif vendor == cls.Vendor.MTURK or vendor == cls.Vendor.MTURK.value:
            return cls(cls.MTurkAnnotationJob.create(**params))
        elif vendor == cls.Vendor.LABELBOX or vendor == cls.Vendor.LABELBOX.value:
            return cls(cls.LabelboxAnnotationJob.create(**params))
        else:
            raise ValueError(
                f"""Unsupported vendor {vendor}. Supported values are
                    {[f"AnnotationJob.{e}" for e in cls.Vendor]}""")
