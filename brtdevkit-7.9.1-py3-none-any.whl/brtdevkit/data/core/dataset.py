""" API Bindings for Dataset API.
    API Resource : /datasets
    Please check API docs for request parameters: https://aletheia.brtws.com/docs

Authors: Asav Patel <asav.patel@bluerivert.com>,
         Olgert Denas <olgert.denas@bluerivert.com>
         David Evans <david.evans@bluerivert.com>

Copyright 2019, Blue River Technology
"""
import json
import re
import sys
import tempfile
import uuid
from collections import namedtuple
from functools import reduce
from pathlib import Path

import pandas as pd

import brtdevkit
from brtdevkit import config
from brtdevkit.core import error
from brtdevkit.core.api.resources.abstract import (
    APIResource,
    CreateableAPIResource,
    NamedListableAPIResource,
    nested_resource_class_methods,
)
from brtdevkit.util import logger
from brtdevkit.util.aws import s3
from brtdevkit.util.aws.s3 import parallel_download

ID = "id"
_ID = "_id"
ID_COLUMNS = [ID, _ID]

log = logger.Logger('Dataset')

# kawrgs for progress bar
PBAR_KWARGS = {
    'unit_scale': True,
    'leave': True,
    'dynamic_ncols': True,
    'file': sys.stderr,
}


class StandardPaths(namedtuple('sd', ['assets', 'df_csv'])):
    """ Namedtuple which returns the folder name and annotations.CSV name
        main reason for this to exist is to reduce dependencies on internal
        naming convetions. user can access paths using this named tuple,
        And as developers we can keep this named tuple updated.
    """

    @classmethod
    def make_standard(cls):
        return cls._make(('images', 'annotations.csv'))


class DatasetCSV(namedtuple(
    'scsv', ['dataset_metadata', 'artifacts_save_paths', 'annotations_save_paths']
)):

    @classmethod
    def get_columns(cls, df):
        return cls._make((
            list(set(df.columns) - set(df.filter(regex='(^artifact_|^annotation_)').columns)),
            list(df.filter(regex="^artifact_(.*?)_save_path(.*?)$").columns),
            list(df.filter(regex="^annotation_(.*?)_save_path(.*?)$").columns)))


class DatasetException(Exception):
    pass


class AletheiaWebDataset(APIResource):
    OBJECT_NAME = "aletheia_webdataset"


@nested_resource_class_methods(
    AletheiaWebDataset, path='webdatasets', operations=["create", "retrieve", "update"]
)
class Dataset(NamedListableAPIResource, CreateableAPIResource):
    OBJECT_NAME = "dataset"
    ENDPOINT = "/datasets"
    DATASET_STATE_READY = 'ready'

    KIND_ANNOTATION = 'annotation'
    KIND_IMAGE = 'image'
    KINDS = (KIND_ANNOTATION, KIND_IMAGE)
    ARTIFACT_COLUMN_PREFIX = 'artifact_'
    ANNOTATION_COLUMN_PREFIX = 'annotation_'
    ANNOTATION_COLUMN_KIND_INFIXES = (
        'pixelwise',
        'boundingbox',
    )

    def __init__(self, values, **kwargs):
        self._df = None
        super().__init__(values, **kwargs)

    def retrieve_data(self, chunksize=1000):
        """
        Downloads the dataset's metadata jsonl file and returns the data in chunks

        Args:
            chunksize (int) : Number of lines to be read from metadata file.
        Returns:
            pandas.Series: the list of dataset resources (image documents)
        """
        s3_client = s3.S3()
        # download metadata json and load it into dataframe
        # TODO (erin): test performance when using an in memory buffer
        with tempfile.NamedTemporaryFile() as tmp_metadata:
            s3_client.download_file(
                self.metadata_s3_bucket,
                self.metadata_s3_key,
                tmp_metadata.name
            )
            for chunk in pd.read_json(
                    tmp_metadata.name, typ='series', lines=True, chunksize=chunksize):
                yield chunk

    def explain(self):
        """ Dynamic method for Dataset.definition

        Returns: str - The Dataset definition, or the Id
                if no definition exists.
        """
        definition = getattr(self, 'definition', None)
        _id = getattr(self, ID, None)
        if not (definition or _id):
            raise ValueError("Missing both definition and Id")
        return definition or _id

    def save(self, name, **kwargs):
        """ Save an in-memory dataset back to the DB. Automatically infers parameters
            'kind', 'image_ids' or 'annotation_ids' (depending on 'kind'), 'state',
            and 'definition'.

        Args:
            name (str): The Dataset name (required API parameter).
            kwargs (dict): Additional keyword arguments such as name and description to apply
                to the dataset.
        Returns:
            dict: API response
        """
        if hasattr(self, ID):
            raise DatasetException(
                f'Dataset has id {getattr(self, ID, None)}, and therefore already exists')

        df = self.to_dataframe()
        if self.kind == self.KIND_IMAGE:
            resource_ids = {'image_ids': df[ID].drop_duplicates().tolist()}
        elif self.kind == self.KIND_ANNOTATION:
            annotation_df = df[[c for c in df if re.match(
                f'^{self.ANNOTATION_COLUMN_PREFIX}'
                f'({"|".join(self.ANNOTATION_COLUMN_KIND_INFIXES)}).*__id$', c)
                is not None
            ]]
            resource_ids = {'annotation_ids': pd.concat([
                annotation_df[c] for c in annotation_df], ignore_index=True
            ).dropna().drop_duplicates().tolist()}
        else:
            raise DatasetException(
                f'kind must be in {(self.KIND_IMAGE, self.KIND_ANNOTATION)}. Got {self.kind}')

        if len(list(resource_ids.values())[0]) == 0:
            raise DatasetException('Dataset is empty')

        return Dataset.create(
            kind=self.kind,
            state=self.DATASET_STATE_READY,
            definition=self.definition,
            name=name,
            **resource_ids,
            **kwargs)

    @classmethod
    def _check_dataset_operands(cls, da, db):
        if da.kind != db.kind:
            raise DatasetException('Datasets must be of same kind')

    @classmethod
    def _merge_id_columns(cls, dataframe: pd.DataFrame) -> pd.DataFrame:
        """
        Merge multiple (sparse) id columns that might be present in a dataframe representation,
        and ensure that the output dataframe has exatly one id column (:const:`ID`)
        containing the merge result.

        Args:
            dataframe (:class:`pandas.DataFrame`): An input dataframe that matches
                the input `dataframe` of :meth:`.from_dataframe`.

        Returns:
            :class:`pandas.DataFrame`: the merged-id-column version of the input.
        """
        id_cols_present = list(set(dataframe.columns).intersection(ID_COLUMNS))
        output_id_column = ID
        if len(id_cols_present) >= 1:
            merged_id_col = reduce(
                lambda x, y: x.combine_first(y),
                [dataframe.loc[:, id_col] for id_col in id_cols_present]
            )
            dataframe = dataframe.drop(id_cols_present, axis=1)
            dataframe.loc[:, output_id_column] = merged_id_col
        else:
            raise ValueError("{dataframe.columns} does not have a column in {ID_COLUMNS}")
        return dataframe

    @classmethod
    def from_dataframe(cls, dataframe, kind, **kwargs):
        """
        Instantiates a Dataset from a dataframe.

        Args:
            dataframe (:class:`pandas.DataFrame`): A dataframe that has the following
                id column(s) (id and/or _id)
                s3_bucket_<kind>
                s3_key_<kind>
            kind (`str`): Either :const:`cls.KIND_IMAGE` or :const:`cls.KIND_ANNOTATION`.
                Note, that IMAGE and ARTIFACT are both used to reference image metadata
                resulting from the artifact collection.
        Returns:
            :class:`.Dataset`: A new dataset.
        """
        df_id_norm = cls._merge_id_columns(dataframe)
        df_id_norm = df_id_norm.sort_index(axis=1)
        return cls._from_dataframe(df_id_norm, kind, **kwargs)

    @classmethod
    def _from_dataframe(cls, dataframe, kind, **kwargs):
        values = {
            'kind': kind,
            'state': Dataset.DATASET_STATE_READY,
        }
        definition_key = 'definition'
        if kwargs.get(definition_key):
            values[definition_key] = kwargs[definition_key]
        else:
            values[definition_key] = cls._get_definition_from_ids(dataframe.loc[:, ID].apply(str))

        dataset = Dataset(values=values)
        # Set the Dataset dataframe reference.
        dataset._df = dataframe
        return dataset

    def _from_series_to_dataframe(self, series_data, artifact_query=None):
        """
        Converts a pandas series into a dataset's dataframe

        Args:
            series_data (pandas.Series) : Pandas series
            artifact_query (str): a SQL like query string to downselect the artifacts.
                can be used to ignore certain artifacts, so that they are not downloaded
                ex: "kind != 'nrg'". see documentation for pandas.DataFrame.query() for more info
        Returns:
            pandas.DataFrame: the dataset represented as a pandas DataFrame
        """
        # json_normalize takes nested structures and turns them into columns
        # it also automatically explodes any lists into their own rows
        df = pd.json_normalize(series_data, max_level=0)
        df = df.drop(['artifacts', 'annotations'], axis=1)

        artifacts_df = pd.json_normalize(
            series_data, record_path='artifacts', meta=ID, meta_prefix='img.')

        """
        we use groupby and cumcount to calculate the eventual prefix added to the column
        the table at this point will look something like this:

            img.id  | _id   | kind          | idx   | ...
            5dc34   | 5dc43 | bounding_box  | 0     |  .
            5dc34   | 5dc44 | bounding_box  | 1     |  .
            5dc34   | 5dc45 | pixelwise     | 0     |  .
            5dc35   | 5dc46 | bounding_box  | 0     |  .

        note the incremental idx value based on `kind` and `img.id`.
        This operation more or less replaces `get_asset_idxs`
        """
        artifacts_df['idx'] = artifacts_df.groupby(['kind', 'img.id']).cumcount().astype(str)

        if artifact_query:
            artifacts_df = artifacts_df.query(artifact_query)

        """
        TODO (erin): maybe refactor these operations into a separate method
        the following pandas operations format the dataframe as follows
        1. first we use `set_index` to create a MultiIndex by `img.id`, `kind`, and `idx`

                                            | _id   | s3_key | bounding_boxes
            --------|---------------|-------|-------|--------|---------------
            img.id  | kind          | idx   |       |        |
            --------|---------------|-------|-------|--------|---------------
            5dc34   | bounding_box  | 0     | 5dc43 |  NaN   | [...]
            5dc34   | bounding_box  | 1     | 5dc44 |  NaN   | [...]
            5dc34   | pixelwise     | 0     | 5dc45 |  /...  | NaN
            5dc35   | bounding_box  | 0     | 5dc46 |  NaN   | [...]

            note that we drop the columns `img.id` and `idx`; we're using them to index

        2. then we use `unstack` to pivot the MultiIndex into columns.

                    | _id          |              |              | s3_key       | ...
            kind    | 0            |              | 1            | 0            | ...
            idx     | bounding_box | pixelwise    | bounding_box | bounding_box | ...
            --------|--------------|--------------|--------------|--------------|-----
            img.id  |              |              |              |              |
            --------|--------------|--------------|--------------|--------------|-----
            5dc34   | 5dc43        |  5dc44       | 5dc45        | NaN          | ...
            5dc35   | 5dc46        |  NaN         | NaN          | NaN          | ...

        3. after that, we use `swap_level` and `sort_index` to format and order the columns

                    | bounding_box |              |              |              | ...
            kind    | 0            |              |              |              | ...
            idx     | _id          |              | s3_key       |              | ...
            --------|--------------|--------------|--------------|--------------|-----
            img.id  |              |              |              |              |
            --------|--------------|--------------|--------------|--------------|-----
            5dc34   | 5dc43        |  5dc44       | NaN          | NaN          | ...
            5dc35   | 5dc46        |  NaN         | NaN          | NaN          | ...

        4. then, we merge the column names and add a prefix

                    | annotation_bounding_box_0__id | annotation_bounding_box_0_s3_key | ...
            --------|-------------------------------|----------------------------------|-----
            img.id  |                               |                                  |
            --------|-------------------------------|----------------------------------|-----
            5dc34   | 5dc43                         |  NaN                             | ...
            5dc35   | 5dc46                         |  NaN                             | ...

            as you can see, there will be columns that don't quite make sense, such as
            `annotation_bounding_box_0_s3_key`. as a final step, we'll drop any columns whose
            values are all NaN. this will get rid of any extraneous columns.
        """

        artifacts_df = artifacts_df.set_index(['img.id', 'kind', 'idx'], drop=False) \
            .drop(['img.id', 'idx'], axis=1) \
            .unstack(level=['idx', 'kind']) \
            .swaplevel(0, 2, axis=1) \
            .sort_index(axis=1, level=['kind', 'idx'])

        artifacts_df.columns = artifacts_df.columns.map('_'.join)
        artifacts_df = artifacts_df.add_prefix('artifact_')
        df = df.merge(artifacts_df, right_index=True, left_on=ID)

        # get all annotations and transpose them into dataframe columns
        if self.kind != Dataset.KIND_IMAGE:
            ann_df = pd.json_normalize(
                series_data,
                record_path='annotations',
                meta=ID,
                meta_prefix='img.',
                max_level=0)
            ann_df['idx'] = ann_df.groupby(['style', 'img.id']).cumcount().astype(str)
            ann_df = ann_df.set_index(['img.id', 'style', 'idx'], drop=False) \
                .drop(['img.id', 'idx'], axis=1) \
                .unstack(level=['idx', 'style']) \
                .swaplevel(0, 2, axis=1) \
                .sort_index(axis=1, level=['style', 'idx'])
            # drop columns that don't make sense (i.e bounding_box_0_s3_key)
            ann_df = ann_df.dropna(axis=1, how='all')
            ann_df.columns = ann_df.columns.map('_'.join)
            ann_df = ann_df.add_prefix('annotation_')
            df = df.merge(ann_df, right_index=True, left_on=ID)
        return df

    def __sub__(self, other):
        """ Dataset difference operator.

        Args:
            self (Dataset): Base dataset
            other (Dataset): Target dataset
        Returns:
            Dataset: The difference between the base and target.
        """
        self._check_dataset_operands(self, other)
        df_A = self.to_dataframe()
        df_B = other.to_dataframe()
        return self.__class__._from_dataframe(
            dataframe=df_A[~df_A.loc[:, ID].isin(df_B.loc[:, ID])],
            definition=f'({self.explain()} - {other.explain()})',
            kind=self.kind)

    def __and__(self, other):
        """ Dataset intersection operator.

        Args:
            self (Dataset): Base dataset
            other (Dataset): Target dataset
        Returns:
            Dataset: The intersection of the base and target.
        """
        self._check_dataset_operands(self, other)
        df_A = self.to_dataframe()
        df_B = other.to_dataframe()
        # Merge the two dataframes on Image ID, and drop the duplicated columns.
        uid = uuid.uuid1()
        df_A_and_B = df_A.merge(df_B, on=[ID], suffixes=('', f'_{uid}'))
        df_A_and_B.drop(df_A_and_B.filter(regex=f'_{uid}$').columns.tolist(), axis=1, inplace=True)
        return Dataset._from_dataframe(
            dataframe=df_A_and_B,
            definition=f'({self.explain()} & {other.explain()})',
            kind=self.kind)

    def __or__(self, other):
        """ Dataset union operator.

        Args:
            self (Dataset): Base dataset
            other (Dataset): Target dataset
        Returns:
            Dataset: The union of the base and target.
        """
        self._check_dataset_operands(self, other)
        df_A = self.to_dataframe()
        df_B = other.to_dataframe()
        return Dataset._from_dataframe(
            dataframe=pd.concat(
                [df_A, df_B], ignore_index=True, sort=False).drop_duplicates([ID]),
            definition=f'({self.explain()} | {other.explain()})',
            kind=self.kind)

    def add_rows(self, rows_df):
        """ Add rows from a dataframe to a Dataset. Returns a new dataset.

        Args:
            self (Dataset): Base dataset
            rows_df (pd.Dataframe): dataframe of rows to concatenate to Dataset.
        Returns:
            Dataset: A new dataset
        """
        df = self.to_dataframe()
        return Dataset._from_dataframe(
            dataframe=pd.concat([df, rows_df], ignore_index=True, sort=True),
            definition=f'({self.explain()} + {rows_df.shape})',
            kind=self.kind
        )

    # @ TODO (alex): Re-enable remove_rows when we can assume all dataframes
    # generated from our models have ID column (and not '_id', unless they're annotations or
    # artifacts).

    # def remove_rows(self, rows_df):
    #     """ Remove rows of a dataframe from a Dataset, if they exist. Returns a new dataset.

    #     Args:
    #         self (Dataset): Base dataset
    #         rows_df (pd.Dataframe): dataframe of rows to remove from the Dataset.
    #     Returns:
    #         Dataset: A new dataset
    #     """
    #     df = self.to_dataframe()
    #     return Dataset._from_dataframe(
    #         dataframe=df[~df.loc[:, ID].isin(rows_df.loc[:, ID])],
    #         definition=f'({self.explain()} - {rows_df.shape})',
    #         kind=self.kind)

    @classmethod
    def _get_definition_from_ids(cls, ids):
        """
        Args:
            ids (`list` of `str`): item IDs.

        Returns:
            A definition string from supplied ids.

        Reference:
            https://bit.ly/329oUDs
        """
        return "D(%s)" % ", ".join(["'%s'" % str(el) for el in ids])

    def to_dataframe(self, cache=True, artifact_query=None):
        """
        Converts the dataset to a dataframe

        Args:
            cache (bool): whether to cache and bind the dataframe to the Dataset object.
                if True, future calls will return the cached dataframe. defaults to True
            artifact_query (str): a SQL like query string to downselect the artifacts.
                can be used to ignore certain artifacts, so that they are not downloaded
                ex: "kind != 'nrg'". see documentation for pandas.DataFrame.query() for more info

        Returns:
            pandas.DataFrame: the dataset represented as a pandas DataFrame
        """
        # converts all annotations for the dataset into pandas dataframe
        if getattr(self, 'instance_url', None) is not None:
            # We can't refresh if we haven't saved the dataset yet.
            self.refresh()

        if self.state != self.DATASET_STATE_READY:
            raise error.InvalidRequestError(
                f"Dataset : {self.name} not ready to be converted to Dataframe yet"
                f"please try again after sometime | current state: {self.state}")

        if self._df is None:
            # download metadata json and load it into dataframe
            data = pd.concat([*self.retrieve_data()])
            df = self._from_series_to_dataframe(data, artifact_query)
            if cache:
                self._df = df
        self._df = self._df.sort_index(axis=1)
        return self._df

    def to_dataframe_chunks(self, chunksize=1000, artifact_query=None):
        """
        Converts the dataset to a dataframe in chunks

        Args:
            chunksize (int) :  number of rows to be converted as dataframe.
            artifact_query (str): a SQL like query string to downselect the artifacts.
                can be used to ignore certain artifacts, so that they are not downloaded
                ex: "kind != 'nrg'". see documentation for pandas.DataFrame.query() for more info

        Returns:
            pandas.DataFrame: the dataset represented as a pandas DataFrame.
                THE RETURNED DATAFRAME WILL NOT BE SORTED LIKE `to_dataframe` METHOD.
        """
        if getattr(self, 'instance_url', None) is not None:
            # We can't refresh if we haven't saved the dataset yet.
            self.refresh()

        if self.state != self.DATASET_STATE_READY:
            raise error.InvalidRequestError(
                f"Dataset : {self.name} not ready to be converted to Dataframe yet"
                f"please try again after sometime | current state: {self.state}")
        for series_data in self.retrieve_data(chunksize):
            yield self._from_series_to_dataframe(series_data, artifact_query)

    def download(
            self, path=config.ASSET_DIR, df=None, include_full_system_path=False, group_by=None,
            max_workers=brtdevkit.MAX_WORKERS):
        """
        Downloads dataset to the given path.
        Currently data is stored as below folder structure in the given path :

        If group_by is not provided::

            path/
            └───images : (contains images/media artifacts for the dataset)
            │   └───<image_id>
            │   │   │   <asset_type>_<image_id>.tiff
            │   │   │   <annotation_type>_<image_id>.bmp
            │   │   │   ...
            │   └───<image_id>
            │   │   │   <asset_type>_<image_id>.tiff
            │   │   │   <annotation_type>_<image_id>.bmp
            │       │   ...
            └───annotations.csv (dataset's metadata linked with downloaded images + label images)

        If group_by is provided::

            path/
            └───images : (contains images/media artifacts for the dataset)
            │   └───<group_1>
            │   │   │   <asset_type>_<image_id_1>.tiff
            │   │   │   <asset_type>_<image_id_2>.tiff
            │   │   │   <annotation_type>_<image_id_1>.bmp
            │   │   │   ...
            │   └───<group_2>
            │   │   │   <asset_type>_<image_id_3>.tiff
            │   │   │   <asset_type>_<image_id_4>.tiff
            │   │   │   <annotation_type>_<image_id_4>.bmp
            │       │   ...
            └───annotations.csv (dataset's metadata linked with downloaded images + label images)

        Args:
            path (str) : Optional. path to directory where dataset needs to be downloaded
            df (pandas.DataFrame) : optional filtered dataframe
            group_by (str) : column name from the dataframe by which images would be grouped by
                             and stored in same directory as column's value
            include_full_system_path (bool) : optional if you want full system path
                included for downloaded artifacts in annotations.csv
            max_workers (int) : optional, number of parallel processes to use to download files
        """
        dataset_description = self.explain()
        log.info(f'start downloading dataset: {dataset_description} into {path}')
        path = Path(path).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        if df is None:
            df = self.to_dataframe()

        if group_by:
            assert group_by in df.columns, \
                f" column : {group_by} does not exist in dataframe to group images."

        # get all columns which contains s3_bucket and s3_key to download
        assets_s3_columns = [
            (c, c.replace('s3_bucket', 's3_key'))
            for c in df.columns
            if 's3_bucket' in c and 'web_s3_bucket' not in c
        ]

        # add save_path columns to dataframe
        save_path_columns = [
            bucket_c.replace('s3_bucket', 'save_path') for bucket_c, _key_c in assets_s3_columns
        ]
        df[save_path_columns] = pd.DataFrame(columns=save_path_columns)

        paths = StandardPaths.make_standard()

        keys_with_save_path = pd.Series([], dtype="object")
        for s3_bucket_column, s3_key_column in assets_s3_columns:
            asset_kind = s3_bucket_column.replace("_s3_bucket", "")
            save_path_column = s3_bucket_column.replace('s3_bucket', 'save_path')
            df[save_path_column] = df.apply(
                lambda r: Path(path, paths.assets, str(r[group_by]) if group_by else r.loc[ID],
                               f'{asset_kind}_{r[ID]}{Path(r[s3_key_column]).suffix}')
                if not pd.isnull(r[s3_bucket_column]) else None, axis=1
            )
            # create all directories
            df[save_path_column].apply(
                lambda p: p.parent.mkdir(parents=True, exist_ok=True)
                if not pd.isnull(p) else None
            )
            keys_with_save_path = keys_with_save_path.append(
                pd.Series(zip(df[s3_bucket_column], df[s3_key_column]), index=df[save_path_column])
            )
            if not include_full_system_path:
                df[save_path_column] = df[save_path_column].apply(
                    lambda p: p.relative_to(path) if not pd.isnull(p) else None)

        # drop all rows which have empty save path due to None s3_keys
        keys_with_save_path = keys_with_save_path[keys_with_save_path.index.notnull()]
        # download all files in parallel
        parallel_download(keys_with_save_path, max_workers=max_workers)

        # need to apply json.dumps to dictionary columns. so when dumping this dataframe into CSV.
        # those columns gets encoded correctly and properly loaded back into dataframe from CSV.
        label_map_columns = [
            c for c in df.columns
            if c.startswith(self.ANNOTATION_COLUMN_PREFIX) and c.endswith('label_map')
        ]

        for label_map_c in label_map_columns:
            df[label_map_c] = df[label_map_c].apply(json.dumps)
        df.to_csv(Path(path, paths.df_csv), index=False)
        # reassign dataframe with updated dataframe
        self._df = df
        log.info(f'finished downloading dataset: {dataset_description}')
