""" API Bindings for label map API.
    API Resource : /label_map/
    Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
    for request parameters

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
        Asav Patel <asav.patel@bluerivert.com>

Copyright 2019, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    ListableAPIResource,
)


class LabelMap(ListableAPIResource, CreateableAPIResource):
    OBJECT_NAME = 'label_map'
    ENDPOINT = '/label_maps'
