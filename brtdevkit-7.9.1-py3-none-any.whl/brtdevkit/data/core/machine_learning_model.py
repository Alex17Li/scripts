"""
API bindings for the machine learning model API.
API Resource : /machine_learning_models/<ml_model_id>

Author: Asav Patel <asav.patel@bluerivert.com>

Copyright 2020, Blue River Technology
"""
from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    DeletableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
    nested_resource_class_methods,
)
from brtdevkit.data.core.machine_learning_model_status import MachineLearningModelStatus


@nested_resource_class_methods(
    MachineLearningModelStatus, path='status', operations=["create", "retrieve", "list"]
)
class MachineLearningModel(
        ListableAPIResource, CreateableAPIResource, DeletableAPIResource, UpdateableAPIResource):
    OBJECT_NAME = "machine_learning_model"
    ENDPOINT = "/machine_learning_models"

    @classmethod
    def get_model_statuses(cls, **params):
        """
        Retrieve list of model statuses for MachineLearningModels

        Args:
            identifier (str) : Model Status Identifier
            status (str) : Model Status
            model (str) : Model ID
            params (dict): Any extra parameters
        Returns:
            response (APIResponse)
        """
        return cls.list_machine_learning_model_status(id=None, **params)

    def get_status(self):
        """
        Returns all model statuses for MachineLearningModels object
        Returns:
            response (APIResponse)
        """
        return self.retrieve_machine_learning_model_status(id=self.id, nested_id=None)

    def update_model_status(self, identifier, status, release_objects=()):
        """
        Update Model with requested status and identifier

        Args:
            identifier (str) : Model Status Identifier, eg. corn, soybean etc
            status (str) : Model Status,
                           value from : [production, prior_production, release_candidate, prototype]
            release_objects (str) : Release Objects related to Model, needs to be a list of
                                    dictionaries.
         Returns:
             dict : Model Status Information
        """
        return self.create_machine_learning_model_status(
            id=self.id,
            **{'identifier': identifier, 'status': status, 'release_objects': release_objects})
