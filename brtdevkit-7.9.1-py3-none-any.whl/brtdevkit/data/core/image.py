"""
API bindings for the Image Resource.

Authors:
    JC Lanoe <jc.lanoe@bluerivert.com>
    Asav Patel <asav.patel@bluerivert.com>
    Taylor Ritenour <taylor.ritenour@bluerivertech.com>

Copyright 2020, Blue River Technology
"""
import hashlib
from datetime import datetime

import dateutil.parser
import PIL.Image
import tifffile

from brtdevkit.core import HTTPClient
from brtdevkit.core.api import error
from brtdevkit.core.api.resources.abstract import (
    APIResource,
    CreateableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
    nested_resource_class_methods,
)
from brtdevkit.core.api.swagger import include_docs
from brtdevkit.data.core.image_feature import ImageFeature
from brtdevkit.util.aws import s3

DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"


@nested_resource_class_methods(
    ImageFeature, path='features', operations=["create", "retrieve", "list"]
)
class Image(ListableAPIResource, CreateableAPIResource, UpdateableAPIResource):
    # API Reference:
    # https://bluerivertechnology.atlassian.net/wiki/spaces/MESA/pages/1003520454/How+To+Image+Import+APIs

    OBJECT_NAME = "image"
    ENDPOINT = "/images"
    ARTIFACT_ENDPOINT_BASE = "/images/{image_id}/artifacts"
    UPLOAD_IMAGE_ENDPOINT = "/images/upload_url"

    @classmethod
    @include_docs(ARTIFACT_ENDPOINT_BASE, "post")
    def add_artifact(cls, image_id, **params):
        """
        Args:
            image_id (str): Image model ID to add this artifact on to
            params (dict): All params for the new artifact
        Returns:
            APIObject (Artifact)
        """
        artifact_endpoint = cls.ARTIFACT_ENDPOINT_BASE.format(image_id=image_id)
        response = cls.request("post", artifact_endpoint, params)
        return response

    @classmethod
    @include_docs(UPLOAD_IMAGE_ENDPOINT, "post")
    def upload_artifact_image(cls, filepath, project_name=None):
        """ Request an upload URL from the server, then complete the S3 upload to that location.

        Args:
            filepath (str): The full image file path. A unique ID will be appended to this
                server side (see the response object).
            project_name (str): project/program team this artifact will be associated with
        Returns:
            dict - The Image upload API response object, containing the final S3 upload location.
        """
        # Get an artifact S3 upload URL from the server.
        payload = {
            "artifact_filenames": [filepath],
        }
        if project_name is not None:
            payload['project_name'] = project_name

        full_resp = cls.request("post", cls.UPLOAD_IMAGE_ENDPOINT, payload)
        resp_data = full_resp.data['artifact_upload_urls'][0]
        # Write the artifact to the S3 URL.
        with open(filepath, 'rb') as f:
            HTTPClient().request(
                'post', resp_data['request_url'], data=resp_data['request_form_data'],
                files={'file': f})
        return resp_data

    @staticmethod
    def compute_artifact_content_hash(filepath):
        """Get the content hash for the Artifact image file.
        Taken from tartarus/backend/app/util/image_importer.py

        Returns:
            str - The MD5 hash for the Image file.
        """
        MAX_CHUNK_LENGTH = 64 * 1024  # 64KiB
        md5 = hashlib.md5()
        with open(filepath, 'rb') as image_file:
            # Read in chunks of 64MB.
            for chunk in iter(lambda: image_file.read(MAX_CHUNK_LENGTH), b''):
                md5.update(chunk)
        return md5.hexdigest()

    @classmethod
    def _get_artifact_dimensions(cls, image_filepath):
        try:
            # We are using tifffile specifically because the AR233 reflectance images are
            # 32-bit float tif files. PIL can't read these
            if image_filepath.endswith('.tif'):
                tif_file = tifffile.imread(image_filepath)
                height, width, *_ = tif_file.shape
                return width, height
            else:
                image = PIL.Image.open(image_filepath)
                # image.size is in the order of width, height.
                return image.size
        except Exception as e:
            raise RuntimeError("Unable to read image dimensions") from e

    @classmethod
    @include_docs(ARTIFACT_ENDPOINT_BASE, "post")
    def create_and_upload_artifact(cls, image_id, artifact_metadata):
        """Helper function for creating and uploading artifacts on an image

        Args:
            image_id (str): The Aletheia image ID to add the artifacts to
            artifact_metadata (dict): a dictionary containing artifact metadata
                artifact_metadata must not be empty
                required keys for artifacts are:
                    filepath (str)
                    kind (str)
        Returns:
            APIObject - the uploaded artifact as returned by add_artifact()
        Raises:
            KeyError - if artifact is missing filepath
            APIError - the POST artifact request fails (error from API will be reported)
        """

        kind = artifact_metadata['kind']
        filepath = artifact_metadata.pop('filepath', None)
        if not filepath:
            raise KeyError(f'missing filepath for artifact {artifact_metadata}')
        project_name = artifact_metadata.get('project_name', None)

        upload_resp = cls.upload_artifact_image(filepath, project_name=project_name)
        width, height = cls._get_artifact_dimensions(filepath)
        artifact = {
            **artifact_metadata,
            'height': height,
            'width': width,
            's3_key': upload_resp['s3_key'],
            's3_bucket': upload_resp['s3_bucket'],
            'web_s3_key': upload_resp['s3_key'] if kind != 'raw' else None,
            'web_s3_bucket': upload_resp['s3_bucket'] if kind != 'raw' else None,
            'content_hash': cls.compute_artifact_content_hash(filepath)
        }
        return cls.add_artifact(image_id, **artifact)

    @classmethod
    def create_and_upload(cls, artifact_metadata, image_metadata):
        """Helper function for creating and uploading an image document

        Args:
            artifact_metadata (list): a list of dictionaries containing artifact metadata
                artifact_metadata must not be empty
                required keys for artifacts are:
                    filepath (str)
            image_metadata (dict): a dictionary representing the image metadata
                required keys are:
                    collected_on
                    latitude or gps_latitude (float)
                    longitude or gps_longitude (float)
        Returns:
            APIObject - the created image
        Raises:
            KeyError - if image is missing gps fields or if artifact is missing filepath
            APIError - the POST image request fails (error from API will be reported)
        """
        # raise KeyError if missing gps fields
        # shasta uses gps_latitude/gps_longitude
        latitude = image_metadata.get('latitude') or image_metadata.get('gps_latitude')
        longitude = image_metadata.get('longitude') or image_metadata.get('gps_longitude')
        if not latitude or not longitude:
            raise KeyError('image_metadata is missing latitude/longitude')

        # Ensure collected_on is in the correct format
        image_metadata['collected_on'] = datetime.strftime(
            dateutil.parser.isoparse(image_metadata['collected_on']), DATETIME_FORMAT)

        # TODO (erin): API returns an unhelpful 500 message when gps coordinates are invalid
        gnss = {
            "type": "Point",
            "coordinates": [
                # Mongo Points are ordered <longitude, latitude>
                # https://docs.mongodb.com/manual/geospatial-queries/#geojson-objects
                longitude,
                latitude
            ]
        }

        project_name = image_metadata.get('project_name', None)

        artifacts = []
        for artifact in artifact_metadata:
            kind = artifact['kind']
            filepath = artifact.pop('filepath', None)
            if not filepath:
                raise KeyError(f'missing filepath for artifact {artifact}')

            project_name = project_name or artifact.get('project_name', None)
            upload_resp = cls.upload_artifact_image(filepath, project_name=project_name)
            width, height = cls._get_artifact_dimensions(filepath)
            artifacts.append({
                **artifact,
                'height': height,
                'width': width,
                's3_key': upload_resp['s3_key'],
                's3_bucket': upload_resp['s3_bucket'],
                'web_s3_key': upload_resp['s3_key'] if kind != 'raw' else None,
                'web_s3_bucket': upload_resp['s3_bucket'] if kind != 'raw' else None,
                'content_hash': cls.compute_artifact_content_hash(filepath)
            })

        try:
            image = cls.create(artifacts=artifacts, gnss=gnss, **image_metadata)
        except error.APIError:
            # cleanup s3 files in case of failure
            s3_client = s3.S3()
            for artifact in artifacts:
                s3_client.delete_object(artifact['s3_bucket'], artifact['s3_key'])
            # the APIError will report:
            #   1. whether the content_hash already exists
            #   2. if the metadata is missing any required fields
            #       required fields
            raise

        return image

    @classmethod
    @include_docs('/images/uuid/{image_uuid}', 'get')
    def get_by_uuid(cls, image_uuid):
        """
        Fetch an image by its UUID.

        Args:
            image_uuid (str): Image uuid to fetch.
        Returns:
            APIObject (Image)
        """
        response = cls.request('get', f'{cls.ENDPOINT}/uuid/{image_uuid}')
        return response.data

    @classmethod
    @include_docs('/images/uuid', 'post')
    def list_by_uuids(cls, image_uuids):
        """
        Fetch a list of images by a list of UUIDs.

        Args:
            image_uuids (list): List of UUIDs to fetch Images for
        Returns:
            APIObject (Image)
        """
        params = {
            'uuids': image_uuids
        }
        response = cls.request('post', f'{cls.ENDPOINT}/uuid', params)
        return response.data


class ImageGroup(APIResource):
    OBJECT_NAME = "image_group"
    ENDPOINT = "/images/group"

    @classmethod
    @include_docs("/images/group/{group_id}", "get")
    def retrieve(cls, group_id, **params):
        """
        Args:
            group_id (str): ImageGroup ID to retrieve
            params (dict): any extra parameters
        Returns:
            APIObject
        """
        response = cls.request('get', f"{cls.ENDPOINT}/{group_id}", params)
        return response.data
