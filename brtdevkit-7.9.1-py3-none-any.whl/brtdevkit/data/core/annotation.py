"""
API bindings for the annotations API.
API Resource : /images/<image_id>/annotations/<annotation_id>
Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
for request parameters

Author: cfhowes <christian.howes@bluerivert.com>
Copyright 2020, Blue River Technology
"""
import io
from functools import partial

from brtdevkit.core import HTTPClient
from brtdevkit.core.api.resources.abstract import APIResource
from brtdevkit.core.api.swagger import include_docs

STATE_LABELING = 'labeling'
STATE_OK = 'ok'
STATE_REVIEW = 'review'
STATE_RELABEL = 'relabel'
STATE_VENDOR_REVIEW = 'vendor_review'
STATE_SKIPPED = 'skipped'
STATES = (
    STATE_LABELING,
    STATE_OK,
    STATE_REVIEW,
    STATE_RELABEL,
    STATE_VENDOR_REVIEW,
    STATE_SKIPPED
)


class Annotation(APIResource):

    ENDPOINT_BASE = '/images/{image_id}/annotations'
    OBJECT_NAME = 'annotation'

    def __init__(self, image_id, values):
        """
        Create the Annotation python class. This is a utility to call the APIs
        to create and update annotations.

        Args:
            image_id (str): The ID of the image that this annotation will
                belong to.
            values (dict): the key value pairs to initialize the object with
        """
        self.ENDPOINT = self.ENDPOINT_BASE.format(image_id=image_id)
        if '_id' in values:
            values['id'] = values.pop('_id')
        super().__init__(values)

    @classmethod
    def retrieve(cls, id, **params):
        """
        Since we need an image ID to fetch annotations, this cannot be a class
        method, so we override and raise NotImplementedError.
        """
        raise NotImplementedError

    def refresh_from(self, values):
        """
        Override this and allow the 'label_map' field to be a dict, not an
        object.
        """
        for k, v in values.items():
            self.__setitem__(k, v)

    @include_docs(ENDPOINT_BASE, "post")
    def create(self):
        """
        Should be called on a new annotation to persist it in the database.
        """
        if self.get('id'):
            raise ValueError('There is an ID already, did you mean to update?')
        params = self.to_dict_recursive()
        # TODO (eric): this is why you shouldn't subclass dict - `ENDPOINT` is set as an attribute
        # on Annotation, and `APIObject.to_dict_recursive` creates a dict out of all its attributes
        params.pop('ENDPOINT')
        response = self.request('post', self.ENDPOINT, params)
        self.refresh_from(response.data)

    @include_docs(ENDPOINT_BASE + '/{annotation_id}/upload_url', 'get')
    def upload(self, file_resource):
        """ Uploads an asset that will be associated with the calling annotation object to S3

        Args:
            file_resource (`str` or :class:`io.IOBase`):
                An absolute path to a file, or an io buffer containing file contents to upload.
        """
        upload_params = self.request('get', f'{self.ENDPOINT}/{self.id}/upload_url').data
        http_client = HTTPClient()
        request = partial(
            http_client.request,
            *['post', upload_params['url']],
            **dict(data=upload_params['fields'])
        )
        if isinstance(file_resource, io.IOBase):
            request(files={"file": file_resource.getvalue()})
        else:
            with open(file_resource, "rb") as fileobj:
                request(files={"file": fileobj})

    @include_docs(ENDPOINT_BASE + '/{annotation_id}', 'patch')
    def update(self):
        """
        Should be called on an existing annotation to update it in the database.
        """
        if not self.get('id'):
            raise ValueError('There is not an ID already, did you mean to save?')
        params = self.to_dict_recursive()
        response = self.request('patch', f'{self.ENDPOINT}/{self.id}', params)
        self.refresh_from(response.data)


class AnnotationBatch(APIResource):
    ENDPOINT = '/annotations/batch'

    def __init__(self, annotation_ids, values):
        """
        Create the Annotation Batch python class. This is a utility to call the APIs
        to create and update a batch of annotations.

        Args:
            annotation_ids (list): The IDs of the annotations to update
            values (dict): Data to update these annotations with
        """
        valid_keys = ('audit_requested', 'state')
        for key in values:
            if key not in valid_keys:
                values[key] = values.pop(key)
        values['annotation_ids'] = annotation_ids
        super().__init__(values)

    @classmethod
    def retrieve(cls, id, **params):
        """
        There is nothing to retrieve, so we override and raise NotImplementedError.
        """
        raise NotImplementedError

    @include_docs(ENDPOINT, 'patch')
    def update(self):
        """
        Update all of the annotations in this batch with the values dict
        """
        params = self.to_dict_recursive()
        response = self.request('patch', f'{self.ENDPOINT}', params)
        self.refresh_from(response.data)
