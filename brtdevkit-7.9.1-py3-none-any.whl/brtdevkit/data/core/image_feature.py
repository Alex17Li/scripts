"""
API bindings for the Image Features API
API Resource : /images/<image_id>/features, /images/features

Author: Asav Patel <asav.patel@bluerivert.com>

Copyright 2021, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import ListableAPIResource


class ImageFeature(
    ListableAPIResource
):
    OBJECT_NAME = "image_feature"
    ENDPOINT = "/images/features"

    @classmethod
    def retrieve(cls, id, **params):
        """
        There is no retrieve handler for this endpoint, so raise NotImplementedError.
        """
        raise NotImplementedError
