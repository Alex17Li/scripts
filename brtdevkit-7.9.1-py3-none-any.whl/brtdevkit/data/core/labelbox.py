"""
API Bindings for Lablebox webhook API.
API Resource : /webhooks/labelbox
Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
for request parameters

Author: Christian Howes <christian.howes@bluerivert.com>
Copyright 2020, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import CreateableAPIResource


class IngestLabel(CreateableAPIResource):
    OBJECT_NAME = 'labelbox_label'
    ENDPOINT = '/webhooks/labelbox'
