import logging
import random

import webdataset as wds

from .dataset import Dataset

logger = logging.getLogger(__file__)


class BRTWebDataset(wds.WebDataset):

    def __init__(
        self, s3_urls=None, dataset_id=None, webdataset_id=None, use_s5cmd=True, cache_dir=None,
        cache_size=-1, verbose=False, handler=wds.warn_and_continue, **kwargs
    ):
        if not s3_urls:
            try:
                assert dataset_id and webdataset_id
            except AssertionError:
                raise ValueError('One of {dataset_id, webdataset_id} and s3_urls must be specified')

            self.webdataset_obj = Dataset.retrieve_aletheia_webdataset(dataset_id, webdataset_id)
            s3_urls = self.webdataset_obj.shard_urls
            if use_s5cmd:
                s3_urls = [f"pipe:s5cmd --log debug --numworkers 1 cat {url}" for url in s3_urls]
            else:
                s3_urls = [f"pipe:aws s3 cp {url} -" for url in s3_urls]
        elif dataset_id or webdataset_id:
            logger.warning('s3_urls provided. Ignoring dataset_id and webdataset_id arguments.')

        # Expanding s3_urls again if it's already provided and already expanded won't hurt us.
        self.s3_urls = [pipe_url for url in s3_urls for pipe_url in wds.shardlists.expand_urls(url)]
        super().__init__(urls=self.s3_urls, cache_dir=cache_dir, cache_size=cache_size,
                         verbose=verbose, handler=handler, **kwargs)

    def __len__(self):
        return len(self.s3_urls)

    @classmethod
    def split(
        cls, seed: int, train_ratio: float, s3_urls=None, dataset_id=None, webdataset_id=None,
        use_s5cmd=True, cache_dir=None, cache_size=-1, verbose=False, handler=wds.warn_and_continue,
        **kwargs
    ):
        dset = cls(s3_urls=s3_urls, dataset_id=dataset_id, webdataset_id=webdataset_id,
                   use_s5cmd=use_s5cmd, cache_dir=cache_dir, cache_size=cache_size, verbose=verbose,
                   handler=handler, **kwargs)
        all_s3_urls = dset.s3_urls
        random.seed(seed)
        random.shuffle(all_s3_urls)
        assert 0 < train_ratio < 1, "train_ratio expected to be in range (0, 1)"
        assert len(all_s3_urls) >= 2  # We can't split without at least 2 shards
        train_cutoff = round(train_ratio * len(all_s3_urls))
        if train_cutoff == 0:
            train_cutoff = 1  # Ensure we have at least one train shard
        elif train_cutoff == len(all_s3_urls):
            train_cutoff -= 1  # Ensure we have at least one val shard
        train_s3_urls = all_s3_urls[:train_cutoff]
        val_s3_urls = all_s3_urls[train_cutoff:]
        assert len(train_s3_urls) > 0 and len(val_s3_urls) > 0, \
            'Both train and val sets should have a non-zero number of s3_urls. How did this happen!'
        if cache_size > 0:
            train_cache_size = cache_size * len(train_s3_urls) / len(all_s3_urls)
            val_cache_size = cache_size * len(val_s3_urls) / len(all_s3_urls)
        else:
            train_cache_size, val_cache_size = cache_size, cache_size

        train_dset = cls(s3_urls=train_s3_urls, cache_dir=cache_dir, cache_size=train_cache_size,
                         verbose=verbose, handler=handler, **kwargs)
        val_dset = cls(s3_urls=val_s3_urls, cache_dir=cache_dir, cache_size=val_cache_size,
                       verbose=verbose, handler=handler, **kwargs)
        return train_dset, val_dset
