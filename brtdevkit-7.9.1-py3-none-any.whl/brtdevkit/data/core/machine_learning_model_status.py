"""
API bindings for the machine learning model status API.
API Resource : /machine_learning_models/<ml_model_id>/status, /machine_learning_models/status

Author: Asav Patel <asav.patel@bluerivert.com>

Copyright 2021, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import ListableAPIResource


class MachineLearningModelStatus(
    ListableAPIResource
):
    OBJECT_NAME = "machine_learning_model_status"
    ENDPOINT = "/machine_learning_models/status"

    @classmethod
    def retrieve(cls, id, **params):
        """
        There is no retrieve handler for this endpoint, so raise a NotImplementedError.
        """
        raise NotImplementedError
