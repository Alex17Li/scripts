"""
API bindings for the model evaluation API.
API Resource : /model_evaluations/<evaluation_id>

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>

Copyright 2020, Blue River Technology
"""

from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    DeletableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
    nested_resource_class_methods,
)
from brtdevkit.data.core.image_evaluation import ImageEvaluation


@nested_resource_class_methods(
    ImageEvaluation, path='image_evaluations', operations=["list"]
)
class ModelEvaluation(
    ListableAPIResource, CreateableAPIResource,
    DeletableAPIResource, UpdateableAPIResource
):
    OBJECT_NAME = "model_evaluation"
    ENDPOINT = "/model_evaluations"

    @classmethod
    def filters(cls, **params):
        """
        Retrieve the supported filters on the ModelEvaluation collection

        Args:
            params (dict): Any extra parameters
        Returns:
            dict
        """
        response = cls.request('get', f"{cls.ENDPOINT}/filters", params)
        return response.data

    def image_evaluations(self, **params):
        """
        Get the image evaluations associated with this model evaluation

        Args:
            params (dict): Any extra parameters
        Returns:
            ListObject
        """
        return self.list_image_evaluation(id=self.id, **params)

    def save(self):
        raise NotImplementedError("save() not supported on this API resource")
