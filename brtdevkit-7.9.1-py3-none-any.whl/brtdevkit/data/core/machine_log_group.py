""" API Bindings for MachineLogGroup API.

Author: Suresh Thapa <suresh.thapa@bluerivertech.com>

Copyright 2021, Blue River Technology
"""

from brtdevkit.core import ListObject
from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    ListableAPIResource,
)


class MachineLogGroup(ListableAPIResource, CreateableAPIResource):
    OBJECT_NAME = 'machine_log_group'
    ENDPOINT = '/machine_log_groups'
    LOG_IDS_ENDPOINT = "/machine_log_groups/{machine_log_group_id}/logs"

    @classmethod
    def get_logs(cls, id, **params):
        machine_log_group_endpoint = cls.LOG_IDS_ENDPOINT.format(
            machine_log_group_id=id)
        response = cls.request("get", machine_log_group_endpoint, params)
        response.data['data'] = [cls(item) for item in response.data['data']]
        response.data['params'] = params
        return ListObject(response.data, endpoint=machine_log_group_endpoint)
