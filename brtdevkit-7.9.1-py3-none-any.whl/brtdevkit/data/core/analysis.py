"""
API bindings for the analyses API.
API Resource : /analyses/<analysis_id>
Please check API docs : http://aletheia-api.brtws.com/api/v1/docs
for request parameters

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
Copyright 2020, Blue River Technology
"""
from brtdevkit.core.api.resources.abstract import (
    APIResource,
    CreateableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
)
from brtdevkit.core.api.swagger import include_docs


class Analysis(CreateableAPIResource, ListableAPIResource, UpdateableAPIResource):
    OBJECT_NAME = 'analysis'
    ENDPOINT = '/analyses'

    def save(self):
        raise NotImplementedError()


class AnalysisArtifact(APIResource):
    ENDPOINT = '/analyses/{analysis_id}/artifacts'

    @classmethod
    @include_docs(f'{ENDPOINT}/' + '{artifact_id}', 'get')
    def retrieve(cls, analysis_id, artifact_id, **params):
        """
        Since we need an analysis ID to fetch analysis artifacts,
        we must override this method.
        """
        endpoint = f"{cls.ENDPOINT.format(analysis_id=analysis_id)}/{artifact_id}"
        response = cls.request('get', endpoint, params)
        return cls(response.data, **params, _analysis_id=analysis_id)

    @classmethod
    @include_docs(ENDPOINT, 'post')
    def create(cls, analysis_id, **params):
        """
        Args:
            analysis_id (str) : ID of the analysis object to create the artifact on
            params (dict) : any extra parameters
        Returns:
            AnalysisArtifact
        """
        response = cls.request(
            "post", cls.ENDPOINT.format(analysis_id=analysis_id), params, headers=None)
        return cls(response.data, **params, _analysis_id=analysis_id)

    @classmethod
    @include_docs(ENDPOINT, 'patch')
    def modify(cls, analysis_id, artifact_id, params):
        """
        Args:
            analysis_id (str) : ID of the analysis object of the artifact to modify
            params (dict) : patch parameters
        Returns:
            AnalysisArtifact
        """
        endpoint = f"{cls.ENDPOINT.format(analysis_id=analysis_id)}/{artifact_id}"
        response = cls.request("patch", endpoint, params)
        return cls(response.data, **params, _analysis_id=analysis_id)

    def instance_url(self):
        return (f"{self.ENDPOINT.format(analysis_id=self._retrieve_params['_analysis_id'])}"
                f"/{self.id}")

    def refresh(self):
        response = self.request("get", self.instance_url(), params=self._retrieve_params)
        self.refresh_from(response.data)

    def save(self):
        params = self.to_dict_recursive()
        params.pop('analysis_id')  # Internal tracking variable, not part of model definition
        response = self.request("patch", self.instance_url(), params)
        self.refresh_from(response.data)
