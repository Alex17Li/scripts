""" API Bindings for task API.
    API Resource : /tasks/
    Please check API docs for request parameters

Author: cfhowes <christian.howes@bluerivert.com>
Copyright 2020, Blue River Technology
"""
from brtdevkit.core.api.resources.abstract.createable_api_resource import (
    CreateableAPIResource,
)
from brtdevkit.core.api.resources.abstract.listable_api_resource import (
    ListableAPIResource,
)


class Task(ListableAPIResource, CreateableAPIResource):
    OBJECT_NAME = 'task'
    ENDPOINT = '/tasks'
