"""
API bindings for the User API.
API Resource: /users

Author: JC Lanoë <jc.lanoe@bluerivertech.com>
Copyright 2023, Blue River Technology
"""
from brtdevkit.core.api.resources.abstract import APIResource


class User(APIResource):
    OBJECT_NAME = 'user'
    ENDPOINT = '/users'

    @classmethod
    def me(cls, **params):
        response = cls.request('get', f'{cls.ENDPOINT}/me', params)
        return cls(response.data, **params)
