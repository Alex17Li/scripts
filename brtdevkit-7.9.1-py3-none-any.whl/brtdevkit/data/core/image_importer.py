"""
DEPRECATED -- see MESASW-1503

    API Bindings for image importer API.
    API Resource : /image/import
    Please check API docs : http://tartarus-api.brtws.com/api/v1/docs
    for request parameters

Author: Taylor Ritenour <taylor.ritenour@bluerivert.com>
Copyright 2019, Blue River Technology
"""

from brtdevkit import config
from brtdevkit.core.api.resources.abstract import APIResource
from brtdevkit.util import logger

log = logger.Logger('ImageImporter')


class ImageImporter(APIResource):
    OBJECT_NAME = 'image_importer'
    ENDPOINT = '/images/import'

    DEV_BUCKET = 's3.aletheia.uploads.dev'
    PROD_BUCKET = 's3.aletheia.uploads.prod'

    @classmethod
    def run(cls, s3_key, mode):
        """
        Kicks off an image importer job to the tartarus workers
        Args:
            s3_key (str): s3 key to be imported
            mode (str): what mode to run importer in ['jupiter', 'imec', 'ar233']
        """
        params = {
            's3_bucket': cls.get_s3_bucket(),
            's3_key': s3_key,
            'mode': mode
        }
        log.info(f'Queuing image importer on: s3://{cls.get_s3_bucket()}/{s3_key}...')
        response = cls.request("post", cls.ENDPOINT, params)  # noqa: F841

    @classmethod
    def get_s3_bucket(cls):
        return cls.PROD_BUCKET if config.ENV == config.ENV_PROD else cls.DEV_BUCKET
