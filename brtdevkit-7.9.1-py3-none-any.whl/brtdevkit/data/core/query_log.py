"""
API bindings for the QueryLog API.
API Resource: /query_logs

Author: Corey Sutphin <corey.sutphin@bluerivertech.com>
Copyright 2021, Blue River Technology
"""
from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    UpdateableAPIResource,
)


class QueryLog(CreateableAPIResource, UpdateableAPIResource):
    OBJECT_NAME = 'query_log'
    ENDPOINT = '/query_logs'
