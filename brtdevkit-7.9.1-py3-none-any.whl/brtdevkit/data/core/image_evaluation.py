"""
API bindings for the image evaluation API.
API Resource : /image_evaluations/<image_evaluation_id>

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>

Copyright 2020, Blue River Technology
"""
from os import PathLike
from pathlib import Path

import requests

from brtdevkit.core.api.resources.abstract import (
    CreateableAPIResource,
    DeletableAPIResource,
    ListableAPIResource,
    UpdateableAPIResource,
)
from brtdevkit.core.api.swagger import include_docs


class ImageEvaluation(
        CreateableAPIResource, DeletableAPIResource, ListableAPIResource, UpdateableAPIResource
):
    OBJECT_NAME = "image_evaluation"
    ENDPOINT = "/image_evaluations"

    @include_docs(ENDPOINT + '/{image_evaluation_id}/upload_url', 'get')
    def _upload_url(self, data):
        """
        Call the upload url API to retrieve the request parameters
        needed to upload the file to S3

        Args:
            data (dict): POST data for the request
        Returns:
            dict: The API response data
        """
        response = self.request('post', f"{self.instance_url}/upload_url", data)
        return response.data

    @include_docs(ENDPOINT + '/{image_evaluation_id}/upload_url', 'post')
    def _upload(self, filepath: PathLike, upload_url: dict):
        """
        Upload file to S3 url

        Args:
            filepath (PathLike): The path of the file to upload
            upload_url (dict): Dictionary containing parameters needed for S3 upload
        Returns:
            requests.models.Response
        """
        with open(filepath, 'rb') as thefile:
            # Upload the Image to the S3 bucket.
            resp = requests.post(
                upload_url['url'],
                data=upload_url['fields'],
                files=[('file', thefile)])
        return resp

    def upload_prediction(self, filepath: PathLike):
        """
        Upload the prediction file to the ImageEvaluation

        Args:
            filepath (PathLike): The path to the file to upload
        Returns:
            requests.models.Response
        """
        upload_url = self._upload_url({
            'prediction_s3_filename': Path(filepath).name
        })
        return self._upload(filepath, upload_url['prediction_s3_url'])

    def upload_thumbnail(self, filepath: PathLike):
        """
        Upload the thumbnail file to the ImageEvaluation

        Args:
            filepath (PathLike): The path to the file to upload
        Returns:
            requests.models.Response
        """
        upload_url = self._upload_url({
            'thumbnail_s3_filename': Path(filepath).name
        })
        return self._upload(filepath, upload_url['thumbnail_s3_url'])

    def save(self):
        raise NotImplementedError("save() not supported on this API resource")
