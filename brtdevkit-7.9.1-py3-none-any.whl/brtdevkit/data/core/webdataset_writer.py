"""
Wrapper class for creating a webdataset

Authors: Asav Patel <asav.patel@bluerivertech.com>

Copyright 2021, Blue River Technology
"""
import csv
import json
import os
from concurrent.futures import ThreadPoolExecutor, wait
from pathlib import Path

from webdataset import ShardWriter

import brtdevkit
from brtdevkit.util import logger
from brtdevkit.util.aws.s3 import S3

log = logger.Logger('WebDatasetWriter')

ZERO_FILL_LENGTH = 7
SHARD_NAME = "shard-"
SHARD_NAME_FORMAT = f"{SHARD_NAME}%0{ZERO_FILL_LENGTH}d.tar"


class WebDatasetWriter:

    def __init__(self, dataset_id: str, sample_size: int, save_path: str, s3_key_prefix: str,
                 upload_to_s3: bool = True, auto_clean: bool = True, encoder: bool = True):
        """
        Wrapper class to create a webdataset
        Args:
            dataset_id (str) : Aletheia Dataset ID
            sample_size (int): number of samples to be included in a shard
            save_path (str): path to save shards
            s3_key_prefix (str): prefix to the s3 key,
                                a specific folder name in which user might want to store the shards.
            upload_to_s3 (bool) : Upload shards to S3 automatically, Default shard location on S3
                        would be : s3://dataset_id.metadata_file_location/dataset_id/s3_key_prefix
            auto_clean (bool): auto delete shards from disk after they are uploaded to s3
            encoder (bool): auto encode data samples based on given extensions.
                            eg. image.png, data.npz
        """
        self.sample_size = sample_size
        self.save_path = Path(save_path)
        self._ds = brtdevkit.data.Dataset.retrieve(id=dataset_id)
        self.s3_bucket = self._ds.metadata_s3_bucket
        self.base_s3_key = str(
            Path(Path(self._ds.metadata_s3_key).parent, self._ds.id, s3_key_prefix))
        self.shard_metadata_s3_key = str(Path(self.base_s3_key, "shard_metadata.csv"))

        self.upload_to_s3 = upload_to_s3
        self.auto_clean = auto_clean
        self.data_sample_keys = set()
        save_path_pattern = str(Path(save_path, SHARD_NAME_FORMAT))
        self._shard_writer = ShardWriter(
            save_path_pattern, maxcount=sample_size, post=self._post_creation, encoder=encoder)

        self._shard_metadata_file = Path(save_path, 'shard_metadata.csv').open('a')
        self._shard_metadata_writer = csv.DictWriter(
            self._shard_metadata_file, fieldnames=["datasample_key", "shard_name"]
        )

        self._shard_metadata_writer.writeheader()

        # TODO (Asav) : Remove explicitly reading credentials from Environment variables
        #               once internal credentials are removed from the package
        self.s3_client = S3(
            aws_access_key_id=os.environ.get("AWS_ACCESS_KEY_ID"),
            aws_secret_access_key=os.environ.get("AWS_SECRET_ACCESS_KEY")
        )
        self._shards_path = set()
        self._futures = set()
        self._executor = ThreadPoolExecutor(brtdevkit.MAX_WORKERS)
        self.__is_closed = False

    def __post_shard_creation(self, shard_file_path: str):
        """
        actions to be performed after shard creation.
        upload shard to s3, delete the shard file from disk after upload is finished.
        Args:
            shard_file_path (str) : File path for created shard
        """
        shard_file_path = Path(shard_file_path)
        if self.upload_to_s3:
            s3_key = str(Path(self.base_s3_key, shard_file_path.name))
            log.info(f"Uploading shard : {shard_file_path} to S3. s3://{self.s3_bucket}/{s3_key}")
            uploaded = self.s3_client.upload_file(self.s3_bucket, s3_key, shard_file_path)
            if uploaded:
                self._shards_path.add(f"s3://{self.s3_bucket}/{s3_key}")
            else:
                log.warn(f"Could not upload : {shard_file_path} to s3://{self.s3_bucket}/{s3_key}")

            log.info(
                f"Uploading shard metadata : {self._shard_metadata_file.name} to S3. "
                f"s3://{self.s3_bucket}/{self.shard_metadata_s3_key}")
            uploaded = self.s3_client.upload_file(
                self.s3_bucket, self.shard_metadata_s3_key, self._shard_metadata_file.name)
            if not uploaded:
                log.warn(
                    f"Could not upload : {self._shard_metadata_file.name} to "
                    f"s3://{self.s3_bucket}/{self._shard_metadata_file}")
        else:
            self._shards_path.add(shard_file_path)
        if self.auto_clean:
            shard_file_path.unlink()

    def _post_creation(self, shard_file_path: str):
        """
        Submits post shard creation call to a thread and returns.
        Args:
             shard_file_path (str) : File path for created shard
        """
        self._futures.add(self._executor.submit(self.__post_shard_creation, shard_file_path))

    def get_shard_range(self):
        shard_range = Path(
            Path(next(iter(self._shards_path))).parent,
            f"{SHARD_NAME}{{{''.zfill(ZERO_FILL_LENGTH)}.."
            f"{Path(self._shard_writer.fname).stem.split('-').pop()}}}.tar"
        )
        return str(shard_range).replace("s3:/", "s3://")  # pathlib removes double slash from URI!

    def write(self, key: str, **kwargs):
        """ write a datasample to the shard
        Args:
             key (str): key for datasample
             kwargs (dict) : items to be included in datasample
        """
        sample_keys = set(kwargs.keys())
        if self.data_sample_keys:
            if self.data_sample_keys != sample_keys:
                raise ValueError('All data sample should have same keys')
        self.data_sample_keys = self.data_sample_keys | sample_keys
        self._shard_writer.write({
            "__key__": key,
            **kwargs
        })
        self._shard_metadata_writer.writerow(
            {'datasample_key': key, 'shard_name': Path(self._shard_writer.fname).name}
        )

    def close(self):
        self._shard_writer.close()
        self._shard_metadata_file.close()
        # Important : always wait() after closing the shard_writer, otherwise shard which was
        # created at last won't get uploaded to S3
        wait(self._futures)
        self.__is_closed = True

    def save(self, name, description, parameters=None):
        if not self.__is_closed:
            raise Exception("You must call close() before saving the webdataset")
        return self._ds.create_aletheia_webdataset(
            id=self._ds.id, name=name,
            description=description, parameters=parameters,
            **self.to_dict())

    def to_dict(self):
        return {
            'datasample_keys': sorted(list(self.data_sample_keys)),
            'sample_size': self.sample_size,
            'shard_urls': self.get_shard_range(),
            'shard_metadata_url': f"s3://{self.s3_bucket}/{self.shard_metadata_s3_key}"
                                  if self.upload_to_s3 else self._shard_metadata_file.name
        }

    def __str__(self):
        return json.dumps(self.to_dict(), sort_keys=True, indent=2)

    def __enter__(self):
        """Enter context."""
        return self

    def __exit__(self, *args, **kwargs):
        """Exit context."""
        self.close()
