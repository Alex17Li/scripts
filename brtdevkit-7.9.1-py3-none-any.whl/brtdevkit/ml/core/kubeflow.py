"""
API bindings for the Kubeflow API.
API Resource : /kubeflow/pipelines/<pipeline_id>
for request parameters

Author: Ajay Penmatcha <ajay.penmatcha@bluerivert.com>
        Asav Patel <asav.patel@bluerivert.com>

Copyright 2020, Blue River Technology
"""
import os
import tempfile
import uuid
from typing import Callable, Mapping, Optional

import kfp

from brtdevkit.core.api.resources.abstract import (
    APIResource,
    DeletableAPIResource,
    ListableAPIResource,
    NamedListableAPIResource,
)
from brtdevkit.util.aws.s3 import S3


class KubeflowPipeline(
    NamedListableAPIResource,
    DeletableAPIResource,
):
    OBJECT_NAME = "kubeflow_pipeline"
    ENDPOINT = "/kubeflow/pipelines"

    def submit(self, **params):
        namespace = params is not None and params.get('namespace')
        # Mesa specific header that the mesa-kubeflow api will use to set the namespace after
        # validating the user has access to it
        headers = {"X-Kubeflow-Namespace": namespace} if namespace else None
        response = self.request("post", f"{self.ENDPOINT}/{self.id}", params, headers=headers)
        return response.data

    @classmethod
    def submit_pipeline(cls, pipeline_id, **params):
        namespace = params is not None and params.get('namespace')
        # Mesa specific header that the mesa-kubeflow api will use to set the namespace after
        # validating the user has access to it
        headers = {"X-Kubeflow-Namespace": namespace} if namespace else None
        response = cls.request("post", f"{cls.ENDPOINT}/{pipeline_id}", params, headers=headers)
        return response.data


class KubeflowPipelineExecutor(APIResource):
    OBJECT_NAME = "kubeflow_pipeline_executor"
    ENDPOINT = "/kubeflow/pipeline_executor"

    # Note: This bucket exists in us-west-2 and deletes everything after a day.
    # It is a purely temporary storage to facilitate communication between brtdevkit and the
    # mesa kubeflow api
    S3_BUCKET_NAME = "mesa-kubeflow-tmp-pipelines"

    @classmethod
    def create_run_from_pipeline_func(
            cls,
            pipeline_func: Callable,
            arguments: Mapping[str, str],
            run_name: Optional[str] = None,
            experiment_name: Optional[str] = None,
            pipeline_conf: Optional[kfp.dsl.PipelineConf] = None,
            namespace: Optional[str] = None
    ):
        s3_key = f"{uuid.uuid1()}.yaml"
        # Mesa specific header that the mesa-kubeflow api will use to set the namespace after
        # validating the user has access to it
        headers = {"X-Kubeflow-Namespace": namespace} if namespace else None
        with tempfile.TemporaryDirectory() as tmpdir:
            pipeline_package_path = os.path.join(tmpdir, 'pipeline.yaml')
            kfp.compiler.Compiler().compile(pipeline_func, pipeline_package_path,
                                            pipeline_conf=pipeline_conf)
            s3_client = S3()
            s3_client.upload_file(cls.S3_BUCKET_NAME, s3_key, pipeline_package_path)

        post_data = {
            "name": run_name,
            "s3_bucket": cls.S3_BUCKET_NAME,
            "s3_key": s3_key,
            "params": arguments,
            "experiment_name": experiment_name,
            "namespace": namespace,
        }

        response = cls.request("post", f"{cls.ENDPOINT}", post_data, headers=headers)
        return response.data


class KubeflowPipelineRun(
    ListableAPIResource
):
    OBJECT_NAME = "kubeflow_pipeline_run"
    ENDPOINT = "/kubeflow/runs"

    @classmethod
    def retry(cls, id):
        response = cls.request('post', f'{cls.ENDPOINT}/{id}/retry')
        return response.code == 200

    @classmethod
    def terminate(cls, id):
        response = cls.request('post', f'{cls.ENDPOINT}/{id}/terminate')
        return response.code == 200
