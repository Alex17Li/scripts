# -*- coding: utf-8 -*-

"""Top-level package for brt-devkit.

Aletheia API Bindings and other tools for CV And ML.
Aletheia API Docs : http://aletheia-api.brtws.com/api/v1/docs

Author : BRT - CV/ML Enterprise Team <asav.patel@bluerivert.com>
Copyright 2019, Blue River Technology
"""
from multiprocessing import cpu_count

import pkg_resources

from brtdevkit import config

__version__ = pkg_resources.get_distribution(__package__).version
log_level = "INFO"


# Pull brtdevkit credentials from the Mesa API if running in Databricks
if config.is_running_in_databricks():
    databricks_api_token, databricks_api_host = \
            config.get_databricks_api_token_and_host()
    config.generate_all_credentials_files_in_databricks(
        databricks_api_token,
        databricks_api_host
    )

# Configuration variables
config.load_credentials()

# Number of worker threads for multiprocessed code
MAX_WORKERS = cpu_count() * 2

# aletheia specific stuff here
api_base = f"{config.API_BASE}"
refresh_token = getattr(config.Credentials, "REFRESH_TOKEN", None)
api_key = None if refresh_token else getattr(config.Credentials, "API_KEY", None)
max_network_retries = 3
